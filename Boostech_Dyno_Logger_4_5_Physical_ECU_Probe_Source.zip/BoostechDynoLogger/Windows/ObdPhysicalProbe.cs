using System.Text.RegularExpressions;
namespace BoostechDynoLogger;
public static class ObdPhysicalProbe {
 // Require a response from the expected ECU CAN ID, with standard Mode 01
 // positive service 41 and PID 00. Ignore echoes and other ECU addresses.
 public static bool IsMode01SupportedPidReply(string raw,string expectedRx) {
  foreach(var line in raw.ToUpperInvariant().Split(['\r','\n'],StringSplitOptions.RemoveEmptyEntries)) {
   var match=Regex.Match(line.Trim(),@"^([0-9A-F]{3})\s+(?:[0-9A-F]{2}\s+)?41\s+00(?:\s|$)");
   if(match.Success && match.Groups[1].Value==expectedRx.ToUpperInvariant())return true;
  }
  return false;
 }
}
