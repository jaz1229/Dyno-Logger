# Boostech Dyno Logger — Honda Discovery v0.1

Windows WPF (.NET 10) **source-code prototype**. No flashing, ECU programming, clearing codes or write services. Includes a fully offline simulator and read-only Mode 01 requests.

## Build on Windows 10/11
1. Install the **.NET 10 SDK** (and Windows desktop workload if using Visual Studio).
2. Open PowerShell in this folder.
3. Run `dotnet restore` then `dotnet run`.
4. To publish a standalone EXE: `dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true`.
5. Find the EXE in `bin/Release/net10.0-windows/win-x64/publish/`.

The project references `System.IO.Ports` 10.0.15 from NuGet, requiring internet during first restore.

## Before your 6-pin cable arrives
Select **Simulator**, click Connect, Discover supported PIDs, then Start logging. The data is generated and is NOT real Honda ECU data. You can check dashboard, console and CSV export now.

## When the cable arrives
1. Confirm cable wiring/fit and 12V compatibility against Honda documentation. Do not force the connector or bridge SCS.
2. With ignition off, connect Honda DLC -> appropriate 6-pin-to-16-pin OBD adapter -> Vgate.
3. Turn ignition on. In Windows Bluetooth settings pair **Android-Vlink** (Vgate lists PIN **1234**).
4. In Windows Device Manager > Ports, find the outgoing Bluetooth serial COM port.
5. Select **Bluetooth COM**, choose that COM port, click Connect and Discover.
6. If no COM port is available, this version does **not** support BLE GATT; a BLE transport must be implemented after identifying the actual GATT service/characteristics. Do not assume pairing alone guarantees COM.
7. Confirm RPM at idle and compare temperature values to known readings before any dyno run.

## Scope and limitations
- Mode 01 PID discovery (0100/0120/0140), then response validation.
- Decodes standard PIDs: 04,05,06,07,0B,0C,0D,0E,0F,11,14,15,24,34,42 where the ECU advertises and responds.
- ECU-specific Honda PIDs, gear, injector pulse width, knock correction and external wideband are NOT implemented.
- Serial baud fixed at 38400 for the ELM-compatible COM transport; may need adjustment for a particular firmware.
- OBD polling is sequential and per-channel rate depends on ECU and adapter. CSV stores one timestamped row per successful response, NOT synchronized samples.
- Raw parser handles common spaced/compact ELM Mode 01 response layouts; it is not a complete ISO-TP multi-frame implementation. Validate on real ECU.
- No direct YourDyno integration yet. Export CSV and align externally.
- No Windows build was executed in the authoring environment. Compile and test on Windows before using for real dyno logging.
- This prototype is diagnostic software, not a safety-critical monitoring device. Use separate calibrated wideband AFR equipment for tuning.

## Example CSV
`timestamp_utc,elapsed_ms,pid,parameter,value,unit,raw_response`

## Next iteration
Bluetooth BLE GATT support if required, Honda-specific verified ECU parameter profile, configurable polling priorities, wideband serial input, YourDyno CSV overlay, logging watchdog and connection recovery.

## Easy launch (recommended)
- On Windows 10/11, double-click `START_HERE.bat`.
- First launch requires the .NET 10 SDK and internet access to restore the serial-port NuGet dependency. The script builds a self-contained EXE and launches it.
- On later launches, `START_HERE.bat` starts the existing EXE directly, without rebuilding.
- Optionally double-click `CREATE_DESKTOP_SHORTCUT.bat` after the first successful build to add a desktop shortcut.
- To rebuild after editing source, run `build-windows.bat`. The desktop shortcut will point to the updated published EXE.
- This is still an uncompiled, untested Windows source distribution. It does not contain a prebuilt EXE.
