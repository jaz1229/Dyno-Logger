@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>&1
if errorlevel 1 (
 echo .NET 10 SDK is required. Download: https://dotnet.microsoft.com/download/dotnet/10.0
 pause
 exit /b 1
)
echo Publishing standalone Windows x64 executable...
dotnet publish BoostechDynoLogger.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o "%~dp0Release"
if errorlevel 1 (echo BUILD FAILED & pause & exit /b 1)
echo.
echo SUCCESS: %~dp0Release
explorer "%~dp0Release"
pause
