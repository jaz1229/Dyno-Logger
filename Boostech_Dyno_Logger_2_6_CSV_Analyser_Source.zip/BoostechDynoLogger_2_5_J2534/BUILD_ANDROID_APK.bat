@echo off
cd /d "%~dp0Android"
where dotnet >nul 2>&1 || (echo Install .NET 10 SDK & pause & exit /b 1)
dotnet workload install maui-android
if errorlevel 1 (echo Android workload installation failed & pause & exit /b 1)
dotnet publish BoostechMobile.csproj -f net10.0-android -c Release -p:AndroidPackageFormat=apk -p:AndroidKeyStore=false
if errorlevel 1 (echo Build failed. Check Android SDK and workload installation. & pause & exit /b 1)
echo Check Androidin\Release
et10.0-android\publish for APK
pause
