using System.IO;
using System.Text.Json;

namespace BoostechDynoLogger;
public sealed class EcuProfileRecord {
 public string ProfileId {get;set;}="";
 public string DisplayName {get;set;}="";
 public string Manufacturer {get;set;}="";
 public string VinWmiPrefix {get;set;}="";
 public string CalibrationId {get;set;}="";
 public string ProtocolContains {get;set;}="";
 public string Status {get;set;}="reference";
 public string[] SuggestedStandardPids {get;set;}=[];
 public string Notes {get;set;}="";
}
public sealed class ProfileMatch {
 public EcuProfileRecord Profile {get;set;}=new();
 public string Confidence {get;set;}="Unverified";
 public bool VerifiedForAutomaticUse {get;set;}
 public string Reason {get;set;}="";
}
public static class EcuProfileDatabase {
 public static IReadOnlyList<EcuProfileRecord> Load(string path) {
  if(!File.Exists(path))return [];
  using var stream=File.OpenRead(path);
  using var doc=JsonDocument.Parse(stream);
  if(doc.RootElement.ValueKind!=JsonValueKind.Array)return [];
  var result=JsonSerializer.Deserialize<List<EcuProfileRecord>>(doc.RootElement.GetRawText(),
   new JsonSerializerOptions{PropertyNameCaseInsensitive=true})??[];
  return result.Where(x=>!string.IsNullOrWhiteSpace(x.ProfileId)).ToList();
 }
 public static IReadOnlyList<ProfileMatch> Match(EcuIdentity ecu,IEnumerable<EcuProfileRecord> profiles) {
  var found=new List<ProfileMatch>();
  foreach(var p in profiles) {
   bool exactCal=!string.IsNullOrWhiteSpace(p.CalibrationId)&&
    ecu.CalibrationIds.Split('|',StringSplitOptions.TrimEntries).Any(c=>c.Equals(p.CalibrationId,StringComparison.OrdinalIgnoreCase));
   bool wmi=!string.IsNullOrWhiteSpace(p.VinWmiPrefix)&&
    ecu.Vin.StartsWith(p.VinWmiPrefix,StringComparison.OrdinalIgnoreCase);
   bool proto=!string.IsNullOrWhiteSpace(p.ProtocolContains)&&
    ecu.Protocol.Contains(p.ProtocolContains,StringComparison.OrdinalIgnoreCase);
   if(!exactCal&&!wmi)continue;
   bool verified=exactCal&&p.Status.Equals("verified",StringComparison.OrdinalIgnoreCase)
    &&(string.IsNullOrWhiteSpace(p.VinWmiPrefix)||wmi)
    &&(string.IsNullOrWhiteSpace(p.ProtocolContains)||proto);
   found.Add(new ProfileMatch{Profile=p,VerifiedForAutomaticUse=verified,
    Confidence=verified?"Verified profile":exactCal?"Exact calibration match (unverified profile)":"Manufacturer/WMI candidate only",
    Reason=verified?"Exact calibration and profile constraints validated":
      exactCal?"Matching calibration ID, but profile not validated for automatic use":
      "VIN prefix matches; ECU hardware and calibration not confirmed"});
  }
  return found.OrderByDescending(x=>x.VerifiedForAutomaticUse).ThenByDescending(x=>x.Confidence.StartsWith("Exact")).ToList();
 }
 public static string FindDatabase() => Path.Combine(AppContext.BaseDirectory,"ecu_profiles.json");
}
