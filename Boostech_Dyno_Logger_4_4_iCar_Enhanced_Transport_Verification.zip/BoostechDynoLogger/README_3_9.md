# Boostech Dyno Logger 3.9 — Parameter coverage and diagnostics groundwork

## Implemented
- **Required channels** window: shows which of 24 useful dyno/diagnostic parameters are backed by ECU-verified standard Mode 01 PIDs and which are missing.
- **Export coverage** JSON: useful for building a verified manufacturer-specific ECU profile from a real vehicle.
- Approximate boost gauge availability requires BOTH supported 010B MAP and 0133 BARO; it is reported as **derivable**, not automatically logged or represented as an OEM boost sensor.
- Clearly differentiates ignition advance from cylinder-specific knock retard, commanded equivalence ratio from measured lambda, and unavailable OEM channels from standard OBD2.
- Existing multi-vehicle selection, ECU ID, CSV logging, YourDyno analysis, and offline J1939 remain.

## Not implemented
- Universal OEM enhanced PIDs for all vehicles. There is no universal manufacturer-specific address/scale for knock, boost target, fuel correction, etc.
- Working ISO-TP/UDS 0x22 read-data-by-identifier, KWP measuring blocks, J1939 live CAN interface, NMEA 2000, and ECU-specific knock logging.
- Production-ready validated vLinker/Tactrix transport. Exact vLinker model and ECU hardware are required to test those.

## Build / verify
Windows/.NET 10 SDK: run `Windows/PUBLISH_EXE.bat`. No Windows compiler or adapter is available in this environment; the source is **not build-verified**. Check build output and report errors. Use a stationary vehicle for initial testing.

## References
SAE J1979 support bitmap / Mode 01 definitions; python-OBD Command Tables https://python-obd.readthedocs.io/en/latest/Command%20Tables/
