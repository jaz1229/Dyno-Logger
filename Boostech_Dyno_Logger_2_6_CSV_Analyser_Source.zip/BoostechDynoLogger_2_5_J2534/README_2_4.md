# Boostech Dyno Logger 2.4 — Adapter Discovery Preview

Windows-only source update based on v2.3. This is NOT a fully functioning Tactrix logger.

## What changed
- Adds Tactrix/J2534 option to transport selector.
- Enumerates installed J2534 drivers via Windows PassThruSupport.04.04 / 05.00 registry keys, checking 32-bit and 64-bit registry views.
- Displays discovered driver names and DLL locations.
- Explicitly blocks connecting to J2534 until a correctly implemented and tested native transport exists.
- Existing simulator, Bluetooth Classic serial/ELM327, standard PID discovery, scanning and CSV logging remain available.

## Important limitations
- Tactrix Openport USB cannot be operated using ELM327 AT commands. J2534 PassThruOpen/Connect, message framing, ISO-TP filtering, protocol selection, timeouts and error handling must be implemented and hardware-tested separately.
- Driver detection does NOT establish that a device is plugged in, genuine, operational or compatible with the ECU.
- No BLE GATT support; a Vgate adapter that exposes no Windows COM port cannot be used yet.
- No manufacturer-specific tractor or marine protocols.
- Windows build not compiled or tested in this environment.

## Build
Extract the zip and run BUILD_WINDOWS_EXE.bat from the project root on a Windows PC with .NET 10 SDK. This is source code, not a precompiled executable.
