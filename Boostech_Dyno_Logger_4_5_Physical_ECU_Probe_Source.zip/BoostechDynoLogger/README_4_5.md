# Boostech Dyno Logger 4.5 — physical ECU address verification

Adds a **read-only**, controlled physical-address diagnostic probe for the observed
7E8/7E9 CAN responders on the test Golf. Tests standard Mode 01 PID 00 via
7E0->7E8 and 7E1->7E9 with a response filter, reports independently verified
responses, exports through existing transport trace, and restores ELM settings.

**This is not VW TP 2.0/KWP2000 implementation and does not unlock knock,
requested boost, lambda target or fuel pressure channels.** ELM327-style AT
commands do not guarantee raw CAN frame control. Before implementing TP 2.0,
verify raw CAN receive/transmit capabilities and ECU identity with suitable
hardware/reference diagnostics. Do not log or tune from unverified values.

## Test
Connect Bluetooth COM; stop logging/discovery; Enhanced ECU ID tab ->
Probe physical ECU addresses -> Export transport trace. Ignition on,
vehicle stationary. The initial functional 0100 can take ~7 seconds.

## Build
Windows/PUBLISH_EXE.bat (Windows with .NET SDK 10). Not compiled or hardware
validated in this environment.
