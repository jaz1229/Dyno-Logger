using System.Globalization;
namespace BoostechDynoLogger;
// Passive J1939 frame decoding. No bus transmission or ECU requests.
public sealed record J1939Signal(int Pgn,int Spn,string Name,string Unit,double Value,int SourceAddress);
public static class J1939Decoder {
 public static (int Pgn,int SourceAddress) ParseCanId(uint id) {
  if(id>0x1FFFFFFF)throw new ArgumentOutOfRangeException(nameof(id));
  int pf=(int)((id>>16)&0xFF),ps=(int)((id>>8)&0xFF),dp=(int)((id>>24)&1);
  return ((dp<<16)|(pf<<8)|(pf<240?0:ps),(int)(id&0xFF));
 }
 public static IReadOnlyList<J1939Signal> Decode(uint id,ReadOnlySpan<byte> data) {
  var (pgn,sa)=ParseCanId(id);
  var output=new List<J1939Signal>();
  if(data.Length<8)return output;
  void Add(int spn,string name,string unit,double? value){if(value is double v && double.IsFinite(v))output.Add(new(pgn,spn,name,unit,v,sa));}
  switch(pgn){
   case 61444: // EEC1: engine speed SPN 190, bytes 4-5 (1-based)
    ushort rpmRaw=(ushort)(data[3]|(data[4]<<8));
    Add(190,"Engine speed","rpm",rpmRaw==65535?null:rpmRaw*0.125);
    break;
   case 61443: // EEC2: accelerator pedal position 1, SPN 91, byte 2
    Add(91,"Accelerator pedal position","%",data[1]==255?null:data[1]*0.4);
    break;
   case 65262: // ET1: coolant temp SPN 110, byte 1
    Add(110,"Coolant temperature","°C",data[0]==255?null:data[0]-40.0);
    break;
   case 65263: // EFL/P1: engine oil pressure SPN 100, byte 4
    Add(100,"Engine oil pressure","kPa",data[3]==255?null:data[3]*4.0);
    break;
  }
  return output;
 }
 public static bool TryParseLine(string line,out uint canId,out byte[] payload){
  canId=0;payload=[];
  var parts=line.Trim().Split([' ', '\t', ':'],StringSplitOptions.RemoveEmptyEntries);
  if(parts.Length!=9||parts[0].Length!=8||!uint.TryParse(parts[0],NumberStyles.HexNumber,CultureInfo.InvariantCulture,out canId)||canId>0x1FFFFFFF)return false;
  payload=new byte[8];
  for(int i=0;i<8;i++)if(parts[i+1].Length!=2||!byte.TryParse(parts[i+1],NumberStyles.HexNumber,CultureInfo.InvariantCulture,out payload[i]))return false;
  return true;
 }
}
