using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace BoostechDynoLogger;

// Dependency-free, read-only CSV plotting. Uses the same long-form CSV layout as the logger.
public sealed class CsvViewerWindow : Window
{
    private sealed record Sample(double Time, double Value);
    private readonly Dictionary<string, List<Sample>> series = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, CheckBox> switches = new();
    private readonly Canvas plot = new() { Background = new SolidColorBrush(Color.FromRgb(15, 24, 36)), ClipToBounds = true };
    private readonly StackPanel legend = new() { Margin = new Thickness(10) };
    private readonly TextBlock info = new() { Foreground = Brushes.LightGray, Text = "Open a Boostech logging CSV to begin." };
    private readonly TextBlock cursor = new() { Foreground = Brushes.LightBlue };
    private readonly Slider zoom = new() { Minimum = 1, Maximum = 20, Value = 1, Width = 145, TickFrequency = 1 };
    private readonly Slider offset = new() { Minimum = 0, Maximum = 1, Value = 0, Width = 135 };
    private readonly ComboBox axis = new() { Width = 160, Margin = new Thickness(5) };
    private double totalSeconds;
    private readonly Brush[] colors = { Brushes.DeepSkyBlue, Brushes.Orange, Brushes.LimeGreen, Brushes.Violet, Brushes.Gold, Brushes.Tomato, Brushes.Cyan, Brushes.HotPink, Brushes.LightSteelBlue, Brushes.SandyBrown };

    public CsvViewerWindow(string? initialFile = null)
    {
        Title = "BOOSTECH / CSV ANALYSER — 2.6"; Width = 1240; Height = 780; MinWidth = 850; MinHeight = 520;
        Background = new SolidColorBrush(Color.FromRgb(16, 23, 32)); Foreground = Brushes.White;
        var layout = new DockPanel { Margin = new Thickness(12) }; Content = layout;
        var toolbar = new WrapPanel { Margin = new Thickness(0, 0, 0, 8) };
        DockPanel.SetDock(toolbar, Dock.Top); layout.Children.Add(toolbar);
        var open = new Button { Content = "Open CSV", Padding = new Thickness(15, 7, 15, 7), Margin = new Thickness(3) };
        open.Click += (_, _) => { var d = new OpenFileDialog { Filter = "CSV files|*.csv|All files|*.*" }; if (d.ShowDialog(this) == true) LoadCsv(d.FileName); };
        toolbar.Children.Add(open);
        var png = new Button { Content = "Export chart PNG", Padding = new Thickness(12, 7, 12, 7), Margin = new Thickness(3) };
        png.Click += (_, _) => ExportPng(); toolbar.Children.Add(png);
        toolbar.Children.Add(new TextBlock { Text = "  Zoom", VerticalAlignment = VerticalAlignment.Center }); toolbar.Children.Add(zoom);
        toolbar.Children.Add(new TextBlock { Text = "  Pan", VerticalAlignment = VerticalAlignment.Center }); toolbar.Children.Add(offset);
        toolbar.Children.Add(new TextBlock { Text = "  Scale", VerticalAlignment = VerticalAlignment.Center });
        axis.Items.Add("Individual (normalized)"); axis.Items.Add("Shared raw values"); axis.SelectedIndex = 0; toolbar.Children.Add(axis);
        zoom.ValueChanged += (_, _) => { offset.Value = Math.Min(offset.Value, 1); Draw(); };
        offset.ValueChanged += (_, _) => Draw(); axis.SelectionChanged += (_, _) => Draw();
        var footer = new StackPanel { Margin = new Thickness(4, 8, 4, 0) }; DockPanel.SetDock(footer, Dock.Bottom);
        footer.Children.Add(info); footer.Children.Add(cursor); layout.Children.Add(footer);
        var body = new Grid(); body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(245) });
        body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }); layout.Children.Add(body);
        var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Background = new SolidColorBrush(Color.FromRgb(29, 42, 56)) };
        var side = new StackPanel(); side.Children.Add(new TextBlock { Text = "CHANNELS  ·  toggle visibility", FontWeight = FontWeights.Bold, Margin = new Thickness(10, 12, 5, 6) });
        var all = new Button { Content = "Show all / Hide all", Margin = new Thickness(8, 0, 8, 8) };
        all.Click += (_, _) => { bool show = switches.Values.Any(x => x.IsChecked != true); foreach (var x in switches.Values) x.IsChecked = show; Draw(); };
        side.Children.Add(all); side.Children.Add(legend); scroll.Content = side; body.Children.Add(scroll);
        Grid.SetColumn(plot, 1); body.Children.Add(plot);
        plot.SizeChanged += (_, _) => Draw();
        plot.MouseMove += (_, e) => ShowCursor(e.GetPosition(plot));
        if (!string.IsNullOrWhiteSpace(initialFile) && File.Exists(initialFile)) LoadCsv(initialFile);
    }

    // Supports RFC-style quoted CSV fields (including escaped quotes and embedded newlines).
    private static IEnumerable<string[]> ReadRecords(TextReader reader)
    {
        var field = new StringBuilder(); var record = new List<string>(); bool quoted = false;
        while (true)
        {
            int n = reader.Read();
            if (n < 0) { if (quoted) throw new FormatException("Unterminated quoted CSV field"); if (field.Length > 0 || record.Count > 0) { record.Add(field.ToString()); yield return record.ToArray(); } yield break; }
            char c = (char)n;
            if (c == '"') { if (quoted && reader.Peek() == '"') { reader.Read(); field.Append('"'); } else quoted = !quoted; }
            else if (c == ',' && !quoted) { record.Add(field.ToString()); field.Clear(); }
            else if ((c == '\n' || c == '\r') && !quoted)
            {
                if (c == '\r' && reader.Peek() == '\n') reader.Read();
                record.Add(field.ToString()); field.Clear(); yield return record.ToArray(); record.Clear();
            }
            else field.Append(c);
        }
    }

    private void LoadCsv(string file)
    {
        try
        {
            var loaded = new Dictionary<string, List<Sample>>(StringComparer.OrdinalIgnoreCase);
            int accepted = 0, skipped = 0; double maxTime = 0;
            using var reader = new StreamReader(file);
            using var enumerator = ReadRecords(reader).GetEnumerator();
            if (!enumerator.MoveNext()) throw new FormatException("CSV file is empty");
            var header = enumerator.Current.Select(x => x.Trim().TrimStart('\uFEFF')).ToArray();
            int Index(string name) => Array.FindIndex(header, x => string.Equals(x, name, StringComparison.OrdinalIgnoreCase));
            int t = Index("elapsed_ms"), pid = Index("pid"), parameter = Index("parameter"), value = Index("value"), unit = Index("unit");
            if (t < 0 || value < 0 || (pid < 0 && parameter < 0)) throw new FormatException("Expected Boostech CSV columns: elapsed_ms, pid/parameter, value");
            while (enumerator.MoveNext())
            {
                var fields = enumerator.Current;
                if (fields.Length <= Math.Max(t, Math.Max(value, Math.Max(pid, parameter)))) { skipped++; continue; }
                if (!double.TryParse(fields[t], NumberStyles.Float, CultureInfo.InvariantCulture, out var ms) ||
                    !double.TryParse(fields[value], NumberStyles.Float, CultureInfo.InvariantCulture, out var y) ||
                    !double.IsFinite(ms) || !double.IsFinite(y) || ms < 0) { skipped++; continue; }
                var name = parameter >= 0 && fields[parameter].Length > 0 ? fields[parameter] : fields[pid];
                if (string.IsNullOrWhiteSpace(name)) { skipped++; continue; }
                var suffix = unit >= 0 && unit < fields.Length && fields[unit].Length > 0 ? $" ({fields[unit]})" : "";
                var key = name + suffix;
                if (!loaded.TryGetValue(key, out var samples)) loaded[key] = samples = new List<Sample>();
                samples.Add(new Sample(ms / 1000d, y)); accepted++; maxTime = Math.Max(maxTime, ms / 1000d);
                if (accepted > 1_000_000) throw new InvalidDataException("CSV exceeds the 1,000,000-sample viewer limit");
            }
            if (accepted == 0) throw new FormatException("No valid numeric samples found");
            foreach (var samples in loaded.Values) samples.Sort((a, b) => a.Time.CompareTo(b.Time));
            series.Clear(); switches.Clear(); legend.Children.Clear();
            int color = 0;
            foreach (var (key, samples) in loaded.OrderByDescending(x => x.Value.Count))
            {
                series[key] = samples;
                var check = new CheckBox { Content = key, IsChecked = color < 6, Foreground = colors[color % colors.Length], Margin = new Thickness(5, 6, 3, 6), ToolTip = $"{samples.Count:N0} samples" };
                check.Checked += (_, _) => Draw(); check.Unchecked += (_, _) => Draw();
                legend.Children.Add(check); switches[key] = check; color++;
            }
            totalSeconds = maxTime; zoom.Value = 1; offset.Value = 0;
            info.Text = $"{System.IO.Path.GetFileName(file)}   •   {accepted:N0} samples   •   {series.Count} channels   •   {totalSeconds:F2}s   •   {skipped:N0} skipped rows";
            Draw();
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Could not open CSV", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private (double start, double end) WindowRange()
    {
        double width = Math.Max(totalSeconds / zoom.Value, 0.001);
        double start = (totalSeconds - width) * offset.Value;
        return (start, start + width);
    }

    private void Draw()
    {
        if (plot == null || series == null || switches == null) return;
        plot.Children.Clear(); double w = plot.ActualWidth, h = plot.ActualHeight;
        if (w < 80 || h < 80 || series.Count == 0) return;
        const double left = 62, right = 20, top = 26, bottom = 48;
        double pw = w - left - right, ph = h - top - bottom;
        if (pw <= 0 || ph <= 0) return;
        var (start, end) = WindowRange();
        void Line(double x1, double y1, double x2, double y2, Brush brush, double thickness = 1)
        { plot.Children.Add(new Line { X1 = x1, Y1 = y1, X2 = x2, Y2 = y2, Stroke = brush, StrokeThickness = thickness }); }
        void Label(string text, double x, double y, Brush brush)
        { var block = new TextBlock { Text = text, Foreground = brush, FontSize = 11 }; Canvas.SetLeft(block, x); Canvas.SetTop(block, y); plot.Children.Add(block); }
        var gridBrush = new SolidColorBrush(Color.FromRgb(46, 61, 77));
        for (int i = 0; i <= 5; i++)
        {
            double x = left + i * pw / 5, y = top + i * ph / 5;
            Line(x, top, x, top + ph, gridBrush); Line(left, y, left + pw, y, gridBrush);
            Label($"{start + i * (end - start) / 5:F1}s", x - 12, top + ph + 9, Brushes.LightGray);
        }
        var selected = series.Where(x => switches.TryGetValue(x.Key, out var cb) && cb.IsChecked == true).ToArray();
        bool shared = axis.SelectedIndex == 1;
        var visibleValues = selected.SelectMany(x => x.Value.Where(s => s.Time >= start && s.Time <= end).Select(s => s.Value)).ToArray();
        double sharedMin = visibleValues.Length == 0 ? 0 : visibleValues.Min(), sharedMax = visibleValues.Length == 0 ? 1 : visibleValues.Max();
        if (sharedMax <= sharedMin) sharedMax = sharedMin + 1;
        int idx = 0;
        foreach (var (key, samples) in series)
        {
            var brush = colors[idx++ % colors.Length];
            if (!switches.TryGetValue(key, out var check) || check.IsChecked != true) continue;
            var visible = samples.Where(s => s.Time >= start && s.Time <= end).ToArray();
            if (visible.Length == 0) continue;
            double min = shared ? sharedMin : visible.Min(s => s.Value), max = shared ? sharedMax : visible.Max(s => s.Value);
            if (max <= min) { min -= 0.5; max += 0.5; }
            var geometry = new StreamGeometry();
            using (var ctx = geometry.Open())
            {
                bool first = true;
                // Bound drawing complexity to approximately two points per horizontal pixel.
                int stride = Math.Max(1, visible.Length / Math.Max(1, (int)(pw * 2)));
                for (int i = 0; i < visible.Length; i += stride)
                {
                    var s = visible[i]; var p = new Point(left + (s.Time - start) / (end - start) * pw, top + (max - s.Value) / (max - min) * ph);
                    if (first) { ctx.BeginFigure(p, false, false); first = false; } else ctx.LineTo(p, true, false);
                }
            }
            geometry.Freeze(); plot.Children.Add(new System.Windows.Shapes.Path { Data = geometry, Stroke = brush, StrokeThickness = 1.7, SnapsToDevicePixels = true });
        }
        Label(shared ? $"Shared axis: {sharedMin:F1} – {sharedMax:F1}" : "Per-channel normalized scale (0–100%)", left + 4, 4, Brushes.LightGray);
        Label("Elapsed time (seconds)", left + pw / 2 - 55, h - 18, Brushes.LightGray);
    }

    private void ShowCursor(Point p)
    {
        if (plot.ActualWidth <= 82 || series.Count == 0) return;
        double frac = Math.Clamp((p.X - 62) / (plot.ActualWidth - 82), 0, 1);
        var (start, end) = WindowRange(); double t = start + frac * (end - start);
        var parts = new List<string> { $"Cursor {t:F2}s" };
        foreach (var (key, samples) in series.Where(x => switches.TryGetValue(x.Key, out var cb) && cb.IsChecked == true).Take(6))
        {
            int lo = 0, hi = samples.Count;
            while (lo < hi) { int mid = (lo + hi) / 2; if (samples[mid].Time < t) lo = mid + 1; else hi = mid; }
            int index = Math.Clamp(lo, 0, samples.Count - 1);
            if (index > 0 && Math.Abs(samples[index - 1].Time - t) < Math.Abs(samples[index].Time - t)) index--;
            parts.Add($"{key}: {samples[index].Value:F2}");
        }
        cursor.Text = string.Join("    |    ", parts);
    }

    private void ExportPng()
    {
        if (series.Count == 0) { MessageBox.Show(this, "Open a CSV first."); return; }
        var dlg = new SaveFileDialog { Filter = "PNG image|*.png", FileName = "Boostech_Dyno_Chart.png" };
        if (dlg.ShowDialog(this) != true) return;
        try
        {
            var size = new Size(Math.Max(1, plot.ActualWidth), Math.Max(1, plot.ActualHeight));
            plot.Measure(size); plot.Arrange(new Rect(size));
            var bmp = new System.Windows.Media.Imaging.RenderTargetBitmap((int)Math.Ceiling(size.Width), (int)Math.Ceiling(size.Height), 96, 96, PixelFormats.Pbgra32);
            bmp.Render(plot);
            var encoder = new System.Windows.Media.Imaging.PngBitmapEncoder(); encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(bmp));
            using var stream = File.Create(dlg.FileName); encoder.Save(stream);
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "PNG export failed", MessageBoxButton.OK, MessageBoxImage.Error); }
    }
}
