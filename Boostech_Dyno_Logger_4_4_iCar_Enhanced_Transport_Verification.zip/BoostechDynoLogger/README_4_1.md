# Boostech Dyno Logger 4.1 — iCar Pro 2S CAN/UDS validation preview

- Adds a read-only ELM adapter capability probe (`ATI`, `AT@1`, `ATDP`, `ATDPN`, `ATCAF1`, `ATCFC1`, `ATAL`). A successful reply does not prove every feature works.
- Explicit 11-bit 500 kbps CAN protocol (`ATSP6`), ISO-TP formatting/flow control, receive address filter (`ATCRA`) for experimental UDS DID reads.
- Improved UDS parser supports multi-line reassembled payloads and raw ISO-TP first/consecutive frames with sequence checking.
- Restores automatic protocol and clears response filter after UDS requests. Disconnect/reconnect if a request times out.
- Only read-only ECU identification DIDs are permitted; no arbitrary DIDs, security access or ECU writes.
- Existing standard OBD2, profile matching, parameter coverage, CSV and YourDyno features retained.

**Not universal diagnostics.** 11-bit/500 kbps is only one CAN configuration. Not all iCar Pro 2S adapters support the extended ELM commands. No OEM enhanced parameter decoding, J1939 live transport, KWP measuring blocks, NMEA2000 or universal vehicle coverage is claimed. No Windows build/hardware test was possible here.

To test: Windows/PUBLISH_EXE.bat -> Bluetooth COM -> Connect -> Enhanced ECU identification -> Test iCar Pro 2S. Save/export logs with VIN redacted before sharing.
