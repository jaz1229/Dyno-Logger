using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;

namespace BoostechDynoLogger;

/// <summary>Read-only SAE J2534-1 ISO15765 11-bit CAN 500 kbps transport.
/// This is an initial hardware-test implementation, not a universal J2534 protocol scanner.</summary>
public sealed class J2534CanTransport : IObdTransport {
 const uint ISO15765=6, BAUD=500000, PASS_FILTER=1, FLOW_CONTROL_FILTER=3;
 const uint ERR_TIMEOUT=9, RX_STATUS_TX_MSG_TYPE=0x00000001, ISO15765_FRAME_PAD=0x00000040;
 readonly IntPtr library;
 readonly OpenFn open; readonly CloseFn close; readonly ConnectFn connect; readonly DisconnectFn disconnect;
 readonly ReadFn read; readonly WriteFn write; readonly FilterFn filter;
 readonly SemaphoreSlim gate=new(1,1);
 uint deviceId,channelId; bool disposed;
 [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int OpenFn(IntPtr name,out uint id);
 [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int CloseFn(uint id);
 [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int ConnectFn(uint id,uint protocol,uint flags,uint baud,out uint channel);
 [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int DisconnectFn(uint channel);
 [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int ReadFn(uint channel,[In,Out] IntPtr messages,ref uint count,uint timeout);
 [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int WriteFn(uint channel,[In,Out] IntPtr messages,ref uint count,uint timeout);
 [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int FilterFn(uint channel,uint filterType,IntPtr mask,IntPtr pattern,IntPtr flow,out uint filterId);
 [StructLayout(LayoutKind.Sequential)] struct PassThruMsg {
  public uint ProtocolID, RxStatus, TxFlags, Timestamp, DataSize, ExtraDataIndex;
  [MarshalAs(UnmanagedType.ByValArray,SizeConst=4128)] public byte[] Data;
 }
 static PassThruMsg Msg(byte[] data)=>new(){ProtocolID=ISO15765,DataSize=(uint)data.Length,Data=Fill(data)};
 static byte[] Fill(byte[] data){var b=new byte[4128];Array.Copy(data,b,data.Length);return b;}
 static IntPtr Alloc(PassThruMsg msg){var p=Marshal.AllocHGlobal(Marshal.SizeOf<PassThruMsg>());Marshal.StructureToPtr(msg,p,false);return p;}
 static void Check(int result,string op){if(result!=0)throw new IOException($"J2534 {op} failed (error {result}).");}
 T Fn<T>(string name) where T:Delegate=>Marshal.GetDelegateForFunctionPointer<T>(NativeLibrary.GetExport(library,name));
 public J2534CanTransport(string dllPath){
  if(!File.Exists(dllPath))throw new FileNotFoundException("J2534 driver DLL missing",dllPath);
  // Openport 2.0 drivers commonly use 32-bit J2534 DLLs; match the process architecture.
  library=NativeLibrary.Load(dllPath);
  try{
   open=Fn<OpenFn>("PassThruOpen");close=Fn<CloseFn>("PassThruClose");
   connect=Fn<ConnectFn>("PassThruConnect");disconnect=Fn<DisconnectFn>("PassThruDisconnect");
   read=Fn<ReadFn>("PassThruReadMsgs");write=Fn<WriteFn>("PassThruWriteMsgs");filter=Fn<FilterFn>("PassThruStartMsgFilter");
   Check(open(IntPtr.Zero,out deviceId),"Open");
   Check(connect(deviceId,ISO15765,0,BAUD,out channelId),"Connect ISO15765 11-bit 500k");
   // Accept only the conventional 11-bit OBD engine ECU response ID 0x7E8.
   AddFilter(PASS_FILTER,0x7FF,0x7E8,null);
   // J2534 ISO15765 flow control for multi-frame responses from 0x7E8.
   AddFilter(FLOW_CONTROL_FILTER,0x7FF,0x7E8,0x7E0);
  }catch{Dispose();throw;}
 }
 void AddFilter(uint kind,uint mask,uint pattern,uint? flowId){
  IntPtr a=IntPtr.Zero,b=IntPtr.Zero,c=IntPtr.Zero;
  try{
   a=Alloc(Msg(CanId(mask)));b=Alloc(Msg(CanId(pattern)));
   if(flowId.HasValue)c=Alloc(Msg(CanId(flowId.Value)));
   Check(filter(channelId,kind,a,b,c,out _),"StartMsgFilter");
  }finally{if(a!=IntPtr.Zero)Marshal.FreeHGlobal(a);if(b!=IntPtr.Zero)Marshal.FreeHGlobal(b);if(c!=IntPtr.Zero)Marshal.FreeHGlobal(c);}
 }
 static byte[] CanId(uint id)=>[(byte)(id>>24),(byte)(id>>16),(byte)(id>>8),(byte)id];
 public async Task<string> RequestAsync(string command,CancellationToken ct){
  await gate.WaitAsync(ct);
  try{return await Task.Run(()=>Request(command,ct),ct);}finally{gate.Release();}
 }
 string Request(string command,CancellationToken ct){
  if(disposed)throw new ObjectDisposedException(nameof(J2534CanTransport));
  command=command.Trim().ToUpperInvariant();
  if(command.StartsWith("AT"))return command=="ATDP"?"ISO 15765-4 CAN (11 bit ID, 500 kbaud)":"OK";
  if(command.Length%2!=0||command.Length<2||!command.All(Uri.IsHexDigit))return "?";
  var request=Convert.FromHexString(command);
  if(!new byte[]{0x01,0x02,0x03,0x07,0x09,0x0A}.Contains(request[0]))return "BLOCKED: read-only diagnostic modes only";
  if(request.Length>7)return "BLOCKED: request too long";
  // Physical address 0x7E0 to match the configured ECU 0x7E8 response filter.
  var tx=Msg([..CanId(0x7E0),..request]); tx.TxFlags=ISO15765_FRAME_PAD;
  var p=Alloc(tx);
  try{uint count=1;Check(write(channelId,p,ref count,1000),"WriteMsgs");if(count!=1)throw new IOException("J2534 transmitted no message");}
  finally{Marshal.FreeHGlobal(p);}
  var deadline=System.Diagnostics.Stopwatch.StartNew();
  while(deadline.ElapsedMilliseconds<1600){
   ct.ThrowIfCancellationRequested();
   p=Alloc(Msg([]));
   try{
    uint count=1;int status=read(channelId,p,ref count,150);
    if(status==ERR_TIMEOUT||count==0)continue;
    Check(status,"ReadMsgs");
    var msg=Marshal.PtrToStructure<PassThruMsg>(p);
    if(msg.DataSize<6||msg.DataSize>4128)continue;
    if(msg.RxStatus==RX_STATUS_TX_MSG_TYPE)continue;
    var bytes=msg.Data.Take((int)msg.DataSize).ToArray();
    uint id=((uint)bytes[0]<<24)|((uint)bytes[1]<<16)|((uint)bytes[2]<<8)|bytes[3];
    if(id!=0x7E8)continue;
    var payload=bytes.Skip(4).ToArray();
    if(payload.Length==0)continue;
    if(payload[0]==0x7F)return "NEGATIVE RESPONSE "+Convert.ToHexString(payload);
    if(payload[0]!=(byte)(request[0]+0x40))continue;
    if(request.Length>1 && payload.Length>1 && payload[1]!=request[1])continue;
    return string.Join(" ",payload.Select(x=>x.ToString("X2",CultureInfo.InvariantCulture)));
   }finally{Marshal.FreeHGlobal(p);}
  }
  return "NO DATA";
 }
 public void Dispose(){if(disposed)return;disposed=true;
  if(channelId!=0){try{disconnect(channelId);}catch{}channelId=0;}
  if(deviceId!=0){try{close(deviceId);}catch{}deviceId=0;}
  if(library!=IntPtr.Zero)NativeLibrary.Free(library);
 }
}
