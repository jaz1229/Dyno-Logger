using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
namespace BoostechDynoLogger;
public sealed class ChannelRow { public string Pid {get;set;}=""; public string Name {get;set;}=""; public string Value {get;set;}="—"; public string Updated {get;set;}="—"; public bool Selected {get;set;}=true; }
public partial class MainWindow : Window {
 private IObdTransport? transport;
 private CancellationTokenSource? logging;
 private readonly ObservableCollection<ChannelRow> rows=new();
 private readonly List<object> events=new();
 private readonly List<string> csv=new();
 private readonly object eventGate=new();
 private bool busy;
 private static readonly string[] FastPids={"0C","11","0B","05","0F","0E","04","42","23","44"};
 public MainWindow(){InitializeComponent();Channels.ItemsSource=rows;Adapter.SelectedIndex=0;RefreshPorts();SetCategory();Closed+=(_,_)=>{logging?.Cancel();transport?.Dispose();};}
 private void RefreshPorts(){string previous=Port.SelectedItem?.ToString()??"COM11";Port.Items.Clear();foreach(var name in SerialPort.GetPortNames().OrderBy(x=>x))Port.Items.Add(name);if(Port.Items.Contains(previous))Port.SelectedItem=previous;else if(Port.Items.Count>0)Port.SelectedIndex=0;}
 private void Refresh_Click(object s,RoutedEventArgs e)=>RefreshPorts();
 private void Category_Changed(object s,SelectionChangedEventArgs e){if(Make is not null && Coverage is not null)SetCategory();}
 private void SetCategory(){string category=(Category.SelectedItem as ComboBoxItem)?.Content?.ToString()??"Car / Van";string[] makes=category switch {"Motorcycle"=>["Honda","Yamaha","Kawasaki","Suzuki","BMW Motorrad","Ducati","KTM","Triumph","Harley-Davidson"],"Marine"=>["Yamaha Marine","Mercury","Suzuki Marine","Honda Marine","Sea-Doo","Volvo Penta","Cummins"],"Agricultural"=>["John Deere","New Holland","Case IH","Fendt","Massey Ferguson","Kubota"],"Heavy truck"=>["Volvo","Scania","DAF","MAN","Mercedes-Benz","Isuzu","Hino"],_=>["Volkswagen","Audi","BMW","Mercedes-Benz","Toyota","Ford","Holden","Honda","Hyundai","Nissan","Mazda","Subaru","Mitsubishi","Peugeot","Renault","Volvo"]};Make.Items.Clear();foreach(var m in makes)Make.Items.Add(m);Make.SelectedIndex=0;Coverage.Text=CoverageText(category);}
 private static string CoverageText(string c)=>c switch {"Motorcycle"=>"Motorcycles: SAE OBD2 on supported newer models through a compatible diagnostic connector. Many older bikes use manufacturer-specific connectors and protocols; those require a validated adapter and ECU profile. No universal bike PID coverage is claimed.","Marine"=>"Marine: standard OBD2 only on compatible engines. NMEA 2000 (250 kbit/s CAN with PGNs) and proprietary engine networks need dedicated, correctly isolated hardware and a verified live decoder; not enabled in this build.","Heavy truck" or "Agricultural"=>"Heavy-duty/agricultural: SAE J1939 29-bit CAN decoding is available for imported traces. Live J1939 transport is not enabled; use suitable 250/500 kbit/s CAN hardware and validated SPN/PGN definitions.",_=>"Cars/vans: live standard SAE Mode 01 OBD2 over ELM327 Bluetooth, with supported PID discovery. ECU-specific VW TP2.0/KWP2000 and UDS enhanced logging require validated raw CAN transport and verified ECU definitions; not enabled in this release."};
 private void Record(string cmd,string response,long ms){lock(eventGate)events.Add(new {utc=DateTimeOffset.UtcNow,command=cmd,response,elapsedMs=ms});Dispatcher.Invoke(()=>{Trace.AppendText($"{DateTime.Now:HH:mm:ss} {cmd} [{ms}ms] {response.Trim().Replace('\r',' ')}\n");Trace.ScrollToEnd();});}
 private async Task<string> Request(string cmd,CancellationToken ct){var sw=System.Diagnostics.Stopwatch.StartNew();try{string raw=await transport!.RequestAsync(cmd,ct);Record(cmd,raw,sw.ElapsedMilliseconds);return raw;}catch(Exception ex){Record(cmd,"ERROR: "+ex.Message,sw.ElapsedMilliseconds);throw;}}
 private async void Connect_Click(object s,RoutedEventArgs e){if(busy||transport is not null)return;busy=true;Connect.IsEnabled=false;try{transport=Adapter.SelectedIndex==1?new SimulatorTransport():new SerialElmTransport(Port.SelectedItem?.ToString()??throw new InvalidOperationException("Select a COM port."));using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(15));foreach(var cmd in new[]{"ATZ","ATE0","ATL0","ATS1","ATH0","ATSP0"})await Request(cmd,timeout.Token);ConnectionStatus.Text="Connected · "+(Adapter.SelectedIndex==1?"SIMULATION":"ELM Bluetooth");Disconnect.IsEnabled=true;Discover.IsEnabled=true;RunStatus.Text="Discover supported channels before logging";}catch(Exception ex){transport?.Dispose();transport=null;MessageBox.Show(ex.Message,"Connection failed");Connect.IsEnabled=true;}finally{busy=false;}}
 private void Disconnect_Click(object s,RoutedEventArgs e){logging?.Cancel();logging=null;transport?.Dispose();transport=null;Connect.IsEnabled=true;Disconnect.IsEnabled=false;Discover.IsEnabled=false;Start.IsEnabled=false;Stop.IsEnabled=false;ConnectionStatus.Text="Offline";}
 private async void Discover_Click(object s,RoutedEventArgs e){
  if(transport is null||busy)return;
  busy=true;Discover.IsEnabled=false;RunStatus.Text="Discovering ECU-supported PIDs…";
  try{
   using var cts=new CancellationTokenSource(TimeSpan.FromSeconds(90));
   var advertised=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
   bool first=true;
   foreach(var start in new[]{"00","20","40","60","80","A0","C0","E0"}){
    if(!first&&!advertised.Contains(start))break;
    first=false;
    var raw=await Request("01"+start,cts.Token);
    if(Pids.Extract(raw,start) is not {Length: >=4})break;
    advertised.UnionWith(Pids.DecodeSupported(raw,start));
   }
   rows.Clear();int verified=0;
   foreach(var def in Pids.All.Where(p=>advertised.Contains(p.Id)).GroupBy(p=>p.Id).Select(g=>g.First()).OrderBy(p=>p.Name)){
    var raw=await Request("01"+def.Id,cts.Token);
    var bytes=Pids.Extract(raw,def.Id);
    if(bytes is null||def.Decode(bytes) is not double value||!double.IsFinite(value))continue;
    rows.Add(new ChannelRow{Pid=def.Id,Name=def.Name,Value=value.ToString("0.###",CultureInfo.InvariantCulture)+" "+def.Unit,Updated=DateTime.UtcNow.ToString("HH:mm:ss.fff")});
    verified++;
   }
   RunStatus.Text=$"{verified} verified live OBD2 channels · select channels to log";
   Start.IsEnabled=verified>0;
  }catch(Exception ex){RunStatus.Text="Discovery interrupted: "+ex.Message;}
  finally{busy=false;Discover.IsEnabled=transport is not null;}
 }
 private void SelectEssentials_Click(object s,RoutedEventArgs e){
  var essential=new HashSet<string>(new[]{"0C","11","0B","05","0F","0E","04","42","23","44","06","07","08","09","10","0A","22","24","34","43","46","49","4A","4C","5C","59","33","0D","5E"});
  foreach(var row in rows)row.Selected=essential.Contains(row.Pid);
  Channels.Items.Refresh();RunStatus.Text=$"{rows.Count(r=>r.Selected)} verified essential channels selected";
 }
 private void SelectAll_Click(object s,RoutedEventArgs e){foreach(var row in rows)row.Selected=true;Channels.Items.Refresh();}
 private void ShowRequired_Click(object s,RoutedEventArgs e){
  string[] standard={"Engine RPM|0C","Throttle position|11","Ignition timing|0E","Calculated engine load|04","MAP (absolute)|0B","Intake air temperature|0F","Coolant temperature|05","MAF|10","Fuel trims B1|06,07","Fuel trims B2|08,09","Fuel rail pressure|22,23,59","Lambda / equivalence ratio|24,34,44","Oil temperature|5C","Barometric pressure|33","Vehicle speed|0D"};
  string[] enhanced={"Knock retard per cylinder","Requested boost pressure","Wastegate/N75 duty cycle","Actual turbo shaft speed","Requested/actual high-pressure fuel target","Injector pulse width/duty","Camshaft requested/actual","Torque intervention","EGT per sensor","Transmission clutch slip/temperature"};
  var lines=new List<string>{"STANDARD OBD2 — VERIFIED ONLY WHEN ECU RESPONDS:"};
  foreach(var entry in standard){var parts=entry.Split('|');var ids=parts[1].Split(',');lines.Add($"{(ids.Any(id=>rows.Any(r=>r.Pid==id))?"AVAILABLE":"NOT VERIFIED"),-14} {parts[0]} ({parts[1]})");}
  lines.Add("\nOEM ENHANCED — REQUIRES VERIFIED ECU-SPECIFIC PROTOCOL/DEFINITIONS:");
  lines.AddRange(enhanced.Select(x=>"NOT IMPLEMENTED  "+x));
  lines.Add("\nBoost gauge pressure = MAP minus barometric pressure when both are valid; no inferred requested boost or knock values.");
  MessageBox.Show(string.Join("\n",lines),"Dyno essential parameter coverage");
 }
 private async void Start_Click(object s,RoutedEventArgs e){if(transport is null||logging is not null||!rows.Any(r=>r.Selected))return;logging=new CancellationTokenSource();Start.IsEnabled=false;Discover.IsEnabled=false;Stop.IsEnabled=true;RunStatus.Text="Recording selected verified channels · ECU-reported";csv.Clear();csv.Add("utc,elapsed_ms,vehicle_type,make,model,year,run,pid,parameter,value,unit,raw_response");var token=logging.Token;var started=System.Diagnostics.Stopwatch.StartNew();try{while(!token.IsCancellationRequested){foreach(var row in rows.Where(r=>r.Selected).OrderBy(r=>Array.IndexOf(FastPids,r.Pid)<0?999:Array.IndexOf(FastPids,r.Pid))){token.ThrowIfCancellationRequested();var def=Pids.All.First(p=>p.Id==row.Pid);string raw=await Request("01"+row.Pid,token);byte[]? payload=Pids.Extract(raw,row.Pid);double? val=payload is null?null:def.Decode(payload);if(val is null||double.IsNaN(val.Value)||double.IsInfinity(val.Value)){row.Value="—";continue;}string stamp=DateTimeOffset.UtcNow.ToString("O");row.Value=val.Value.ToString("0.###",CultureInfo.InvariantCulture)+" "+def.Unit;row.Updated=DateTime.UtcNow.ToString("HH:mm:ss.fff");Channels.Items.Refresh();if(row.Pid=="0C")Rpm.Text=row.Value;if(row.Pid=="11")Throttle.Text=row.Value;if(row.Pid=="05")Coolant.Text=row.Value;if(row.Pid=="0B")Map.Text=row.Value;csv.Add(string.Join(",",new[]{stamp,started.ElapsedMilliseconds.ToString(),Csv((Category.SelectedItem as ComboBoxItem)?.Content?.ToString()??""),Csv(Make.Text),Csv(Model.Text),Csv(Year.Text),Csv(RunId.Text),row.Pid,Csv(row.Name),val.Value.ToString("0.###",CultureInfo.InvariantCulture),Csv(def.Unit),Csv(raw)}));}await Task.Delay(10,token);}}catch(OperationCanceledException){}catch(Exception ex){RunStatus.Text="Logging stopped: "+ex.Message;}finally{logging?.Dispose();logging=null;Stop.IsEnabled=false;Start.IsEnabled=transport is not null&&rows.Count>0;Discover.IsEnabled=transport is not null;RunStatus.Text=$"Stopped · {Math.Max(0,csv.Count-1)} samples captured";SaveCsv();}}
 private static string Csv(string s)=>"\""+s.Replace("\"","\"\"").Replace("\r"," ").Replace("\n"," ")+"\"";
 private void Stop_Click(object s,RoutedEventArgs e)=>logging?.Cancel();
 private void SaveCsv(){if(csv.Count<2)return;var dlg=new SaveFileDialog{Filter="CSV files|*.csv",FileName="Boostech_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".csv"};if(dlg.ShowDialog()==true){File.WriteAllLines(dlg.FileName,csv,Encoding.UTF8);RunStatus.Text=$"Saved {csv.Count-1} samples · {dlg.FileName}";}}
 private void ExportTrace_Click(object s,RoutedEventArgs e){var dlg=new SaveFileDialog{Filter="JSON files|*.json",FileName="Boostech_Trace_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".json"};if(dlg.ShowDialog()==true){object[] snapshot;lock(eventGate)snapshot=events.ToArray();File.WriteAllText(dlg.FileName,JsonSerializer.Serialize(new{schema="boostech-v5-trace",generatedUtc=DateTimeOffset.UtcNow,adapter=Adapter.Text,events=snapshot},new JsonSerializerOptions{WriteIndented=true}));}}
 private void ImportJ1939_Click(object s,RoutedEventArgs e){var dlg=new OpenFileDialog{Filter="CAN traces|*.txt;*.log;*.csv|All files|*.*"};if(dlg.ShowDialog()!=true)return;var data=new List<object>();foreach(string line in File.ReadLines(dlg.FileName)){var tokens=System.Text.RegularExpressions.Regex.Matches(line,@"(?i)\b[0-9a-f]{2,8}\b").Select(m=>m.Value).ToArray();if(tokens.Length<2||tokens[0].Length!=8)continue;uint id=Convert.ToUInt32(tokens[0],16);if((id&0xE0000000)!=0)continue;uint pgn=((id>>8)&0x3FFFF);if((pgn&0xFF00)<0xF000)pgn&=0x3FF00;data.Add(new{CanId=id.ToString("X8"),Pgn=pgn,Source=(byte)id,Payload=string.Join(" ",tokens.Skip(1).Take(8))});if(data.Count>=50000)break;}J1939.ItemsSource=data;RunStatus.Text=$"Imported {data.Count} J1939 candidate frames · offline only";}
}
