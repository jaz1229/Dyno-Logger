# Boostech Dyno Logger 3.0 — Grouped channel browser

New hierarchical channel tree: source (YourDyno / Log) → loaded file/run → category → individual toggleable channel. Spark, ignition, timing, knock, coil and dwell parameters are grouped under Spark & Ignition. Other categories include Power & Torque, Fuel & AFR, Boost & Pressure, Temperatures, Engine & Speed, Dyno & Load, Environment and Other Channels.

Channel search filters the tree and expands matching branches without changing selected graph traces. Show All / Hide All still operate across all loaded channels. CSV/dyno RPM alignment and plotting logic are unchanged.

Build on Windows with Windows/PUBLISH_EXE.bat. Compilation has not been verified in this environment.
