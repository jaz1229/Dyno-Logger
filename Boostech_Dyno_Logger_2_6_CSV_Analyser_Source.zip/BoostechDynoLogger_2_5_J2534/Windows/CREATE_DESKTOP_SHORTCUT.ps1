$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$app = Join-Path $root 'bin\Release\net10.0-windows\win-x64\publish\BoostechDynoLogger.exe'
if (!(Test-Path $app)) { Write-Host 'Run START_HERE.bat first to build the application.'; Read-Host 'Press Enter'; exit 1 }
$desktop = [Environment]::GetFolderPath('Desktop')
$shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desktop 'Boostech Dyno Logger.lnk'))
$shortcut.TargetPath = $app
$shortcut.WorkingDirectory = Split-Path $app
$shortcut.Description = 'Boostech motorcycle ECU logging prototype'
$shortcut.Save()
Write-Host 'Desktop shortcut created.'
