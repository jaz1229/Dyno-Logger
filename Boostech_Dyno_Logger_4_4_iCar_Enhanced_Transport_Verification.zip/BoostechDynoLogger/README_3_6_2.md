# 3.6.2 — Layout repair

- The channel list and diagnostic console are now separate tabs, with **Live channels** selected by default. This removes the 50/50 vertical split that crushed the grid.
- Vehicle/customer fields are in a collapsed expander; ECU identification details are in another collapsed expander. Connection and logging controls remain visible.
- All original XAML control names and event handlers retained.
- Enlarged default window and minimum size.
- No diagnostic logic or ECU requests changed.

Build on Windows using `Windows/PUBLISH_EXE.bat`. The source is XML-validated and event-handler-checked, but Windows compilation is not available here.
