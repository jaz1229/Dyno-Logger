# RPM-aligned YourDyno / ECU CSV preview

Open a YourDyno file and an ECU CSV in the same analyser window. Each file remains as a separate run, and every channel is toggleable. Select **Engine RPM (aligned)** for the X-axis. Engine RPM is interpolated at each channel timestamp, so staggered PID samples are plotted at the correct engine speed. The graph is limited to the intersection of the runs' RPM ranges; it never extrapolates.

**Important:** This is RPM-based curve comparison, not timestamp synchronization. It is suitable for comparing power/torque and ECU readings at the same RPM in a steady acceleration pull. It does not prove that samples happened at the same real-world moment. If RPM falls/reverses during a run, first-sweep selection is basic and may require manually selecting the pull interval in a later version. Source RPM must be actual engine RPM; roller/dyno RPM is not substituted. CSV must include a recognized engine RPM channel. YourDyno raw channel filtering is not matched to UnaVision yet.

Run Windows/PUBLISH_EXE.bat to build. No Windows .NET compiler or hardware validation was available in this environment.
