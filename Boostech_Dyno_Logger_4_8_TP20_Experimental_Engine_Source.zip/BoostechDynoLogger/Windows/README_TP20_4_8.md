# v4.8 Experimental VW TP2.0 protocol engine

Added `VwTp20Session.cs`: raw CAN transport interface, channel setup, parameter exchange, segmented KWP payload exchange, acknowledgements, sequence checking, timeout handling, channel closure, and KWP measuring-block request/response validation.

**Not a working live adapter integration.** The Vgate iCar Pro 2S has not demonstrated the required raw CAN receive/transmit capability. The engine is intentionally NOT connected to the existing UI, and no raw TP2.0 channel-setup messages are transmitted by the current application. A tested `IVwRawCan` adapter implementation, hardware validation, session timing tuning, and ECU-specific measuring-block decoding are still required. The engine has not been compiled or tested against a real ECU; packet details must be verified against hardware traces before use.

Do not use these experimental protocol routines during a dyno pull. Existing OBD2 features remain unchanged.
