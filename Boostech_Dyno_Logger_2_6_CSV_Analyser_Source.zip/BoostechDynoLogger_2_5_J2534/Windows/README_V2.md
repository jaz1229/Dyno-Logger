# Boostech Dyno Logger 2.0 — Windows source and one-click EXE publisher

1. Extract this ZIP on a Windows x64 computer.
2. Install the .NET 10 SDK from https://dotnet.microsoft.com/download/dotnet/10.0 (first build only).
3. Double-click RUN_OR_BUILD.bat. The first launch downloads dependencies and publishes Release/BoostechDynoLogger.exe. Later launches open the EXE directly.
4. Copy the entire Release folder to another Windows x64 machine if desired; it is self-contained.

## Features
- Simulator without bike; Bluetooth COM via ELM327-style serial adapter; BLE GATT not yet supported.
- Standard OBD Mode 01 supported-PID discovery, read-only requests, live RPM/TPS/coolant/MAP.
- Customer, motorcycle and run metadata in timestamped CSV output.
- Optional faster polling of RPM, TPS and MAP only; actual rate varies.
- Raw diagnostic console and console export.

## Limitations
- This is a Windows source project, not a precompiled or hardware-tested executable. Run publisher on Windows to create EXE.
- Honda 2023 CBR650R PID compatibility is unverified until the six-pin adapter arrives.
- Only classic Bluetooth serial COM supported. BLE-only models require a separate transport.
- No ECU flashing, no proprietary Honda PIDs, no AFR wideband or live YourDyno integration.
- CSV uses one row per PID sample; values are NOT simultaneous.
- Simulator output is fabricated test data and must not be used for tuning.
- Check cable pinout before use; test with bike stationary before dyno operation.
