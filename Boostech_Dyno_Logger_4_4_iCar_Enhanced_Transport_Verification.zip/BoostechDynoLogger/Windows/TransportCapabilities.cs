namespace BoostechDynoLogger;
public sealed record TransportCapability(string Name,bool StandardObd,bool Uds,bool Kwp,bool J1939,bool Nmea2000,string Note);
public static class TransportCapabilities {
 public static TransportCapability ForMode(int selectedIndex,string? adapterName=null) => selectedIndex switch {
  0=>new("Simulator",true,false,false,false,false,"Simulated standard OBD only"),
  1=>new("Serial ELM/vLinker",true,false,false,false,false,"Standard OBD is implemented; enhanced UDS/KWP/J1939 are not implemented or validated. Model-specific hardware capabilities must be checked."),
  2=>new("J2534",false,false,false,false,false,"Driver discovery/opening exists, but end-to-end diagnostics are not verified."),
  _=>new("Unknown",false,false,false,false,false,"No validated transport")
 };
}
