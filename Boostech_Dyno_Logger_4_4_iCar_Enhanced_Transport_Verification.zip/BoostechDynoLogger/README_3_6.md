# Boostech Dyno Logger 3.6 — Diagnostic validation preview

## Changes
- Hardened standard Mode 01 ELM response extraction for compact/spaced replies, optional 11-bit/29-bit headers, and single-frame ISO-TP PCI.
- Rejects unrelated, malformed, echoed, and error responses instead of interpreting them as PID data.
- **Export diagnostics** button: writes a JSON snapshot of selected adapter, manually selected vehicle, ECU identity (if obtained), verified standard PIDs, latest values, observed polling errors, and logging state.
- Connection-health strip says `sampling idle` when no logging is active, avoiding a misleading 0.0 samples/s claim.

## Validation and safety
- The exported diagnostic JSON can include VIN, customer-adjacent vehicle details, calibration IDs and adapter information. Review/redact before sharing publicly.
- No new proprietary ECU diagnostic commands are issued. No ECU writes.
- Manufacturer database remains reference-only unless real-world verified.
- **Not build-verified**: this environment lacks the Windows .NET 10 SDK and the user's Bluetooth/J2534 hardware.
- Use Windows/PUBLISH_EXE.bat on a Windows machine with .NET 10 SDK, then test simulator and read-only ECU operations before any dyno pull.
- ECU identification parser and protocol-specific enhanced data still need real hardware validation.
