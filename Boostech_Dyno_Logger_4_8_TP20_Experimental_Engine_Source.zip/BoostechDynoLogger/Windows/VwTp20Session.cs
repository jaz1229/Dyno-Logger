using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace BoostechDynoLogger;

/// <summary>Raw CAN access is required. An ELM AT-command port is NOT automatically a raw CAN transport.</summary>
public interface IVwRawCan : IAsyncDisposable {
 Task SendAsync(Can11Frame frame, CancellationToken cancellationToken);
 Task<Can11Frame?> ReceiveAsync(TimeSpan timeout, CancellationToken cancellationToken);
}

public sealed class VwTp20ProtocolException : Exception {
 public VwTp20ProtocolException(string message) : base(message) { }
}

/// <summary>
/// Experimental TP2.0 state machine for controlled bench tests.
/// Channel negotiation, parameter exchange, TP2.0 packet acknowledgement and
/// segmented message exchange are implemented against an abstract raw CAN link.
/// Not validated on the target ECU; no claim of supported measuring groups.
/// </summary>
public sealed class VwTp20Session : IAsyncDisposable {
 readonly IVwRawCan can;
 readonly SemaphoreSlim mutex = new(1,1);
 ushort txId, rxId;
 byte txSequence;
 bool opened;
 public TimeSpan ResponseTimeout { get; set; } = TimeSpan.FromMilliseconds(800);
 public bool IsOpen => opened;
 public VwTp20Session(IVwRawCan can) => this.can=can;

 async Task<Can11Frame> WaitForAsync(ushort id, CancellationToken ct) {
  var sw=Stopwatch.StartNew();
  while(sw.Elapsed<ResponseTimeout){
   var remaining=ResponseTimeout-sw.Elapsed;
   var frame=await can.ReceiveAsync(remaining,ct);
   if(frame is null)break;
   if(frame.Value.Id==id)return frame.Value;
  }
  throw new TimeoutException($"No TP2.0 response on CAN 0x{id:X3}");
 }

 public async Task OpenAsync(byte module, CancellationToken ct=default) {
  await mutex.WaitAsync(ct);
  try {
   if(opened)throw new InvalidOperationException("TP2.0 session already open");
   await can.SendAsync(VwTp20.ChannelSetupRequest(module),ct);
   var response=await WaitForAsync(0x200,ct);
   var d=response.Data;
   if(d.Length<7||d[0]!=module||d[1]!=0xD0)throw new VwTp20ProtocolException("TP2.0 channel setup not accepted");
   // In the D0 response, the 12-bit receive and transmit CAN IDs are little endian.
   rxId=(ushort)(d[2]|((d[3]&0x0F)<<8));
   txId=(ushort)(d[4]|((d[5]&0x0F)<<8));
   if(rxId==0||txId==0||rxId>0x7FF||txId>0x7FF)throw new VwTp20ProtocolException("Invalid negotiated CAN IDs");
   // A1 = connection parameters request. ECU returns A1 with negotiated timing.
   await can.SendAsync(new Can11Frame(txId,new byte[]{0xA0,0x0F,0x8A,0xFF,0x32,0xFF}),ct);
   var parameters=await WaitForAsync(rxId,ct);
   if(parameters.Data.Length<1||parameters.Data[0]!=0xA1)throw new VwTp20ProtocolException("TP2.0 parameter exchange failed");
   txSequence=0;opened=true;
  } finally {mutex.Release();}
 }

 /// <summary>Exchange a KWP2000 payload through the negotiated TP2.0 channel.</summary>
 public async Task<byte[]> ExchangeAsync(ReadOnlyMemory<byte> kwp, CancellationToken ct=default) {
  if(kwp.Length==0||kwp.Length>240)throw new ArgumentOutOfRangeException(nameof(kwp));
  await mutex.WaitAsync(ct);
  try {
   if(!opened)throw new InvalidOperationException("TP2.0 channel not open");
   // TP2.0 carries a 2-byte KWP length before the KWP message.
   var message=new byte[kwp.Length+2];message[0]=(byte)(kwp.Length>>8);message[1]=(byte)kwp.Length;
   kwp.CopyTo(message.AsMemory(2));
   int offset=0;
   while(offset<message.Length){
    int count=Math.Min(7,message.Length-offset);
    bool last=offset+count==message.Length;
    var payload=new byte[count+1];
    payload[0]=(byte)((last?0x10:0x00)|(txSequence&0x0F));
    Array.Copy(message,offset,payload,1,count);
    await can.SendAsync(new Can11Frame(txId,payload),ct);
    txSequence=(byte)((txSequence+1)&0x0F);offset+=count;
    // Intermediate packets require acknowledgement; final packet can be
    // followed by the ECU response directly.
    if(!last){
     var ack=await WaitForAsync(rxId,ct);
     if(ack.Data.Length==0||(ack.Data[0]&0xF0)!=0xB0)throw new VwTp20ProtocolException("TP2.0 packet acknowledgement missing");
    }
   }
   var buffer=new List<byte>();int expected=-1;byte? previous=null;
   for(int i=0;i<64;i++){
    var frame=await WaitForAsync(rxId,ct);var d=frame.Data;
    if(d.Length==0)throw new VwTp20ProtocolException("Empty TP2.0 response frame");
    byte kind=(byte)(d[0]&0xF0);
    if(kind==0xA0)continue; // channel control, not payload
    if(kind!=0x00&&kind!=0x10&&kind!=0x20)throw new VwTp20ProtocolException($"Unexpected TP2.0 packet type 0x{d[0]:X2}");
    var seq=(byte)(d[0]&0x0F);
    if(previous.HasValue&&seq!=((previous.Value+1)&0x0F))throw new VwTp20ProtocolException("TP2.0 response sequence mismatch");
    previous=seq;
    buffer.AddRange(d.Skip(1));
    if(expected<0&&buffer.Count>=2){expected=(buffer[0]<<8)|buffer[1];if(expected>4096)throw new VwTp20ProtocolException("Oversized KWP response");}
    if(kind==0x10){
     if(expected<0||buffer.Count-2<expected)throw new VwTp20ProtocolException("Truncated KWP response");
     return buffer.Skip(2).Take(expected).ToArray();
    }
    await can.SendAsync(new Can11Frame(txId,new byte[]{(byte)(0xB0|((seq+1)&0x0F))}),ct);
   }
   throw new VwTp20ProtocolException("TP2.0 response exceeded packet limit");
  } finally {mutex.Release();}
 }

 public async Task CloseAsync(CancellationToken ct=default){
  await mutex.WaitAsync(ct);
  try {if(opened){await can.SendAsync(new Can11Frame(txId,new byte[]{0xA8}),ct);opened=false;}}
  finally{mutex.Release();}
 }
 public async ValueTask DisposeAsync(){
  try{await CloseAsync();}catch{ /* best effort cleanup */ }
  mutex.Dispose();await can.DisposeAsync();
 }
}

public static class VwKwpMeasuringBlocks {
 /// <summary>Read measuring block group; requires an established KWP session.</summary>
 public static byte[] ReadGroupRequest(byte group) => new byte[]{0x21,group};
 public static byte[] ReadGroupResponse(byte group,byte[] payload){
  if(payload.Length>=3&&payload[0]==0x7F)throw new VwTp20ProtocolException($"KWP negative response NRC 0x{payload[2]:X2}");
  if(payload.Length<2||payload[0]!=0x61||payload[1]!=group)throw new VwTp20ProtocolException("Unexpected KWP measuring-block response");
  return payload.Skip(2).ToArray();
 }
}
