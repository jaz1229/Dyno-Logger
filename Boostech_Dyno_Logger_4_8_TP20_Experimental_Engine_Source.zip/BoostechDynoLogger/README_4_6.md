# Boostech Dyno Logger v4.6 — connection diagnostics and physical ECU probe clarification

- Keeps the selected COM port when refreshing the device list. COM11 is preferred when the previous port is unavailable, matching the current iCar Pro 2S test setup.
- Reports the exception type and actual error in a visible dialog on connection failure, not just the generic status message.
- Logs the selected transport and port at connection start; clears the transport trace at the start of a new connection for clearer diagnostics.
- Clarifies that a silent physical address 7E0 does not establish ECU identity or TP 2.0 support; a responding 7E1 cannot automatically be called the engine ECU.
- Preserves standard OBD2 discovery, CSV logging, UDS identification experiments and physical probe.

## Important limitations

This is a diagnostic/reliability patch, **not** a working VW TP 2.0/KWP2000 implementation. The iCar Pro 2S has not been proven to support the raw CAN frame handling required for TP 2.0, and no enhanced knock/boost/fuel-pressure values are claimed. The physical probe remains read-only and should be run with the vehicle stationary.

Build on Windows using `Windows/PUBLISH_EXE.bat`. Not compiled or hardware-tested in this environment.
