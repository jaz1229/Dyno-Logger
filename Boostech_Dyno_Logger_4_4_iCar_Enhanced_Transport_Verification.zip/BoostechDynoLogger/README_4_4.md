# Boostech Dyno Logger 4.4 — iCar Pro 2S enhanced transport verification

## Implemented

- New **Verify enhanced transport** button in Enhanced ECU ID tab.
- Confirms standard OBD2 and the actual CAN protocol first.
- Restricts the test to one read-only VIN DID (22 F190) at the previously observed 7E0/7E8 pair.
- Tries ELM automatic ISO-TP formatting (ATCAF1); only if it fails, tries explicit single-frame ISO-TP length (ATCAF0 / 03 22 F1 90).
- Reports positive, negative or NO DATA results independently; all commands and raw responses are recorded in the existing transport trace.
- Restores standard OBD2 formatting and automatic protocol selection after testing; disables logging start if restoration fails.
- No address scanning, security access, coding, ECU writes, session changes or guessed enhanced sensor decoding.

## What is NOT implemented

This does **not** unlock VW TP 2.0 measuring blocks, proprietary knock corrections, target boost or universal enhanced channels. Those require a working transport/session implementation and verified ECU-specific signal definitions. On some older VAG ECUs, an ELM-compatible dongle may not provide reliable raw TP 2.0 support. The source is uncompiled here (Windows .NET 10 SDK not available) and needs stationary vehicle testing.

## Test

Build `Windows/PUBLISH_EXE.bat`, connect COM11, open Enhanced ECU ID, click Verify enhanced transport, then Export transport trace. Review VIN before sharing.
