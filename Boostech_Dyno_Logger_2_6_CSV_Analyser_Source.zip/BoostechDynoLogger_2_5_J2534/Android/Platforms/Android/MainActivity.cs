using Android.App;using Android.Content.PM;
namespace BoostechMobile;
[Activity(Theme="@android:style/Theme.Material.NoActionBar",MainLauncher=true,ConfigurationChanges=ConfigChanges.ScreenSize|ConfigChanges.Orientation|ConfigChanges.UiMode|ConfigChanges.ScreenLayout|ConfigChanges.SmallestScreenSize|ConfigChanges.Density)]
public class MainActivity:Microsoft.Maui.MauiAppCompatActivity {}
