@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>&1
if errorlevel 1 (echo Install .NET 10 SDK first & pause & exit /b 1)
dotnet publish BoostechDynoLogger.csproj -c Release -r win-x86 --self-contained true -p:PlatformTarget=x86 -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o "%~dp0Release-x86"
if errorlevel 1 (echo BUILD FAILED & pause & exit /b 1)
explorer "%~dp0Release-x86"
pause
