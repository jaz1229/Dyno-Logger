# Boostech Dyno Logger 3.5 — Workshop Preview

This is a **source preview**, not a finished or hardware-certified workshop diagnostic application.

## Delivered
- Local, JSON-driven ECU profile catalog (`Windows/ecu_profiles.json`) with WMI and exact-calibration match fields, protocol constraints and explicit verification status.
- `Match ECU profile` interface and matching confidence labels. WMI-only results remain *candidates*; they never enable proprietary diagnostics.
- Saved vehicle profiles (`*.btvehicle.json`) and reload; stored ECU identity is never treated as live proof.
- Connection-health strip with observed CSV sample rate, sample counts, polling errors and verified channel count.
- Discovery / logging UI guards and safer disconnect during discovery.
- J2534 path no longer sends ELM `AT` commands. J2534 hardware communication still unverified.
- Existing CSV/YourDyno graphing, RPM alignment, grouped channels, Mode 09 ECU identification, and read-only standard PID discovery retained.

## Not delivered (requires verified data and hardware testing)
- Broad verified proprietary ECU ID database and OEM enhanced PIDs. The reference profiles are **not** proprietary PID implementations.
- Universal automatic ECU family identification, ECU-specific boost/knock channels, UDS/KWP/J1939 diagnostic coverage.
- Reliable J2534 operation across protocols, automatic reconnection, automated regression testing, verified Windows executable.
- Commercial polish and production safety validation.

## Extend database
Add entries to `Windows/ecu_profiles.json` and rebuild. Each record has:
`profileId`, `displayName`, `manufacturer`, `vinWmiPrefix`, `calibrationId`, `protocolContains`, `status`, `suggestedStandardPids`, `notes`.
Set `status: "verified"` only after checking exact ECU/calibration, protocol and validated read-only channels against real hardware.
The current database entries are `reference` only. No unverified enhanced diagnostic requests are sent.

## Build
On Windows with .NET 10 SDK, run `Windows/PUBLISH_EXE.bat`.
No .NET compiler is available in this environment; this package is **not build-verified**.
Before a dyno pull, verify RPM, logging rate and data integrity on a stationary vehicle.
