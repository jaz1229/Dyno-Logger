# Boostech Dyno Logger v4.7 — TP2.0 foundation (experimental)

This release adds a **VW TP2.0 raw CAN frame model**, channel-setup frame construction and response interpretation, plus a **VW TP2.0 capability check** in Enhanced ECU ID.

The check sends ELM AT configuration commands only. It **does not transmit the TP2.0 channel-setup frame**, open a KWP2000 session, read VW measuring blocks, or add new live channels. AT command acceptance does not prove the iCar Pro 2S can reliably run VW TP2.0. The code prepares a candidate setup frame for later validation; module addressing and channel negotiation must be tested against a known-good reference before any ECU transmission.

Why staged: raw CAN reception, TP2.0 setup reply, dynamic CAN IDs, sequence/ACK, segmentation, timing and KWP2000 measuring-block decoding are required before knock/boost/fuel-pressure data can be trusted. Never use experimental diagnostics during a dyno pull. Existing standard OBD2 logging remains unchanged.

Run Windows/PUBLISH_EXE.bat on Windows with the .NET SDK. Not compiled or tested against a vehicle in this environment.
