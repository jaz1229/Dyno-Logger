# Boostech Dyno Logger 2.1 — Windows + Android source

## What is included
- Windows WPF logger based on v2, with additional read-only DTC scan button (stored / pending / permanent), standard supported-PID discovery, CSV export and simulator.
- Android .NET MAUI app, Bluetooth Classic SPP (RFCOMM) connection to already-paired ELM327-compatible adapters, simulator, supported PID discovery, read-only DTC scan, live parameter polling and CSV export via Android share sheet.

## Building
Windows: install .NET 10 SDK, run `BUILD_WINDOWS_EXE.bat` on Windows. It attempts self-contained EXE publishing.
Android: install .NET 10 SDK, Android SDK, and MAUI Android workload, run `BUILD_ANDROID_APK.bat` on Windows. Android SDK setup and signing for distribution may be required. Android APK may be unsigned or development-signed depending on SDK settings; distribution requires a properly signed build.

## Important compatibility limitations
- Neither Windows EXE nor Android APK has been compiled or tested in this environment.
- Android supports Bluetooth Classic SPP only. A BLE-only Vgate variant will need a separate GATT implementation; do not assume compatibility from product branding.
- Android requests Bluetooth Connect permission and lists already paired devices. Pair in Android settings first.
- Diagnostic protocol, Honda ECU support, and supported PIDs remain unverified until the six-pin cable arrives.
- Scan returns raw-supported standard DTCs; no manufacturer-specific fault definitions, freeze-frame decoding, ABS or body modules. Do not clear codes.
- Mode 01 PID availability is discovered; not all listed channels are guaranteed on the Honda.
- CSV is long-format with one timestamped sample per channel; do not interpret sequential PID samples as simultaneous.
- Simulated values are not real ECU readings.
- No flashing, no coding, no write requests.
- Windows and Android are separate UI implementations with equivalent core functions, not synchronized clients.

## Recommended first tests
1. Build and run simulator on both platforms.
2. Pair Vgate to Android and Windows and verify SPP support.
3. Verify cable wiring for the 2023 Honda before connecting.
4. Connect with ignition on, engine off; discover supported PIDs.
5. Verify RPM/TPS live with stationary engine before dyno.
6. Save a CSV and verify timestamps, dropped samples and actual polling speed.
