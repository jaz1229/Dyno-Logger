# Boostech Dyno Logger 4.2 — Automatic protocol detection (read-only preview)

Adds **Auto detect ECU protocol** to the Enhanced ECU ID tab.

- Verifies standard OBD2 service 01 support with 0100 before probing enhanced diagnostics.
- Reads ELM ATDP/ATDPN to identify the protocol actually negotiated with the ECU.
- If and only if 11-bit/500 kbps CAN (protocol 6) is confirmed, attempts a single conventional read-only UDS VIN request to 7E0, filtered for 7E8.
- Distinguishes verified positive UDS responses, negative responses, and missing responses.
- Avoids scanning arbitrary CAN IDs or guessing sessions and manufacturer-specific commands.
- Restores generic OBD2 adapter settings after the test.
- Explains when KWP2000/VW TP 2.0, 29-bit CAN, J1939, or OEM routing needs a different implementation.

This is **not** universal enhanced protocol discovery. Standard OBD2 response does not prove that a vehicle supports UDS; a failed 7E0 UDS request does not prove that the ECU lacks enhanced diagnostics. The current iCar Pro 2S transport cannot implement all KWP/TP2.0/J1939 protocols without more adapter-specific work or different hardware.

This source was not compiled or hardware tested. On Windows with .NET 10 SDK, run Windows/PUBLISH_EXE.bat. Use stationary ignition-on testing; avoid running diagnostic probes during dyno pulls.
