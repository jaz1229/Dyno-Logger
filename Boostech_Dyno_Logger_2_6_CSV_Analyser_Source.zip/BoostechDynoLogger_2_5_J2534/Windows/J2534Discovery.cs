using Microsoft.Win32;
namespace BoostechDynoLogger;
public sealed record J2534Device(string Name,string DllPath,string RegistryPath);
public static class J2534Discovery {
 // Enumerates installed pass-thru drivers. No ECU commands are sent.
 public static IReadOnlyList<J2534Device> Find() {
  var results=new List<J2534Device>();
  foreach(var view in new[]{RegistryView.Registry32,RegistryView.Registry64}) {
   try {
    using var baseKey=RegistryKey.OpenBaseKey(RegistryHive.LocalMachine,view);
    foreach(var root in new[]{@"SOFTWARE\PassThruSupport.04.04",@"SOFTWARE\PassThruSupport.05.00"}) {
     using var parent=baseKey.OpenSubKey(root);
     if(parent is null)continue;
     foreach(var keyName in parent.GetSubKeyNames()) {
      using var device=parent.OpenSubKey(keyName);
      var dll=device?.GetValue("FunctionLibrary") as string;
      if(string.IsNullOrWhiteSpace(dll))continue;
      var name=(device?.GetValue("Name") as string)??keyName;
      if(results.All(x=>!string.Equals(x.DllPath,dll,StringComparison.OrdinalIgnoreCase)))results.Add(new(name,dll,root+"\\"+keyName));
     }
    }
   } catch(System.Security.SecurityException) {} catch(UnauthorizedAccessException) {}
  }
  return results;
 }
}
