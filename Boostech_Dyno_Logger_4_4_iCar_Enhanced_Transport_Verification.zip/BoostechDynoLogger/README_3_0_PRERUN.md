# Boostech Dyno Logger 3.0 — Pre-run improvements

New: adjustable non-destructive moving-average graph smoothing (Off/5/11/21), sorted RPM graph samples to avoid backtracking line artifacts, warnings on constant channels and nonpositive AFR/lambda, optional Hide suspect button, and pre-run checklist. Existing grouped YourDyno/Log channels, RPM comparison, CSV and native .yourdyno import remain.

**Limitations:** Suspicious readings are heuristic, not definitive disconnection detection. Manual channel selection remains possible. RPM sweep identification remains basic; no verified automated acceleration-run detector. Raw YourDyno samples are not necessarily filtered like UnaVision. No new hardware/protocol support, no real-time channel validation. This source has not been compiled in Windows.

Build on Windows with .NET 10 SDK using Windows/PUBLISH_EXE.bat. Test with a real connected wideband before using AFR for tuning.
