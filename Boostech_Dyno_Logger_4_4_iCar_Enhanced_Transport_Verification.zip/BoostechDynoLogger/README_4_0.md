# Boostech Dyno Logger 4.0 — Enhanced diagnostics preview

## Actually implemented
- Read-only UDS service 0x22 ECU **identification** DIDs F190, F187, F188, F189, F18A, F18C and F191 over compatible ELM/vLinker serial CAN, with manually selected 11-bit diagnostic request header.
- Response validation and limited single-frame UDS decoding; error/negative response reporting.
- Guard against running enhanced requests while discovery or logging is active; restore generic OBD adapter header/protocol after request.
- Existing standard OBD logging, J1939 offline decoding, coverage view, ECU profile matching, and CSV/YourDyno analysis preserved.

## Not yet implemented — critical distinctions
- Universal ECU identification, manufacturer-specific knock correction, boost targets, fuel pressure, misfire, DPF or UDS dynamic measurements.
- Reliable multi-frame ISO-TP reassembly on all ELM adapters, response source arbitration, OEM security/session handling, KWP measuring blocks, live J1939, NMEA 2000, and validated J2534 enhanced communications.
- The UDS request ID must be known for the vehicle; 7E0 is only a common default and not universal. Some ECUs may not support these identification DIDs.
- This is a source preview, not a compiled, tested or commercially polished application. Test on a stationary vehicle, with a suitable interface and trusted diagnostics for comparison.

## Build
Windows .NET 10 SDK: `Windows/PUBLISH_EXE.bat`. The Windows compiler and physical hardware were unavailable in this environment.
