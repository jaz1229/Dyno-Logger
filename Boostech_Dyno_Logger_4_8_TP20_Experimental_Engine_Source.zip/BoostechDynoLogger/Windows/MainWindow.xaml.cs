using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Text.Json;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
namespace BoostechDynoLogger;
public sealed class ChannelRow : INotifyPropertyChanged {
 public string Pid {get;init;}="";public string Name {get;init;}="";
 private string display="—",updated="—";
 public string Display {get=>display;set{display=value;PropertyChanged?.Invoke(this,new(nameof(Display)));}}
 public string Updated {get=>updated;set{updated=value;PropertyChanged?.Invoke(this,new(nameof(Updated)));}}
 public event PropertyChangedEventHandler? PropertyChanged;
}
public partial class MainWindow : Window {
 private IObdTransport? transport;private CancellationTokenSource? polling;
 private readonly ObservableCollection<ChannelRow> rows=[];
 private readonly Dictionary<string,PidDef> supported=new();
 private readonly Dictionary<string,double> lastValues=new();
 private StreamWriter? csv;private DateTime sessionStart;private Stopwatch? sessionClock;private string activeCustomer="",activeBike="",activeRun="",activeVehicleType="",activeManufacturer="",activeModel="",activeYear="";private int activeProfile;private string? sessionFolder;private readonly Dictionary<string,long> lastSampleTicks=new();private long sampleCount;private string? lastCsvPath;
 public MainWindow(){InitializeComponent();healthTimer.Tick+=(_,_)=>UpdateHealth();healthTimer.Start();ChannelsGrid.ItemsSource=rows;InitializeVehicleSelection();ModeBox.SelectionChanged+=(_,_)=>RefreshPorts();RefreshPorts();Closing+=(_,_)=>{polling?.Cancel();csv?.Dispose();transport?.Dispose();};}
 private static readonly Dictionary<string,string[]> Makes = new(){
  ["Car"]=["Audi","BMW","Ford","Honda","Hyundai","Mazda","Mercedes-Benz","Mitsubishi","Nissan","Subaru","Toyota","Volkswagen","Other"],
  ["Motorcycle"]=["Aprilia","BMW","Ducati","Harley-Davidson","Honda","Kawasaki","KTM","Suzuki","Triumph","Yamaha","Other"],
  ["Tractor"]=["Case IH","Claas","Deutz-Fahr","Fendt","John Deere","Kubota","Massey Ferguson","New Holland","Other"],
  ["Marine"]=["Evinrude","Honda Marine","Mercury","MerCruiser","Suzuki Marine","Volvo Penta","Yamaha Marine","Yanmar","Other"]
 };
 private void InitializeVehicleSelection(){PopulateMakes("Motorcycle","Honda");}
 private void VehicleType_Changed(object sender,SelectionChangedEventArgs e){
  if(ManufacturerBox is null || VehicleTypeBox?.SelectedItem is not ComboBoxItem item)return;
  var category=item.Content?.ToString()??"Motorcycle";
  PopulateMakes(category,category=="Motorcycle"?"Honda":null);
 }
 private void PopulateMakes(string category,string? preferred){
  ManufacturerBox.ItemsSource=Makes.TryGetValue(category,out var makes)?makes:Array.Empty<string>();
  ManufacturerBox.Text=preferred??"";
 }
 private string VehicleCategory => (VehicleTypeBox.SelectedItem as ComboBoxItem)?.Content?.ToString()??"Motorcycle";
 private void RefreshPorts(){
  string? previous=PortBox.SelectedItem?.ToString();
  if(ModeBox.SelectedIndex==2){
   var devices=J2534Discovery.Find();
   PortBox.ItemsSource=devices.Select(x=>x.Name+" | "+x.DllPath).ToArray();
   StatusText.Text=devices.Count==0?"No installed J2534 driver found":$"{devices.Count} J2534 driver(s) detected — CAN logging available (untested)";
  }else PortBox.ItemsSource=SerialPort.GetPortNames().OrderBy(x=>x).ToArray();
  if(PortBox.Items.Count>0){
   int keep=Array.FindIndex(PortBox.Items.Cast<object>().Select(x=>x.ToString()).ToArray(),x=>x==previous);
   int com11=Array.FindIndex(PortBox.Items.Cast<object>().Select(x=>x.ToString()).ToArray(),x=>x=="COM11");
   PortBox.SelectedIndex=keep>=0?keep:com11>=0?com11:0;
  }
 }
 private void OpenCsvViewer_Click(object s,RoutedEventArgs e){var viewer=new CsvViewerWindow(lastCsvPath){Owner=this};viewer.Show();}
 private void RefreshPorts_Click(object s,RoutedEventArgs e)=>RefreshPorts();
 private void Log(string line){Dispatcher.Invoke(()=>{ConsoleBox.AppendText($"[{DateTime.Now:HH:mm:ss.fff}] {line}\n");ConsoleBox.ScrollToEnd();});}
 private readonly List<TransportTraceRecord> transportTrace=new();
 private sealed record TransportTraceRecord(DateTime Utc,string Command,string RawResponse,long DurationMs,string Outcome);
 private async Task<string> Send(string command,CancellationToken ct=default){
  if(transport is null)throw new InvalidOperationException("Not connected");
  var timer=Stopwatch.StartNew();
  try{
   string r=await transport.RequestAsync(command,ct);
   var outcome=EnhancedDiagnostics.ClassifyAdapterResponse(r);
   transportTrace.Add(new(DateTime.UtcNow,command,r,timer.ElapsedMilliseconds,outcome));
   if(transportTrace.Count>1500)transportTrace.RemoveRange(0,transportTrace.Count-1500);
   Log($"> {command} | {outcome} | {timer.ElapsedMilliseconds}ms | {r.Replace("\r"," ").Replace("\n"," ").Trim()}");
   return r;
  }catch(Exception ex){
   transportTrace.Add(new(DateTime.UtcNow,command,ex.Message,timer.ElapsedMilliseconds,"EXCEPTION: "+ex.GetType().Name));
   if(transportTrace.Count>1500)transportTrace.RemoveRange(0,transportTrace.Count-1500);
   throw;
  }
 }
 private void ExportTransportTrace_Click(object sender,RoutedEventArgs e){
  var dialog=new SaveFileDialog{Filter="JSON trace (*.json)|*.json",FileName=$"Boostech_Transport_Trace_{DateTime.Now:yyyyMMdd_HHmmss}.json"};
  if(dialog.ShowDialog()!=true)return;
  var report=new {schema="boostech-transport-trace-v1",generatedUtc=DateTime.UtcNow,
   adapterMode=(ModeBox.SelectedItem as ComboBoxItem)?.Content?.ToString(),
   warning="Trace may contain VIN and other identifying vehicle information. Redact before sharing.",
   trace=transportTrace.ToArray()};
  File.WriteAllText(dialog.FileName,JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));
 }

 private async void Connect_Click(object s,RoutedEventArgs e){
  ConnectButton.IsEnabled=false;
  transportTrace.Clear();
  Log("CONNECT START: mode="+((ModeBox.SelectedItem as ComboBoxItem)?.Content?.ToString()??"unknown")+", port="+(PortBox.SelectedItem?.ToString()??"none"));
  try{
   if(ModeBox.SelectedIndex==2){
    var devices=J2534Discovery.Find();
    if(devices.Count==0)throw new InvalidOperationException("No J2534 driver installed. Install the genuine Tactrix Openport driver first.");
    var selected=PortBox.SelectedIndex;
    if(selected<0||selected>=devices.Count)throw new InvalidOperationException("Select a J2534 driver first.");
    transport=new J2534CanTransport(devices[selected].DllPath);
   }
   bool sim=ModeBox.SelectedIndex==0;
   if(ModeBox.SelectedIndex==1&&PortBox.SelectedItem is null)throw new InvalidOperationException("Pair Bluetooth and select the outgoing COM port first. BLE-only connections are not implemented.");
   if(ModeBox.SelectedIndex!=2)transport=sim?new SimulatorTransport():new SerialElmTransport(PortBox.SelectedItem!.ToString()!);
   StatusText.Text=sim?"SIMULATION — not real ECU data":"Connecting to ECU...";
   if(ModeBox.SelectedIndex!=2){
    foreach(var cmd in new[]{"ATZ","ATE0","ATL0","ATS1","ATH0","ATSP0"})await Send(cmd);
   }else{
    Log("J2534 CAN device opened. ELM AT initialization skipped; ECU communication still needs a validated J2534 diagnostic exchange.");
   }
   StatusText.Text=sim?"SIMULATOR CONNECTED":ModeBox.SelectedIndex==2?"J2534 OPEN — ECU unverified":"ADAPTER CONNECTED — ECU unverified";
   DisconnectButton.IsEnabled=true;DiscoverButton.IsEnabled=true;ScanButton.IsEnabled=true;IdentifyButton.IsEnabled=true;
  }catch(Exception ex){
   Log("CONNECT ERROR: "+ex.GetType().Name+": "+ex.Message);
   StatusText.Text="Connection failed: "+ex.Message;
   MessageBox.Show("Could not connect to "+(PortBox.SelectedItem?.ToString()??"selected adapter")+".\n\n"+ex.GetType().Name+": "+ex.Message+"\n\nCheck Windows Bluetooth outgoing COM port and close any other app using it.","Boostech connection diagnostics",MessageBoxButton.OK,MessageBoxImage.Warning);
   transport?.Dispose();transport=null;ConnectButton.IsEnabled=true;
  }
 }
 private CancellationTokenSource? discoveryCancellation;
 private void CancelDiscovery_Click(object s,RoutedEventArgs e)=>discoveryCancellation?.Cancel();
 private async void Discover_Click(object s,RoutedEventArgs e){
  if(transport is null || discoveryCancellation is not null)return;
  discoveryCancellation=new CancellationTokenSource();
  var ct=discoveryCancellation.Token;
  DiscoverButton.IsEnabled=false;CancelDiscoveryButton.IsEnabled=true;IdentifyButton.IsEnabled=false;ScanButton.IsEnabled=false;StartButton.IsEnabled=false;
  rows.Clear();supported.Clear();lastValues.Clear();
  var advertised=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  bool bitmapOk=false;
  int attempted=0;
  try{
   // Read the standardized support bitmap, then verify only advertised PIDs.
   // The next bitmap is requested only if the previous one advertises it.
   foreach(var basePid in new[]{"00","20","40","60"}){
    ct.ThrowIfCancellationRequested();
    if(basePid!="00" && !advertised.Contains(basePid))break;
    string response=await Send("01"+basePid,ct);
    var decoded=Pids.Extract(response,basePid);
    if(decoded is null || decoded.Length<4){
     Log($"PID bitmap {basePid} unavailable. Discovery will use limited fallback.");
     break;
    }
    bitmapOk=true;
    advertised.UnionWith(Pids.DecodeSupported(response,basePid));
   }
   var candidates=Pids.All.Where(p=>advertised.Contains(p.Id)).ToList();
   // 010E and 0133 are known standard PIDs: probe them even if a broken
   // supported-PID bitmap omits them. Do not scan arbitrary unadvertised PIDs.
   foreach(var id in new[]{"0E","33"}){
    var def=Pids.All.FirstOrDefault(p=>p.Id==id);
    if(def is not null && candidates.All(p=>p.Id!=id))candidates.Add(def);
   }
   if(!bitmapOk)Log("No usable supported-PID bitmap; testing only known fallback PIDs.");
   for(int i=0;i<candidates.Count;i++){
    ct.ThrowIfCancellationRequested();
    var def=candidates[i];
    StatusText.Text=$"Discovering {i+1}/{candidates.Count}: {def.Name}";
    attempted++;
    try{
     var raw=await Send("01"+def.Id,ct);
     var bytes=Pids.Extract(raw,def.Id);
     if(bytes is null || def.Decode(bytes) is not double value || !double.IsFinite(value))continue;
     supported[def.Id]=def;
     var row=new ChannelRow{Pid=def.Id,Name=def.Name};rows.Add(row);Update(row,def,bytes);
    }catch(TimeoutException ex){
     Log($"PID {def.Id} timed out: {ex.Message}. Stopping discovery to protect adapter synchronization.");
     break;
    }catch(IOException ex){
     Log($"PID {def.Id} transport error: {ex.Message}. Stopping discovery; reconnect if needed.");
     break;
    }
   }
   StatusText.Text=$"{supported.Count} verified PIDs / {attempted} tested";
   Log($"Discovery complete: {supported.Count} verified. OEM enhanced channels need ECU-specific verified definitions.");
  }catch(OperationCanceledException){StatusText.Text=$"Discovery cancelled — {supported.Count} channels retained";}
  catch(Exception ex){Log("DISCOVERY ERROR: "+ex.Message);StatusText.Text="Discovery interrupted";}
  finally{
   discoveryCancellation.Dispose();discoveryCancellation=null;
   CancelDiscoveryButton.IsEnabled=false;DiscoverButton.IsEnabled=transport is not null;IdentifyButton.IsEnabled=transport is not null;ScanButton.IsEnabled=transport is not null;
   StartButton.IsEnabled=supported.Count>0;
  }
 }
 private void ShowCapabilities_Click(object sender,RoutedEventArgs e) {
  var cap=TransportCapabilities.ForMode(ModeBox.SelectedIndex,PortBox.SelectedItem?.ToString());
  MessageBox.Show($"Adapter: {cap.Name}\nStandard OBD2: {(cap.StandardObd?"implemented":"unverified")}\nEnhanced UDS: not implemented\nEnhanced KWP: not implemented\nLive J1939: not implemented\nNMEA 2000: not implemented\n\n{cap.Note}","Boostech transport capabilities");
 }
 private void ImportJ1939_Click(object sender,RoutedEventArgs e) {
  var dialog=new OpenFileDialog{Filter="CAN log (*.txt;*.log)|*.txt;*.log|All files (*.*)|*.*"};
  if(dialog.ShowDialog()!=true)return;
  try{
   var results=new List<object>();int parsed=0,invalid=0;
   foreach(var line in File.ReadLines(dialog.FileName)){
    if(!J1939Decoder.TryParseLine(line,out var id,out var data)){invalid++;continue;}
    parsed++;
    foreach(var signal in J1939Decoder.Decode(id,data)){
     results.Add(new {signal.Pgn,signal.Spn,signal.SourceAddress,signal.Name,signal.Value,signal.Unit});
     if(results.Count>=20000)break;
    }
    if(results.Count>=20000)break;
   }
   J1939Grid.ItemsSource=results;
   Log($"Offline J1939: {parsed} frames parsed, {invalid} lines ignored, {results.Count} signals decoded. No CAN traffic transmitted.");
  }catch(Exception ex){MessageBox.Show("J1939 import failed: "+ex.Message);}
 }
 private void ShowCoverage_Click(object sender,RoutedEventArgs e){
  var coverage=ParameterCoverage.Evaluate(VehicleCategory,supported.Keys.ToArray());
  var lines=coverage.Select(x=>$"{x.State,-13} | {x.Name} | {x.Source}");
  var window=new Window{Title="Required channels — verified vs missing",Width=850,Height=620,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner};
  var text=new TextBox{Text="Verified standard channels vs requested dyno measurements\nOEM values are NOT automatically supported.\n\n"+string.Join("\n",lines),
   FontFamily=new System.Windows.Media.FontFamily("Consolas"),FontSize=13,IsReadOnly=true,
   TextWrapping=TextWrapping.NoWrap,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Auto};
  window.Content=text;window.ShowDialog();
 }
 private void ExportCoverage_Click(object sender,RoutedEventArgs e){
  var dlg=new SaveFileDialog{Filter="JSON coverage (*.json)|*.json",FileName="Boostech_Parameter_Coverage.json"};
  if(dlg.ShowDialog()!=true)return;
  File.WriteAllText(dlg.FileName,ParameterCoverage.JsonReport(VehicleCategory,supported.Keys.ToArray()));
  Log("Parameter coverage report saved. Missing OEM parameters are not guessed.");
 }
 private async void AutoDetect_Click(object sender,RoutedEventArgs e) {
  if(transport is null || ModeBox.SelectedIndex!=1){MessageBox.Show("Connect your iCar Pro 2S using Bluetooth COM first.");return;}
  if(discoveryCancellation is not null || (polling is not null&&!polling.IsCancellationRequested)){
   MessageBox.Show("Stop discovery and logging before protocol detection.");return;
  }
  AutoDetectButton.IsEnabled=false;UdsReadButton.IsEnabled=false;AdapterProbeButton.IsEnabled=false;
  DiscoverButton.IsEnabled=false;IdentifyButton.IsEnabled=false;ScanButton.IsEnabled=false;StartButton.IsEnabled=false;
  var notes=new List<string>();
  try {
   AutoDetectText.Text="Checking standard OBD2 and detecting the active adapter protocol...";
   // Do not assume that an adapter reporting CAN support proves that this ECU uses UDS.
   await Send("ATSP0");
   await Send("ATH1");
   var obd=await Send("0100");
   var bytes=Pids.Extract(obd,"00");
   if(bytes is null || bytes.Length<4){
    notes.Add("Standard OBD2 ECU response not verified. Check ignition, connection and adapter; no enhanced probe attempted.");
    return;
   }
   notes.Add("Standard OBD2 response verified (0100).");
   notes.Add("Raw response headers captured in transport trace; header association is not proof of UDS support.");
   string dp=await Send("ATDP");
   string dpn=await Send("ATDPN");
   notes.Add("Adapter protocol: "+dp.Trim()+" ("+dpn.Trim()+")");
   var code=dpn.Trim().TrimStart('A','a');
   if(code=="6") {
    notes.Add("11-bit 500 kbps CAN detected. Testing one conventional read-only engine ECU UDS VIN request (7E0 / F190).");
    await Send("ATSP6");await Send("ATH1");await Send("ATCAF1");await Send("ATCFC1");await Send("ATAL");
    await Send("ATSH7E0");await Send("ATCRA7E8");
    var raw=await Send("22F190");
    var status=EnhancedDiagnostics.ClassifyAdapterResponse(raw);
    notes.Add("Raw UDS probe classification: "+status+". Export trace for exact bytes.");
    var payload=EnhancedDiagnostics.ParsePositiveUdsResponse(raw,"F190");
    if(payload is not null){
     var vin=EnhancedDiagnostics.DecodeIdentification("F190",payload);
     notes.Add("Positive UDS response at 7E8. VIN payload: "+vin);
     UdsHeaderBox.Text="7E0";
    }else{
     notes.Add(status=="UDS_NEGATIVE"?"UDS negative response received; see raw trace for negative response code.":
      status=="NO_DATA"?"Adapter returned NO DATA; cannot determine whether ECU supports this request.":
      status=="STOPPED"?"ELM reported STOPPED; transport synchronization needs investigation.":
      "No verified positive UDS VIN response. This does not identify the ECU transport protocol.");
     notes.Add("No alternate addresses or sessions were guessed.");
    }
   }else if(code=="7" || code=="8" || code=="9"){
    notes.Add("CAN protocol detected, but not 11-bit 500 kbps. No fixed 7E0/7E8 probe sent; an ECU-specific routing profile is required.");
   }else{
    notes.Add("Non-CAN or unknown protocol. Enhanced KWP2000 / TP 2.0 is not implemented with this adapter. Standard OBD2 remains available.");
   }
  }catch(Exception ex){notes.Add("Detection interrupted: "+ex.Message);notes.Add("Reconnect if the adapter no longer responds to normal OBD2 requests.");}
  finally{
   try{await Send("ATCRA");await Send("ATSH7DF");await Send("ATH0");await Send("ATSP0");}
   catch(Exception ex){notes.Add("Adapter restore failed: "+ex.Message+" — reconnect before logging.");}
   notes.Add("Use Export transport trace for raw bytes, elapsed times, and response classification.");
   AutoDetectText.Text=string.Join("\n",notes);
   foreach(var note in notes)Log("AUTO DETECT: "+note);
   AutoDetectButton.IsEnabled=transport is not null;AdapterProbeButton.IsEnabled=transport is not null;UdsReadButton.IsEnabled=transport is not null;
   DiscoverButton.IsEnabled=transport is not null;IdentifyButton.IsEnabled=transport is not null;ScanButton.IsEnabled=transport is not null;
   StartButton.IsEnabled=supported.Count>0;
  }
 }
 private async void AdapterProbe_Click(object sender,RoutedEventArgs e) {
  if(transport is null||ModeBox.SelectedIndex!=1){MessageBox.Show("Connect using Bluetooth COM first.");return;}
  if(discoveryCancellation is not null || (polling is not null&&!polling.IsCancellationRequested)){MessageBox.Show("Stop logging or discovery first.");return;}
  AdapterProbeButton.IsEnabled=false;UdsReadButton.IsEnabled=false;
  try{
   var results=new List<string>();
   foreach(var command in new[]{"ATI","AT@1","ATDP","ATDPN","ATCAF1","ATCFC1","ATAL"}){
    try{var reply=await Send(command);results.Add($"{command}: {reply.Trim()}");}
    catch(Exception ex){results.Add($"{command}: FAILED {ex.Message}");break;}
   }
   UdsResultText.Text="Adapter capability probe (support is not guaranteed):\n"+string.Join("\n",results);
  }finally{
   try{await Send("ATSP0");}catch(Exception ex){Log("Adapter reset required: "+ex.Message);}
   AdapterProbeButton.IsEnabled=true;UdsReadButton.IsEnabled=true;
  }
 }
 private async void ProbeTp20Capability_Click(object sender,RoutedEventArgs e) {
  if(transport is null||ModeBox.SelectedIndex!=1){MessageBox.Show("Connect the iCar Pro 2S Bluetooth COM adapter first.");return;}
  if(discoveryCancellation is not null||(polling is not null&&!polling.IsCancellationRequested)){MessageBox.Show("Stop logging/discovery first.");return;}
  Tp20CapabilityButton.IsEnabled=false;DiscoverButton.IsEnabled=false;StartButton.IsEnabled=false;
  var report=new List<string>{"VW TP2.0 transport foundation / raw-CAN capability check (no TP2.0 channel opened)."};
  bool restored=false;
  try{
   // AT command acceptance is only a preliminary capability check; it does
   // not demonstrate that raw frames are transmitted/received as required.
   await Send("ATSP6");await Send("ATH1");
   var caf=await Send("ATCAF0");
   var al=await Send("ATAL");
   var h=await Send("ATSH200");
   report.Add("Raw framing mode: "+EnhancedDiagnostics.ClassifyAdapterResponse(caf));
   report.Add("Long messages: "+EnhancedDiagnostics.ClassifyAdapterResponse(al));
   report.Add("11-bit transmit header 200 accepted: "+EnhancedDiagnostics.ClassifyAdapterResponse(h));
   var candidate=VwTp20.ChannelSetupRequest(1);
   report.Add($"TP2.0 engine channel-setup frame prepared OFFLINE: {candidate.Id:X3} {candidate.ElmPayload}");
   report.Add("NOT SENT: ELM AT command acceptance cannot verify unfiltered raw CAN reception, session ACK, or TP2.0 support.");
   report.Add("Next requirement: validated raw CAN send/receive transport and negotiated channel/session implementation.");
  }catch(Exception ex){report.Add("Capability check failed: "+ex.Message);}
  finally{
   try{await Send("ATCRA");await Send("ATCAF1");await Send("ATSH7DF");await Send("ATH0");await Send("ATSP0");restored=true;}
   catch(Exception ex){report.Add("Restore failed; reconnect: "+ex.Message);}
   report.Add(restored?"Standard OBD2 settings restored.":"Standard OBD2 restore not confirmed.");
   AutoDetectText.Text=string.Join("\n",report);foreach(var line in report)Log("TP2.0: "+line);
   Tp20CapabilityButton.IsEnabled=transport is not null;DiscoverButton.IsEnabled=transport is not null;StartButton.IsEnabled=restored&&supported.Count>0;
  }
 }
 private async void ProbePhysicalEcu_Click(object sender,RoutedEventArgs e) {
  if(transport is null || ModeBox.SelectedIndex!=1){MessageBox.Show("Connect the Bluetooth ELM adapter first.");return;}
  if(discoveryCancellation is not null || (polling is not null && !polling.IsCancellationRequested)){
   MessageBox.Show("Stop discovery and live logging before this probe.");return;
  }
  ProbePhysicalButton.IsEnabled=false;VerifyEnhancedButton.IsEnabled=false;
  DiscoverButton.IsEnabled=false;StartButton.IsEnabled=false;
  var report=new List<string>{"Read-only physical-address OBD2 probe (not VW TP2.0 access)."};
  bool restored=false;
  try {
   // First establish auto-detected protocol with functional Mode 01. This may
   // take several seconds on ELM adapters, but is only performed once.
   await Send("ATSP0");await Send("ATH1");
   var functional=await Send("0100");
   var dpn=(await Send("ATDPN")).Trim().ToUpperInvariant();
   report.Add("Functional 0100: "+(Pids.Extract(functional,"00") is not null?"responded":"unverified"));
   report.Add("Protocol: "+dpn);
   if(dpn!="A6" && dpn!="6") {report.Add("Not confirmed CAN 11/500. Stopping.");return;}
   await Send("ATSP6");await Send("ATH1");await Send("ATCAF1");
   report.Add("Testing 7E0 and 7E1 separately. NO DATA does not prove a module is absent.");
   // Physical addresses derived solely from the *observed* 7E8 and 7E9
   // functional responders. 0100 is a standard read-only Mode 01 request.
   foreach(var (tx,rx) in new[]{("7E0","7E8"),("7E1","7E9")}) {
    await Send("ATSH"+tx);await Send("ATCRA"+rx);
    var raw=await Send("0100");
    bool positive=ObdPhysicalProbe.IsMode01SupportedPidReply(raw,rx);
    report.Add($"{tx} -> {rx} physical 0100: "+(positive?"VERIFIED":"no verified response")+
      " ("+EnhancedDiagnostics.ClassifyAdapterResponse(raw)+")");
   }
   report.Add("A verified physical 0100 confirms addressing only, not UDS or VW TP 2.0.");
   report.Add("If 7E0 is silent but 7E1 responds, do not relabel 7E1 as the engine ECU without independent identification.");
   report.Add("ELM AT-command acceptance alone cannot establish raw CAN TP 2.0 capability.");
  }catch(Exception ex){report.Add("Probe interrupted: "+ex.Message);}
  finally {
   try {await Send("ATCRA");await Send("ATSH7DF");await Send("ATH0");await Send("ATCAF1");await Send("ATSP0");restored=true;}
   catch(Exception ex){report.Add("Restore failed: "+ex.Message);}
   report.Add(restored?"Standard OBD configuration restored.":"Reconnect adapter before logging.");
   report.Add("Export transport trace and share the JSON for the next transport decision.");
   AutoDetectText.Text=string.Join("\n",report);
   foreach(var line in report)Log("PHYSICAL ECU PROBE: "+line);
   ProbePhysicalButton.IsEnabled=transport is not null;VerifyEnhancedButton.IsEnabled=transport is not null;
   DiscoverButton.IsEnabled=transport is not null;StartButton.IsEnabled=restored && supported.Count>0;
  }
 }
 private async void VerifyEnhancedTransport_Click(object sender,RoutedEventArgs e) {
  if(transport is null||ModeBox.SelectedIndex!=1){MessageBox.Show("Connect the iCar Pro 2S through Bluetooth COM.");return;}
  if(discoveryCancellation is not null || (polling is not null&&!polling.IsCancellationRequested)){
   MessageBox.Show("Stop logging and discovery before enhanced transport verification.");return;
  }
  VerifyEnhancedButton.IsEnabled=false;AutoDetectButton.IsEnabled=false;UdsReadButton.IsEnabled=false;
  DiscoverButton.IsEnabled=false;IdentifyButton.IsEnabled=false;StartButton.IsEnabled=false;
  var notes=new List<string>();
  bool restored=false;
  try {
   // Verify that generic emissions OBD communication works before any
   // manufacturer-specific read. This does not prove enhanced ECU support.
   await Send("ATSP0");await Send("ATH1");
   var baseline=await Send("0100");
   if(!baseline.Contains("41 00",StringComparison.OrdinalIgnoreCase) &&
      Pids.Extract(baseline,"00") is null){
    notes.Add("Baseline OBD2 0100 failed. No enhanced requests sent.");return;
   }
   notes.Add("Standard OBD2 0100 responded.");
   var dpn=(await Send("ATDPN")).Trim().ToUpperInvariant();
   notes.Add("Detected adapter protocol: "+dpn);
   if(dpn!="A6" && dpn!="6"){
    notes.Add("Not confirmed 11-bit/500 kbps CAN. No enhanced request attempted.");return;
   }
   // Restrict to the already observed engine request/response address pair.
   // Do not scan unrelated modules or enter diagnostic sessions.
   var did="F190";
   await Send("ATSP6");await Send("ATH1");await Send("ATAL");
   await Send("ATCFC1");await Send("ATSH7E0");await Send("ATCRA7E8");
   await Send("ATAT0");await Send("ATST64");
   await Send("ATCAF1");
   var formatted=await Send("22"+did);
   var formattedStatus=EnhancedDiagnostics.DescribeResponse(formatted,did);
   notes.Add("ELM automatic ISO-TP formatting: "+formattedStatus);
   if(EnhancedDiagnostics.ParsePositiveUdsResponse(formatted,did) is null){
    // One additional read-only retry with explicit ISO-TP single-frame length.
    // This is a documented ELM transport fallback, not an ECU DID scan.
    await Send("ATCAF0");
    var raw=await Send(EnhancedDiagnostics.BuildSingleFrameRead(did));
    var rawStatus=EnhancedDiagnostics.DescribeResponse(raw,did);
    notes.Add("Explicit ISO-TP single-frame formatting: "+rawStatus);
    if(EnhancedDiagnostics.ParsePositiveUdsResponse(raw,did) is not null)
      notes.Add("A positive enhanced response was obtained. Review raw trace before enabling any live enhanced channels.");
   }else notes.Add("Positive enhanced response. Explicit formatting fallback not needed.");
   notes.Add("If both formats return NO DATA, VW TP 2.0/KWP2000 or ECU-specific routing may be needed. This test cannot prove which.");
  }catch(Exception ex){
   notes.Add("Transport verification interrupted: "+ex.Message);
  }finally{
   try {
    await Send("ATCAF1");await Send("ATAT1");await Send("ATCRA");
    await Send("ATSH7DF");await Send("ATH0");await Send("ATSP0");
    restored=true;
   }catch(Exception ex){notes.Add("Adapter restore failed: "+ex.Message);}
   notes.Add(restored?"Standard OBD2 adapter configuration restored.":"Reconnect the adapter before logging.");
   notes.Add("Export transport trace to inspect both actual ECU responses.");
   AutoDetectText.Text=string.Join("\n",notes);
   foreach(var line in notes)Log("TRANSPORT VERIFY: "+line);
   VerifyEnhancedButton.IsEnabled=transport is not null;
   AutoDetectButton.IsEnabled=transport is not null;UdsReadButton.IsEnabled=transport is not null;
   DiscoverButton.IsEnabled=transport is not null;IdentifyButton.IsEnabled=transport is not null;
   StartButton.IsEnabled=restored && supported.Count>0;
  }
 }
 private async void ReadUds_Click(object sender,RoutedEventArgs e) {
  if(transport is null){MessageBox.Show("Connect first.");return;}
  if(ModeBox.SelectedIndex!=1){MessageBox.Show("This UDS preview currently supports ELM/vLinker serial CAN only. J2534 support is not validated.");return;}
  if((polling is not null&&!polling.IsCancellationRequested)||discoveryCancellation is not null){MessageBox.Show("Stop logging/discovery first.");return;}
  var header=UdsHeaderBox.Text.Trim().ToUpperInvariant();
  var validation=EnhancedDiagnostics.ValidateCanHeader(header);
  if(validation is not null){MessageBox.Show(validation);return;}
  string did=UdsDidBox.Text.Trim().Split(' ')[0].ToUpperInvariant();
  if(!EnhancedDiagnostics.UdsIdentificationDids.ContainsKey(did)){MessageBox.Show("Select a supported read-only identification DID.");return;}
  UdsReadButton.IsEnabled=false;DiscoverButton.IsEnabled=false;IdentifyButton.IsEnabled=false;ScanButton.IsEnabled=false;StartButton.IsEnabled=false;
  try{
   // ELM handles CAN ISO-TP framing when CAF1 is supported. A request ID
   // alone is not proof of ECU identity; responses must be independently verified.
   // Explicit CAN 11-bit/500k profile. Do not silently use a stale protocol.
   // 7E0->7E8 is a conventional physical diagnostic address pair, not universal.
   await Send("ATSP6");await Send("ATH0");await Send("ATCAF1");
   await Send("ATCFC1");await Send("ATAL");await Send("ATSH"+header);
   string responseHeader=(int.Parse(header,System.Globalization.NumberStyles.HexNumber,System.Globalization.CultureInfo.InvariantCulture)+8).ToString("X3");
   await Send("ATCRA"+responseHeader);
   string raw=await Send("22"+did);
   var bytes=EnhancedDiagnostics.ParsePositiveUdsResponse(raw,did);
   if(bytes is null){UdsResultText.Text=EnhancedDiagnostics.IsNegativeResponse(raw)?
     $"ECU rejected DID {did} (negative response).":"No verified positive UDS response. Check ECU address/protocol and adapter compatibility.";return;}
   string value=EnhancedDiagnostics.DecodeIdentification(did,bytes);
   UdsResultText.Text=$"{EnhancedDiagnostics.UdsIdentificationDids[did]} ({did}): {value} — unverified ECU source address";
   Log("UDS IDENTIFICATION: "+UdsResultText.Text);
  }catch(Exception ex){UdsResultText.Text="UDS read failed: "+ex.Message;Log(UdsResultText.Text);}
  finally{
   // Always return to generic OBD automatic protocol/header selection.
   try{await Send("ATCRA");await Send("ATSH7DF");await Send("ATH0");await Send("ATSP0");}catch(Exception ex){Log("UDS adapter restore failed; reconnect recommended: "+ex.Message);}
   UdsReadButton.IsEnabled=true;DiscoverButton.IsEnabled=transport is not null;IdentifyButton.IsEnabled=transport is not null;
   ScanButton.IsEnabled=transport is not null;StartButton.IsEnabled=supported.Count>0;
  }
 }
 private void ExportDiagnostic_Click(object sender,RoutedEventArgs e) {
  var dialog=new SaveFileDialog{Filter="JSON diagnostics (*.json)|*.json",FileName=$"Boostech_Diagnostics_{DateTime.Now:yyyyMMdd_HHmmss}.json"};
  if(dialog.ShowDialog()!=true)return;
  try{
   var report=new {
    format="boostech-diagnostics-v1",
    capturedUtc=DateTime.UtcNow,
    appVersion="3.9-preview",
    connectionMode=(ModeBox.SelectedItem as ComboBoxItem)?.Content?.ToString()??"Unknown",
    selectedAdapter=PortBox.SelectedItem?.ToString()??"None",
    vehicle=new {category=VehicleCategory,make=ManufacturerBox.Text,model=ModelBox.Text,year=YearBox.Text},
    ecu=identifiedEcu,
    ecuIdentificationConfidence=identifiedEcu?.MatchStatus??"Not identified",
    verifiedStandardPids=supported.Values.Select(x=>new {pid=x.Id,name=x.Name,unit=x.Unit}).ToArray(),
    lastValues=lastValues,
    observedSampleCount=sampleCount,
    observedPollingErrors=errorCount,
    loggingActive=polling is not null&&!polling.IsCancellationRequested,
    note="Read-only diagnostic snapshot. Manufacturer-specific ECU family is not verified unless matched against a tested profile."
   };
   File.WriteAllText(dialog.FileName,JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));
   Log("Diagnostic snapshot exported.");
  }catch(Exception ex){MessageBox.Show("Could not export diagnostics: "+ex.Message);}
 }
 private void OpenUdsTab_Click(object sender,RoutedEventArgs e) { MainTabs.SelectedIndex=2; }
 private EcuIdentity? identifiedEcu;
 private long errorCount;
 private readonly Stopwatch healthClock=Stopwatch.StartNew();
 private long lastHealthCount;
 private long lastHealthMs;
 private readonly System.Windows.Threading.DispatcherTimer healthTimer=new(){Interval=TimeSpan.FromSeconds(2)};
 private void UpdateHealth() {
  long ms=healthClock.ElapsedMilliseconds;
  double rate=ms>lastHealthMs?(sampleCount-lastHealthCount)*1000.0/(ms-lastHealthMs):0;
  HealthText.Text=transport is null?"  Disconnected":
   $"  {(polling is not null&&!polling.IsCancellationRequested?"Recording":"Connected")} | {(polling is not null&&!polling.IsCancellationRequested?rate.ToString("0.0")+" samples/s":"sampling idle")} | {sampleCount:N0} total | {errorCount} errors | {supported.Count} channels";
  lastHealthMs=ms;lastHealthCount=sampleCount;
 }
 private void MatchProfile_Click(object sender,RoutedEventArgs e) {
  if(identifiedEcu is null){MessageBox.Show("Identify the ECU first.");return;}
  try {
   var matches=EcuProfileDatabase.Match(identifiedEcu,EcuProfileDatabase.Load(EcuProfileDatabase.FindDatabase()));
   if(matches.Count==0){ProfileMatchText.Text="No matching profile in local database. Standard OBD2 discovery remains available.";return;}
   var best=matches[0];
   ProfileMatchText.Text=$"ECU profile: {best.Profile.DisplayName} — {best.Confidence}. {best.Reason}. {matches.Count} candidate(s).";
   Log("ECU PROFILE: "+ProfileMatchText.Text);
   // Never automatically activate manufacturer-specific diagnostic requests.
  }catch(Exception ex){Log("PROFILE DATABASE ERROR: "+ex.Message);}
 }
 private sealed class SavedVehicle {
  public string Category {get;set;}="";
  public string Make {get;set;}="";
  public string Model {get;set;}="";
  public string Year {get;set;}="";
  public string Customer {get;set;}="";
  public string VehicleId {get;set;}="";
  public string Run {get;set;}="";
  public string EcuVin {get;set;}="";
  public string EcuCalibration {get;set;}="";
 }
 private void SaveVehicle_Click(object sender,RoutedEventArgs e) {
  var dlg=new SaveFileDialog{Filter="Boostech vehicle (*.btvehicle.json)|*.btvehicle.json",FileName="Boostech_vehicle.btvehicle.json"};
  if(dlg.ShowDialog()!=true)return;
  var v=new SavedVehicle{Category=VehicleCategory,Make=ManufacturerBox.Text,Model=ModelBox.Text,
   Year=YearBox.Text,Customer=CustomerBox.Text,VehicleId=BikeBox.Text,Run=RunBox.Text,
   EcuVin=identifiedEcu?.Vin??"",EcuCalibration=identifiedEcu?.CalibrationIds??""};
  File.WriteAllText(dlg.FileName,JsonSerializer.Serialize(v,new JsonSerializerOptions{WriteIndented=true}));
  Log("Vehicle details saved (no ECU configuration changed).");
 }
 private void LoadVehicle_Click(object sender,RoutedEventArgs e) {
  var dlg=new OpenFileDialog{Filter="Boostech vehicle (*.btvehicle.json)|*.btvehicle.json"};
  if(dlg.ShowDialog()!=true)return;
  try{
   var v=JsonSerializer.Deserialize<SavedVehicle>(File.ReadAllText(dlg.FileName));
   if(v is null)throw new InvalidDataException("Vehicle file is empty.");
   foreach(var item in VehicleTypeBox.Items.OfType<ComboBoxItem>())
    if(string.Equals(item.Content?.ToString(),v.Category,StringComparison.OrdinalIgnoreCase)){VehicleTypeBox.SelectedItem=item;break;}
   ManufacturerBox.Text=v.Make;ModelBox.Text=v.Model;YearBox.Text=v.Year;
   CustomerBox.Text=v.Customer;BikeBox.Text=v.VehicleId;RunBox.Text=v.Run;
   ProfileMatchText.Text="Saved vehicle loaded. ECU identity must be re-verified on the connected vehicle.";
   Log("Vehicle loaded; stored VIN/calibration are metadata only, not live ECU identification.");
  }catch(Exception ex){MessageBox.Show("Could not load vehicle: "+ex.Message);}
 }

 private async void Identify_Click(object sender,RoutedEventArgs e) {
  if(transport is null)return;
  if(discoveryCancellation is not null || (polling is not null&&!polling.IsCancellationRequested)){
   MessageBox.Show("Stop discovery or logging before ECU identification.");return;
  }
  IdentifyButton.IsEnabled=false;DiscoverButton.IsEnabled=false;ScanButton.IsEnabled=false;
  var identity=new EcuIdentity();
  try{
   IdentityStatusText.Text="Reading ECU identification (read-only)...";
   HashSet<byte>? mode09Capabilities=null;
   foreach(var (command,key) in new[]{
    ("ATI","Adapter"),("ATDP","Protocol"),("ATDPN","Protocol number"),
    ("0900","Mode 09 supported"),
    ("0902","VIN"),("0904","Calibration IDs"),("0906","CVN"),("0100","Supported PID signature")}) {
    if(mode09Capabilities is {Count:>0} && command.StartsWith("09") && command!="0900"
      && byte.TryParse(command[2..],System.Globalization.NumberStyles.HexNumber,null,out var mode09Pid)
      && !mode09Capabilities.Contains(mode09Pid)){
      identity.Warnings.Add($"{key}: not advertised by Mode 09 capability bitmap");
      continue;
    }
    try{
     var raw=await Send(command);
     identity.RawResponses[key]=raw;
     if(raw.Contains("NO DATA",StringComparison.OrdinalIgnoreCase)||
        raw.Contains("STOPPED",StringComparison.OrdinalIgnoreCase)||
        raw.Contains("?",StringComparison.OrdinalIgnoreCase))
       identity.Warnings.Add($"{key}: unavailable or unsupported");
     switch(key){
      case "Adapter":identity.Adapter=raw.Trim();break;
      case "Protocol":identity.Protocol=raw.Trim();break;
      case "Header setting":identity.EcuHeader=raw.Trim();break;
      case "Mode 09 supported":
       identity.Mode09Supported=raw.Trim();
       var supported09=EcuIdentification.SupportedMode09Pids(raw);
       if(supported09.Count>0)mode09Capabilities=supported09;
       break;
      case "VIN":identity.Vin=EcuIdentification.DecodeVin(raw);break;
      case "Calibration IDs":identity.CalibrationIds=EcuIdentification.DecodeCalIds(raw);break;
      case "CVN":identity.CvnHex=EcuIdentification.DecodeCvn(raw);break;
      case "Supported PID signature":identity.SupportedPidSignature=raw.Trim();break;
     }
    }catch(TimeoutException ex){identity.Warnings.Add($"{key}: timeout — {ex.Message}");break;}
     catch(IOException ex){identity.Warnings.Add($"{key}: transport desynchronized — {ex.Message}");break;}
   }
   if(identity.Vin.Length==0)identity.Warnings.Add("VIN not returned or could not be decoded");
   if(identity.CalibrationIds.Length==0)identity.Warnings.Add("Calibration ID not returned or could not be decoded");
   identity.VinManufacturer=EcuIdentification.ManufacturerFromVin(identity.Vin);
   identity.MatchStatus=EcuIdentification.MatchConfidence(identity);
   identifiedEcu=identity;
   IdentityText.Text=$"VIN: {(identity.Vin.Length>0?identity.Vin:"Unavailable")}  |  WMI: {identity.VinManufacturer}\n"+
     $"CAL ID: {(identity.CalibrationIds.Length>0?identity.CalibrationIds:"Unavailable")}  |  CVN: {(identity.CvnHex.Length>0?identity.CvnHex:"Unavailable")}";
   IdentityStatusText.Text=$"{identity.MatchStatus} | Protocol: {identity.Protocol} | Warnings: {identity.Warnings.Count}";
   Log("Mode 09 identity requests completed. No OEM enhanced PID support is inferred from this result.");
   SaveIdentityButton.IsEnabled=true;MatchProfileButton.IsEnabled=true;MatchProfile_Click(sender,e);
   Log($"ECU identification: {identity.MatchStatus}. Vehicle make/model selections were NOT overwritten.");
  }catch(Exception ex){Log("IDENTIFICATION ERROR: "+ex.Message);IdentityStatusText.Text="Identification failed";}
  finally{
   IdentifyButton.IsEnabled=transport is not null;
   DiscoverButton.IsEnabled=transport is not null;
   ScanButton.IsEnabled=transport is not null;
  }
 }
 private void SaveIdentity_Click(object sender,RoutedEventArgs e){
  if(identifiedEcu is null)return;
  var dialog=new SaveFileDialog{Filter="JSON files (*.json)|*.json",FileName=$"Boostech_ECU_ID_{DateTime.Now:yyyyMMdd_HHmmss}.json"};
  if(dialog.ShowDialog()==true)File.WriteAllText(dialog.FileName,EcuIdentification.ToJson(identifiedEcu));
 }
 private void Update(ChannelRow row,PidDef def,byte[] bytes){var value=def.Decode(bytes);if(value is null)return;lastValues[def.Id]=value.Value;row.Display=$"{value.Value:0.##} {def.Unit}";row.Updated=DateTime.UtcNow.ToString("HH:mm:ss.fff");
  if(def.Id=="0C")RpmText.Text=$"{value.Value:0} rpm";if(def.Id=="11")TpsText.Text=$"{value.Value:0.#} %";if(def.Id=="05")CoolantText.Text=$"{value.Value:0} °C";if(def.Id=="0B")MapText.Text=$"{value.Value:0} kPa";
 }
 private async void Start_Click(object s,RoutedEventArgs e){
  var dlg=new SaveFileDialog{Filter="CSV files (*.csv)|*.csv",FileName=$"Boostech_Run_{DateTime.Now:yyyyMMdd_HHmmss}.csv"};if(dlg.ShowDialog()!=true)return;
  try{
   lastCsvPath=dlg.FileName;sessionFolder=Path.Combine(Path.GetDirectoryName(dlg.FileName)!,Path.GetFileNameWithoutExtension(dlg.FileName)+"_files");Directory.CreateDirectory(sessionFolder);
   var metadata=new {version="4.0",ecuIdentity=identifiedEcu,createdUtc=DateTime.UtcNow,vehicleCategory=VehicleCategory,manufacturer=ManufacturerBox.Text,model=ModelBox.Text,year=YearBox.Text,customer=CustomerBox.Text,vehicleId=BikeBox.Text,run=RunBox.Text,transport=ModeBox.SelectedIndex==0?"simulator":ModeBox.SelectedIndex==2?"J2534 ISO15765 11/500":"serial",profile=ProfileBox.Text,pids=supported.Values.Select(x=>new{x.Id,x.Name,x.Unit}).ToArray(),notes="ECU support determined by live PID discovery; no proprietary PIDs validated"};
   await File.WriteAllTextAsync(Path.Combine(sessionFolder,"session.json"),JsonSerializer.Serialize(metadata,new JsonSerializerOptions{WriteIndented=true}));
   csv=new StreamWriter(dlg.FileName,false,new UTF8Encoding(true));
   await csv.WriteLineAsync("timestamp_utc,elapsed_ms,vehicle_category,manufacturer,model,year,customer,vehicle_id,run,pid,parameter,value,unit,raw_response,interval_ms");
   sessionStart=DateTime.UtcNow;activeProfile=ProfileBox.SelectedIndex;activeCustomer=CustomerBox.Text;activeBike=BikeBox.Text;activeRun=RunBox.Text;activeVehicleType=VehicleCategory;activeManufacturer=ManufacturerBox.Text;activeModel=ModelBox.Text;activeYear=YearBox.Text;sessionClock=Stopwatch.StartNew();lastSampleTicks.Clear();sampleCount=0;errorCount=0;lastHealthCount=0;lastHealthMs=healthClock.ElapsedMilliseconds;polling=new CancellationTokenSource();
   ProfileBox.IsEnabled=false;StartButton.IsEnabled=false;DiscoverButton.IsEnabled=false;IdentifyButton.IsEnabled=false;MatchProfileButton.IsEnabled=false;ScanButton.IsEnabled=false;StopButton.IsEnabled=true;StatusText.Text="RECORDING";
   _=PollLoop(polling.Token);
  }catch(Exception ex){Log("LOGGING ERROR: "+ex.Message);csv?.Dispose();csv=null;}
 }
 private async Task PollLoop(CancellationToken ct){
  // Sequential single-PID polling, with no unsupported proprietary commands.
  try{while(!ct.IsCancellationRequested){
   foreach(var def in PollOrder()){ct.ThrowIfCancellationRequested();
    try{
     string raw=await Send("01"+def.Id,ct);var bytes=Pids.Extract(raw,def.Id);if(bytes is null){Log("NO DATA for "+def.Id);continue;}
     double? value=def.Decode(bytes);if(value is null)continue;
     var row=rows.First(x=>x.Pid==def.Id);await Dispatcher.InvokeAsync(()=>Update(row,def,bytes));
     var now=DateTime.UtcNow;long elapsed=sessionClock?.ElapsedMilliseconds??0;string interval=lastSampleTicks.TryGetValue(def.Id,out long previous)?(elapsed-previous).ToString():"";lastSampleTicks[def.Id]=elapsed;var safeRaw=raw.Replace('"','\'').Replace('\r',' ').Replace('\n',' ');
     if(csv is not null)await csv.WriteLineAsync($"{now:O},{elapsed},{CsvField(activeVehicleType)},{CsvField(activeManufacturer)},{CsvField(activeModel)},{CsvField(activeYear)},{CsvField(activeCustomer)},{CsvField(activeBike)},{CsvField(activeRun)},{def.Id},{CsvField(def.Name)},{value.Value.ToString(System.Globalization.CultureInfo.InvariantCulture)},{CsvField(def.Unit)},{CsvField(safeRaw)},{interval}");
     sampleCount++;if(sampleCount%20==0&&csv is not null)await csv.FlushAsync(ct);
    }catch(OperationCanceledException){throw;}catch(Exception ex){errorCount++;Log($"POLL {def.Id}: {ex.Message}");await Task.Delay(200,ct);}
   }
  }}catch(OperationCanceledException){}catch(Exception ex){Log("POLL LOOP STOPPED: "+ex.Message);}finally{
   if(csv is not null){try{await csv.FlushAsync();await csv.DisposeAsync();}catch(Exception ex){Log("CSV SAVE ERROR: "+ex.Message);}csv=null;}
   await Dispatcher.InvokeAsync(()=>{ProfileBox.IsEnabled=true;StopButton.IsEnabled=false;StartButton.IsEnabled=supported.Count>0;DiscoverButton.IsEnabled=transport is not null;IdentifyButton.IsEnabled=transport is not null;MatchProfileButton.IsEnabled=identifiedEcu is not null;ScanButton.IsEnabled=transport is not null;StatusText.Text=$"Stopped — {sampleCount} samples";});
  }
 }
 private IEnumerable<PidDef> PollOrder(){
  var all=supported.Values.ToArray();int profile=activeProfile;
  string[] high=profile switch {0=>["0C","11","0B","0E","24","34","05","0F"],1=>["0C","11","0B","0E","05","0F","42"],2=>["05","0F","5C","42","0C","11"],_=>[]};
  if(profile==3)return all;
  // Repeating high-priority channels increases their share of sequential requests;
  // actual rates are ECU/adapter dependent, never guaranteed.
  var ordered=high.Where(supported.ContainsKey).Select(id=>supported[id]).ToList();
  if(profile==0)ordered.InsertRange(0,high.Take(3).Where(supported.ContainsKey).Select(id=>supported[id]));
  ordered.AddRange(all.Where(x=>!high.Contains(x.Id)));return ordered;
 }
 private static string CsvField(string value)=>"\""+value.Replace("\"","\"\"").Replace("\r"," ").Replace("\n"," ")+"\"";
 private void Stop_Click(object s,RoutedEventArgs e){polling?.Cancel();StopButton.IsEnabled=false;}
 private void Disconnect_Click(object s,RoutedEventArgs e){if(polling is not null&&!polling.IsCancellationRequested){MessageBox.Show("Stop logging and wait for CSV to save before disconnecting.");return;}if(discoveryCancellation is not null){MessageBox.Show("Cancel discovery and wait for it to finish before disconnecting.");return;}transport?.Dispose();transport=null;ConnectButton.IsEnabled=true;DisconnectButton.IsEnabled=false;DiscoverButton.IsEnabled=false;ScanButton.IsEnabled=false;IdentifyButton.IsEnabled=false;SaveIdentityButton.IsEnabled=false;MatchProfileButton.IsEnabled=false;ProfileMatchText.Text="ECU profile: not matched";identifiedEcu=null;IdentityText.Text="Not identified";StartButton.IsEnabled=false;rows.Clear();supported.Clear();StatusText.Text="Disconnected";}
 private async void Send_Click(object s,RoutedEventArgs e){
  if(transport is null){MessageBox.Show("Connect first");return;}
  if(polling is not null&&!polling.IsCancellationRequested){MessageBox.Show("Stop logging before sending requests.");return;}
  string cmd=CommandBox.Text.Trim().ToUpperInvariant().Replace(" ","");
  // Whitelist strictly read-only generic Mode 01 queries.
  if(cmd.Length!=4||!cmd.StartsWith("01")||!byte.TryParse(cmd.Substring(2),System.Globalization.NumberStyles.HexNumber,null,out _)){MessageBox.Show("Only Mode 01 PID reads (e.g. 010C) are allowed.");return;}
  try{await Send(cmd);}catch(Exception ex){Log("REQUEST ERROR: "+ex.Message);}
 }
 private async void Scan_Click(object sender,RoutedEventArgs e){
  if(transport is null)return;
  if(polling is not null&&!polling.IsCancellationRequested){MessageBox.Show("Stop logging before scanning.");return;}
  ScanButton.IsEnabled=false;
  try{
   var report=new List<string>{"section,request,result"};
   foreach(var (cmd,label,mode) in new[]{("03","Stored", "43"),("07","Pending","47"),("0A","Permanent","4A")}){
    var raw=await Send(cmd);
    var codes=FaultCodes.Parse(raw,mode);
    var outcome=codes.Count>0?string.Join("; ",codes):raw.Contains("NO DATA",StringComparison.OrdinalIgnoreCase)?"not available / no response":"none decoded";
    Log($"{label} DTCs: "+outcome);report.Add($"{CsvField(label)},{cmd},{CsvField(outcome)}");
   }
   foreach(var (cmd,label) in new[]{("0902","VIN"),("0904","Calibration IDs"),("0906","CVN"),("0200","Freeze-frame support")}){try{var raw=await Send(cmd);report.Add($"{CsvField(label)},{cmd},{CsvField(raw.Replace((char)13,' ').Replace((char)10,' '))}");}catch(Exception ex){report.Add($"{CsvField(label)},{cmd},{CsvField(ex.Message)}");}}
   var save=new SaveFileDialog{Filter="CSV files (*.csv)|*.csv",FileName=$"Boostech_Scan_{DateTime.Now:yyyyMMdd_HHmmss}.csv"};
   if(save.ShowDialog()==true)await File.WriteAllLinesAsync(save.FileName,report);
   Log("Scan is read-only; fault codes have not been cleared. ECU info responses saved raw (not yet decoded).");
  }catch(Exception ex){Log("SCAN ERROR: "+ex.Message);}finally{ScanButton.IsEnabled=transport is not null;}
 }
 private void SaveConsole_Click(object s,RoutedEventArgs e){var dlg=new SaveFileDialog{Filter="Text log (*.txt)|*.txt",FileName="Boostech_Console.txt"};if(dlg.ShowDialog()==true)File.WriteAllText(dlg.FileName,ConsoleBox.Text);}
}
