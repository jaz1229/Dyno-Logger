using System.Text.RegularExpressions;
namespace BoostechDynoLogger;
public static class FaultCodes {
 public static List<string> Parse(string raw,string mode){
  var result=new List<string>();
  foreach(var line in raw.ToUpperInvariant().Split(new[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries)){
   var bytes=Regex.Matches(line,@"(?<![0-9A-F])[0-9A-F]{2}(?![0-9A-F])").Select(m=>m.Value).ToList();
   if(bytes.Count<2){var compact=Regex.Replace(line,@"[^0-9A-F]","");if(compact.Length%2==0&&compact.Length>=4)bytes=Enumerable.Range(0,compact.Length/2).Select(i=>compact.Substring(i*2,2)).ToList();}
   var index=bytes.IndexOf(mode);if(index<0)continue;
   for(int i=index+1;i+1<bytes.Count;i+=2){
    if(!ushort.TryParse(bytes[i]+bytes[i+1],System.Globalization.NumberStyles.HexNumber,null,out var n)||n==0)continue;
    string family="PCBU"[(n>>14)&3].ToString();result.Add($"{family}{((n>>12)&3):X1}{(n&0xFFF):X3}");
   }
  }
  return result.Distinct().ToList();
 }
}
