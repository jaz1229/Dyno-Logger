# Boostech Dyno Logger 3.1 — Automatic standard OBD2 PID discovery

## Changes
- Uses supported-PID bitmaps as hints rather than strict filters.
- Directly tests all **implemented, read-only standard Mode 01 PIDs**, including ignition advance `010E`, barometric pressure `0133`, and MAP `010B`.
- A PID is added to live logging only when the ECU actually returns a valid, decodable numeric response.
- Logs bitmap omissions and continues after per-PID timeouts / I/O errors.
- Does not fake boost readings or manufacture manufacturer-specific channels.
- Existing CSV, YourDyno, RPM-aligned graphing and grouped channel features retained.

## Important scope and limitations
- **Not universal OEM enhanced diagnostics.** Brand/model-specific UDS/KWP measuring values require verified ECU identification, addresses, data identifiers, decoding/scaling and safety validation.
- Directly probing all implemented PIDs can be slow on Bluetooth, especially if many requests time out. Run discovery with the vehicle stationary, ignition on, and no active logging.
- This source has not been compiled or tested against actual ECU hardware in this environment.
- If `010E` responds, it will be discovered even if its bit is absent from `0100`. If `010B` returns NO DATA, it remains unavailable.
- Boost requires a verified pressure source. `0133` alone cannot calculate boost.

## Build
On Windows with .NET 10 SDK run `Windows/PUBLISH_EXE.bat`.
