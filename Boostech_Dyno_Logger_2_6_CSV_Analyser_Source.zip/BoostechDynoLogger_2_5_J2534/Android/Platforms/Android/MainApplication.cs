using Android.App;using Android.Runtime;
namespace BoostechMobile;
[Application] public class MainApplication:Microsoft.Maui.MauiApplication {public MainApplication(IntPtr h,JniHandleOwnership o):base(h,o){}protected override Microsoft.Maui.Hosting.MauiApp CreateMauiApp()=>MauiProgram.CreateMauiApp();}
