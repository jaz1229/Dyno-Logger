# Boostech Dyno Logger v2.6 — CSV Analyser

## New features
- **CSV Analyser / Graphs** button on the main Windows screen.
- Open saved Boostech logger CSV files without an ECU connection.
- Multi-channel line graphs with individual channel visibility toggles.
- Zoom and horizontal pan through a run.
- Normalized per-channel comparison or shared raw-value scaling.
- Mouse cursor displays nearest channel values at the chosen time.
- Export the visible graph to PNG.
- Handles CSV quoting and missing/non-numeric samples.
- No extra chart packages or NuGet dependencies.

## Build
Run `Windows/PUBLISH_EXE.bat` (Windows with .NET 10 SDK).
For 32-bit J2534 drivers use `Windows/PUBLISH_EXE_X86.bat`.

## Notes
CSV data is read-only; the viewer doesn't alter source logs.
This viewer is intended for the long-form CSV exported by Dyno Logger (`elapsed_ms`, `pid`, `parameter`, `value`, `unit`).
For channels with different units, use normalized scaling to compare shapes, not absolute magnitudes.
J2534 hardware communication remains experimental and unverified.
This release was prepared without a Windows .NET build environment; compilation needs verification on Windows.
