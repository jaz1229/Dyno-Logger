# Boostech Dyno Logger 2.5 — J2534 CAN test build

This version replaces the disabled J2534 button with a native SAE J2534-1 PassThru transport. It is **not yet compiled on Windows or tested with an Openport or ECU**. Do not rely on its data for tuning until validated.

## Implemented
- Enumerate installed J2534 DLLs (32-bit and 64-bit registry views).
- Load selected driver DLL, PassThruOpen, PassThruConnect, PassThruStartMsgFilter, PassThruWriteMsgs, PassThruReadMsgs, disconnect/close.
- ISO15765 11-bit CAN at 500 kbps only, conventional engine ECU physical request 0x7E0 and response 0x7E8; flow-control filter.
- Read-only Mode 01, 02, 03, 07, 09, 0A requests; existing standard PID discovery, DTC scanner, dashboard, and CSV logging.
- Adapter initialization AT commands handled locally (never sent to J2534 DLL).

## Build and test
1. Install genuine compatible Openport 2.0 drivers. Plug the Openport into USB and a compatible vehicle diagnostic socket.
2. Run BUILD_WINDOWS_EXE.bat (x64). If driver DLL is 32-bit, run Windows/PUBLISH_EXE_X86.bat instead. A 64-bit EXE cannot load a 32-bit J2534 DLL.
3. Launch the EXE; select **Tactrix J2534 (CAN 11/500)** and the correct installed J2534 driver.
4. Turn ignition ON; click Connect, then Discover PIDs. Verify RPM etc. independently before any dyno pull.
5. Save the diagnostic console on failure and share the error number. Test on a stationary compatible vehicle first.

## Limitations
- No automatic CAN baud/identifier/protocol discovery for J2534; fixed 11-bit CAN/500k and 0x7E0/0x7E8.
- Only the primary engine ECU; no 29-bit CAN, K-Line, J1939, NMEA 2000, multi-ECU addressing, or proprietary Honda services.
- Native J2534 drivers vary; message filtering and ISO-TP handling require physical validation.
- No ECU writing, clearing DTCs, or actuator controls.
- Bluetooth COM mode is separate and unchanged.
- Existing app UI and code have not been verified in a Windows compiler in this environment.
