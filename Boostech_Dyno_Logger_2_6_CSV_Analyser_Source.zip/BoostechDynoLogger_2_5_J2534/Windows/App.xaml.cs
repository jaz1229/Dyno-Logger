using System.Windows;
namespace BoostechDynoLogger;
public partial class App : Application { }
