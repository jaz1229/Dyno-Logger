using System.Globalization;
using System.Text;
using Android.Bluetooth;
using Android.Content.PM;
using Microsoft.Maui.ApplicationModel;
namespace BoostechMobile;
public class MainPage:ContentPage {
 readonly Picker devices=new(){Title="Paired Bluetooth device"};readonly Switch demo=new(){IsToggled=true};
 readonly Entry customer=new(){Placeholder="Customer name"},bike=new(){Text="Honda CBR650R 2023"},run=new(){Text="Run 001"};
 readonly Label status=new(){Text="Not connected",TextColor=Colors.Orange},live=new(){Text="RPM —  |  TPS —  |  MAP —",FontSize=21,FontAttributes=FontAttributes.Bold};
 readonly Label channels=new(){Text="No channels discovered"},faults=new(){Text="No fault scan yet"};
 readonly Editor console=new(){HeightRequest=160,IsReadOnly=true,BackgroundColor=Color.FromArgb("#0A1119"),TextColor=Colors.LightGreen,FontSize=12};
 readonly Button connect=new(){Text="Connect"},discover=new(){Text="Discover PIDs",IsEnabled=false},scan=new(){Text="Scan DTCs",IsEnabled=false},start=new(){Text="Start CSV recording",IsEnabled=false},stop=new(){Text="Stop and save",IsEnabled=false};
 IElm? elm; CancellationTokenSource? cts;readonly List<Channel> supported=new(); readonly List<string> records=new();DateTimeOffset began;bool busy;
 public MainPage(){Title="Boostech Dyno Logger";BackgroundColor=Color.FromArgb("#101B2B");
  var refresh=new Button{Text="Refresh paired devices"};refresh.Clicked+=async(_,_)=>await Refresh();
  connect.Clicked+=async(_,_)=>await Connect();discover.Clicked+=async(_,_)=>await Discover();scan.Clicked+=async(_,_)=>await Scan();start.Clicked+=async(_,_)=>await Start();stop.Clicked+=async(_,_)=>await Stop();
  Content=new ScrollView{Content=new VerticalStackLayout{Padding=18,Spacing=12,Children={
   new Label{Text="BOOSTECH  |  DYNO LOGGER 2.1",FontSize=23,FontAttributes=FontAttributes.Bold,TextColor=Colors.White},
   new Label{Text="Read-only ECU logging and diagnostics",TextColor=Colors.LightGray},
   new HorizontalStackLayout{Spacing=10,Children={new Label{Text="Simulator",TextColor=Colors.White,VerticalTextAlignment=TextAlignment.Center},demo}},
   devices,refresh,connect,status,new BoxView{HeightRequest=1,Color=Colors.Gray},
   live,new Label{Text="SESSION",TextColor=Colors.SkyBlue,FontAttributes=FontAttributes.Bold},customer,bike,run,
   discover,channels,scan,faults,start,stop,new Label{Text="RAW DIAGNOSTIC CONSOLE",TextColor=Colors.SkyBlue},console,
   new Label{Text="Only standard read requests. No DTC clearing, ECU writing or flashing. Actual bike compatibility requires testing.",TextColor=Colors.LightGray,FontSize=12}
  }}};
  _=Refresh();
 }
 void Log(string s){MainThread.BeginInvokeOnMainThread(()=>{console.Text=($"[{DateTime.Now:HH:mm:ss}] {s}\n"+console.Text);if(console.Text.Length>12000)console.Text=console.Text[..12000];});}
 async Task Refresh(){devices.Items.Clear();if(Android.OS.Build.VERSION.SdkInt>=Android.OS.BuildVersionCodes.S&&await Permissions.RequestAsync<BluetoothPermission>()!=PermissionStatus.Granted){Log("Bluetooth permission denied");return;}
  try{var adapter=BluetoothAdapter.DefaultAdapter;if(adapter==null){Log("Bluetooth unavailable");return;}foreach(var d in adapter.BondedDevices??new HashSet<BluetoothDevice>())devices.Items.Add($"{d.Name} | {d.Address}");if(devices.Items.Count>0)devices.SelectedIndex=0;}
  catch(Exception ex){Log("Device discovery: "+ex.Message);}
 }
 async Task<string> Send(string cmd,CancellationToken ct=default){if(elm==null)throw new InvalidOperationException("Not connected");string s=await elm.Send(cmd,ct);Log($"> {cmd}: {s.Replace('\r',' ').Replace('\n',' ').Trim()}");return s;}
 async Task Connect(){if(busy)return;busy=true;connect.IsEnabled=false;try{
  if(elm!=null){elm.Dispose();elm=null;}
  if(demo.IsToggled)elm=new DemoElm();else{
   if(devices.SelectedItem==null)throw new Exception("Pair Vgate in Android Bluetooth settings first");
   var addr=devices.SelectedItem.ToString()!.Split('|').Last().Trim();var device=BluetoothAdapter.DefaultAdapter!.GetRemoteDevice(addr)!;
   elm=await Task.Run(()=>new BluetoothElm(device));
  }
  foreach(var c in new[]{"ATZ","ATE0","ATL0","ATS1","ATH0","ATSP0"})await Send(c);
  status.Text=demo.IsToggled?"SIMULATOR CONNECTED":"BLUETOOTH CONNECTED — ECU unverified";
  discover.IsEnabled=true;scan.IsEnabled=true;
 }catch(Exception ex){status.Text="Connection failed";Log(ex.Message);elm?.Dispose();elm=null;}finally{busy=false;connect.IsEnabled=true;}}
 async Task Discover(){if(elm==null||busy)return;busy=true;discover.IsEnabled=false;try{
  supported.Clear();var avail=Obd.Supported(await Send("0100"),"00");
  if(avail.Contains("20"))avail.UnionWith(Obd.Supported(await Send("0120"),"20"));
  if(avail.Contains("40"))avail.UnionWith(Obd.Supported(await Send("0140"),"40"));
  foreach(var c in Obd.Channels.Where(x=>avail.Contains(x.Pid))){var b=Obd.Extract(await Send("01"+c.Pid),"41",c.Pid);if(b!=null&&c.Decode(b)!=null)supported.Add(c);}
  channels.Text=supported.Count+" verified channels: "+string.Join(", ",supported.Select(x=>x.Name));start.IsEnabled=supported.Count>0;
 }catch(Exception ex){Log("PID discovery failed: "+ex.Message);}finally{busy=false;discover.IsEnabled=true;}}
 async Task Scan(){if(elm==null||busy)return;busy=true;scan.IsEnabled=false;try{
  var all=new List<string>();foreach(var (cmd,mode,label) in new[]{("03","43","Stored"),("07","47","Pending"),("0A","4A","Permanent")}){
   var raw=await Send(cmd);var codes=Obd.Faults(raw,mode);all.Add(label+": "+(codes.Count==0?"None decoded / unsupported":string.Join(", ",codes)));
  }faults.Text=string.Join("\n",all);
 }catch(Exception ex){Log("Fault scan: "+ex.Message);}finally{busy=false;scan.IsEnabled=true;}}
 async Task Start(){if(elm==null||supported.Count==0||cts!=null)return;
  records.Clear();records.Add("timestamp_utc,elapsed_ms,customer,bike,run,pid,parameter,value,unit,raw_response");began=DateTimeOffset.UtcNow;cts=new CancellationTokenSource();start.IsEnabled=false;scan.IsEnabled=false;discover.IsEnabled=false;stop.IsEnabled=true;status.Text="RECORDING";
  _=Poll(cts.Token);
 }
 async Task Poll(CancellationToken ct){try{while(!ct.IsCancellationRequested){foreach(var ch in supported){ct.ThrowIfCancellationRequested();
  try{var raw=await Send("01"+ch.Pid,ct);var b=Obd.Extract(raw,"41",ch.Pid);if(b==null)continue;var v=ch.Decode(b);if(v==null)continue;
   var now=DateTimeOffset.UtcNow;records.Add(string.Join(",",new[]{now.ToString("O"),(now-began).TotalMilliseconds.ToString("F0",CultureInfo.InvariantCulture),Q(customer.Text),Q(bike.Text),Q(run.Text),ch.Pid,Q(ch.Name),v.Value.ToString(CultureInfo.InvariantCulture),Q(ch.Unit),Q(raw)}));
   if(ch.Pid is "0C" or "11" or "0B")MainThread.BeginInvokeOnMainThread(()=>live.Text=$"{ch.Name}: {v.Value:0.##} {ch.Unit}");
  }catch(OperationCanceledException){throw;}catch(Exception ex){Log("Polling: "+ex.Message);await Task.Delay(200,ct);}
 }}}catch(OperationCanceledException){}finally{MainThread.BeginInvokeOnMainThread(()=>status.Text=$"Stopped — {records.Count-1} samples");}}
 static string Q(string? v)=>"\""+(v??"").Replace("\"","\"\"").Replace('\r',' ').Replace('\n',' ')+"\"";
 async Task Stop(){if(cts==null)return;cts.Cancel();await Task.Delay(250);cts.Dispose();cts=null;stop.IsEnabled=false;start.IsEnabled=true;scan.IsEnabled=true;discover.IsEnabled=true;
  try{var path=Path.Combine(FileSystem.CacheDirectory,$"Boostech_{DateTime.Now:yyyyMMdd_HHmmss}.csv");await File.WriteAllLinesAsync(path,records,Encoding.UTF8);
   await Share.Default.RequestAsync(new ShareFileRequest{Title="Export Boostech CSV",File=new ShareFile(path,"text/csv")});Log($"CSV exported: {records.Count-1} samples");
  }catch(Exception ex){Log("Export failed: "+ex.Message);}
 }
 protected override void OnDisappearing(){base.OnDisappearing();cts?.Cancel();}
}
public class BluetoothPermission:Permissions.BasePlatformPermission {
 public override (string androidPermission,bool isRuntime)[] RequiredPermissions=>Android.OS.Build.VERSION.SdkInt>=Android.OS.BuildVersionCodes.S?new[]{("android.permission.BLUETOOTH_CONNECT",true)}:Array.Empty<(string,bool)>();
}
