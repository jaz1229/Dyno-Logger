# Boostech Dyno Logger 3.2 — ELM stability + PID catalog groundwork

### Changes
- Serialize all ELM requests with a SemaphoreSlim.
- Do **not** clear the serial receive buffer before each command.
- Require the ELM `>` prompt before sending another request; after timeout, wait for recovery or require reconnect.
- Longer timeout for first ECU requests (7 seconds).
- Discover supported Mode 01 PID bitmaps first; verify only advertised channels plus two known standard fallbacks (010E ignition, 0133 barometric pressure).
- Stop discovery on a transport timeout rather than causing repeated STOPPED replies.
- Cancel Discovery button; retain successfully verified channels on cancellation or error.
- Add missing standard PID 0133 decoder.
- `Windows/pid_catalog_reference.json` provides a starter **standard** PID catalog and explicit OEM enhancement placeholders.

### Limits
The manufacturer list is a **reference catalog**, not working proprietary diagnostics. Actual VW/BMW/Honda enhanced channels require ECU-specific verified request IDs, transport/session support, data decoding, and testing. The app does not auto-detect arbitrary proprietary ECU channels.
No Windows .NET compiler or physical ELM adapter was available here; this is uncompiled source and needs validation.
Build on Windows using `Windows/PUBLISH_EXE.bat`.
