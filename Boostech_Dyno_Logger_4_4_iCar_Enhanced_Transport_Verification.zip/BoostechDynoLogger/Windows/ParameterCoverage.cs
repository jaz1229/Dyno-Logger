using System.Text.Json;
namespace BoostechDynoLogger;
public sealed record DesiredParameter(string Name,string[] StandardPids,string[] VehicleTypes,string Note);
public sealed record ParameterStatus(string Name,string State,string Source,string Note);
public static class ParameterCoverage {
 public static readonly DesiredParameter[] Targets=[
  new("Engine RPM",["0C"],["all"],"Standard OBD2; J1939 SPN 190 on supported heavy-duty networks"),
  new("Engine load",["04","43"],["all"],"Calculated or absolute engine load"),
  new("Throttle / pedal",["11","45","49","4A","4B","5A"],["all"],"Pedal and throttle are distinct signals"),
  new("Ignition advance",["0E"],["Car","Ute","Van","Motorcycle"],"Generic ignition advance is NOT cylinder knock correction"),
  new("Knock retard by cylinder",[],["Car","Ute","Van","Motorcycle"],"Requires verified OEM measuring values, protocol and ECU family"),
  new("Manifold absolute pressure",["0B"],["all"],"Absolute pressure, not gauge boost"),
  new("Barometric pressure",["33"],["all"],"Used with MAP to calculate approximate gauge boost"),
  new("Boost target",[],["all"],"Requires verified OEM/UDS/KWP/J1939 signal"),
  new("Boost actual (gauge)",["0B","33"],["all"],"Calculated only when BOTH MAP and barometric pressure are valid"),
  new("Wastegate / VGT command",[],["all"],"OEM or J1939 definition required"),
  new("Lambda / equivalence ratio",["24","25","26","27","28","29","2A","2B","34","35","36","37","38","39","3A","3B","44"],["all"],"Equivalence ratio may be measured or commanded depending on PID"),
  new("Fuel rail pressure",["22","23","59"],["all"],"Different PIDs have different pressure references/scales"),
  new("Fuel trims",["06","07","08","09"],["Car","Ute","Van","Motorcycle"],"Generic OBD fuel trims"),
  new("Intake air temperature",["0F"],["all"],"Standard intake temperature"),
  new("Coolant temperature",["05"],["all"],"Standard coolant temperature"),
  new("Engine oil temperature",["5C"],["all"],"Where supported"),
  new("Exhaust gas temperature",[],["all"],"OEM or J1939 measurement; generic PID decoding not implemented"),
  new("DPF differential pressure",[],["Ute","Van","Truck","Bus","Tractor","Industrial"],"OEM/J1939 profile needed"),
  new("DPF soot load",[],["Ute","Van","Truck","Bus","Tractor","Industrial"],"OEM/J1939 profile needed"),
  new("Injector correction / balance",[],["all"],"ECU-specific measurement"),
  new("Transmission temperature",[],["all"],"Transmission controller may require separate ECU address"),
  new("Misfire by cylinder",[],["Car","Ute","Van","Motorcycle"],"Mode 06 or OEM diagnostic support required"),
  new("Engine fuel rate",["5E"],["all"],"Where supported"),
  new("Vehicle speed",["0D"],["all"],"Where supported")
 ];
 public static IReadOnlyList<ParameterStatus> Evaluate(string vehicleType,IReadOnlyCollection<string> verified){
  var ids=new HashSet<string>(verified,StringComparer.OrdinalIgnoreCase);
  return Targets.Where(x=>x.VehicleTypes.Contains("all")||x.VehicleTypes.Contains(vehicleType,StringComparer.OrdinalIgnoreCase))
   .Select(x=>{
    if(x.Name=="Boost actual (gauge)")return new ParameterStatus(x.Name,ids.Contains("0B")&&ids.Contains("33")?"DERIVABLE":"NOT AVAILABLE",ids.Contains("0B")&&ids.Contains("33")?"MAP − BARO":"Needs both 010B and 0133",x.Note);
    var found=x.StandardPids.Where(ids.Contains).ToArray();
    return new ParameterStatus(x.Name,found.Length>0?"AVAILABLE":"NOT AVAILABLE",found.Length>0?"Mode 01: "+string.Join(", ",found):"No verified standard PID",x.Note);
   }).ToArray();
 }
 public static string JsonReport(string category,IReadOnlyCollection<string> verified)=>JsonSerializer.Serialize(new{
  format="boostech-parameter-coverage-v1",category,checkedUtc=DateTime.UtcNow,
  caution="Availability means a standard PID was verified. It does not prove sensor accuracy or OEM compatibility.",
  parameters=Evaluate(category,verified)
 },new JsonSerializerOptions{WriteIndented=true});
}
