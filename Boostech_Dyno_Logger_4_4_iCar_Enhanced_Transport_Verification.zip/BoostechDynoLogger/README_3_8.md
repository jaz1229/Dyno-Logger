# Boostech Dyno Logger 3.8 — Multi-vehicle architecture preview

## Working source additions
- More vehicle categories: cars, bikes, utes/vans, heavy trucks, buses, tractors, marine and industrial.
- Explicit transport capability report: never misrepresent J2534, J1939, NMEA2000, UDS or KWP as working.
- Passive **offline** J1939 CAN log importer (8-digit 29-bit CAN ID + eight 2-digit hex bytes), decoded into its own tab.
- J1939 EEC1 engine RPM (SPN 190), EEC2 accelerator pedal (SPN 91), ET1 coolant temp (SPN 110), EFL/P1 oil pressure (SPN 100), with J1939 unavailable-value handling.
- No new ECU writes or undocumented proprietary commands. Retains previous standard OBD2 PID library, ECU identification, profiles, YourDyno/CSV analyser, Bluetooth logging and layout.

## Critical limitations
- **No live J1939 bus monitoring yet**. Importer accepts only simple line-oriented text with 8-byte frames, not candump ASC/BLF/MF4 or J1939 transport reassembly.
- J1939 signal definitions are a small initial set, not comprehensive. Source addresses are preserved.
- Standard ELM/vLinker serial OBD2 works on supported vehicles, but vLinker hardware variants differ. No automatic OEM enhanced PID support yet.
- J2534 is experimental and not validated; manufacturer-specific KWP/UDS, NMEA 2000, heavy-duty truck adapters and 24V safety are not implemented.
- **Not compiled or hardware tested** in this environment. Run `Windows/PUBLISH_EXE.bat` on Windows with .NET 10 SDK and share build errors and ECU reports.

## Supported J1939 import format
```
0CF00400 FF FF FF 20 4E FF FF FF
18FEEE00 64 FF FF FF FF FF FF FF
```
The first line reports 2500 rpm (0x4E20 * 0.125); the second reports coolant temperature 60°C (0x64 - 40).

## Roadmap
1. Build + test simulator/ELM regression; fix any compiler errors.
2. Add protocol-specific adapter capability probes (model-specific, read-only).
3. Add ISO-TP multi-frame UDS read-only identification, then OEM profiles keyed by exact ECU identifiers.
4. Add validated J1939 live monitor via suitable hardware and NMEA 2000 separately.
5. Test every supported ECU family against reference diagnostic equipment before using on dyno pulls.
