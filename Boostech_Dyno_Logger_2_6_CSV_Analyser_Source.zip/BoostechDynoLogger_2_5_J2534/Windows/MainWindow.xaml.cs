using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Text.Json;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
namespace BoostechDynoLogger;
public sealed class ChannelRow : INotifyPropertyChanged {
 public string Pid {get;init;}="";public string Name {get;init;}="";
 private string display="—",updated="—";
 public string Display {get=>display;set{display=value;PropertyChanged?.Invoke(this,new(nameof(Display)));}}
 public string Updated {get=>updated;set{updated=value;PropertyChanged?.Invoke(this,new(nameof(Updated)));}}
 public event PropertyChangedEventHandler? PropertyChanged;
}
public partial class MainWindow : Window {
 private IObdTransport? transport;private CancellationTokenSource? polling;
 private readonly ObservableCollection<ChannelRow> rows=[];
 private readonly Dictionary<string,PidDef> supported=new();
 private readonly Dictionary<string,double> lastValues=new();
 private StreamWriter? csv;private DateTime sessionStart;private Stopwatch? sessionClock;private string activeCustomer="",activeBike="",activeRun="",activeVehicleType="",activeManufacturer="",activeModel="",activeYear="";private int activeProfile;private string? sessionFolder;private readonly Dictionary<string,long> lastSampleTicks=new();private long sampleCount;private string? lastCsvPath;
 public MainWindow(){InitializeComponent();ChannelsGrid.ItemsSource=rows;InitializeVehicleSelection();ModeBox.SelectionChanged+=(_,_)=>RefreshPorts();RefreshPorts();Closing+=(_,_)=>{polling?.Cancel();csv?.Dispose();transport?.Dispose();};}
 private static readonly Dictionary<string,string[]> Makes = new(){
  ["Car"]=["Audi","BMW","Ford","Honda","Hyundai","Mazda","Mercedes-Benz","Mitsubishi","Nissan","Subaru","Toyota","Volkswagen","Other"],
  ["Motorcycle"]=["Aprilia","BMW","Ducati","Harley-Davidson","Honda","Kawasaki","KTM","Suzuki","Triumph","Yamaha","Other"],
  ["Tractor"]=["Case IH","Claas","Deutz-Fahr","Fendt","John Deere","Kubota","Massey Ferguson","New Holland","Other"],
  ["Marine"]=["Evinrude","Honda Marine","Mercury","MerCruiser","Suzuki Marine","Volvo Penta","Yamaha Marine","Yanmar","Other"]
 };
 private void InitializeVehicleSelection(){PopulateMakes("Motorcycle","Honda");}
 private void VehicleType_Changed(object sender,SelectionChangedEventArgs e){
  if(ManufacturerBox is null || VehicleTypeBox?.SelectedItem is not ComboBoxItem item)return;
  var category=item.Content?.ToString()??"Motorcycle";
  PopulateMakes(category,category=="Motorcycle"?"Honda":null);
 }
 private void PopulateMakes(string category,string? preferred){
  ManufacturerBox.ItemsSource=Makes.TryGetValue(category,out var makes)?makes:Array.Empty<string>();
  ManufacturerBox.Text=preferred??"";
 }
 private string VehicleCategory => (VehicleTypeBox.SelectedItem as ComboBoxItem)?.Content?.ToString()??"Motorcycle";
 private void RefreshPorts(){
  if(ModeBox.SelectedIndex==2){
   var devices=J2534Discovery.Find();
   PortBox.ItemsSource=devices.Select(x=>x.Name+" | "+x.DllPath).ToArray();
   StatusText.Text=devices.Count==0?"No installed J2534 driver found":$"{devices.Count} J2534 driver(s) detected — CAN logging available (untested)";
  }else PortBox.ItemsSource=SerialPort.GetPortNames().OrderBy(x=>x).ToArray();
  if(PortBox.Items.Count>0)PortBox.SelectedIndex=0;
 }
 private void OpenCsvViewer_Click(object s,RoutedEventArgs e){var viewer=new CsvViewerWindow(lastCsvPath){Owner=this};viewer.Show();}
 private void RefreshPorts_Click(object s,RoutedEventArgs e)=>RefreshPorts();
 private void Log(string line){Dispatcher.Invoke(()=>{ConsoleBox.AppendText($"[{DateTime.Now:HH:mm:ss.fff}] {line}\n");ConsoleBox.ScrollToEnd();});}
 private async Task<string> Send(string command,CancellationToken ct=default){if(transport is null)throw new InvalidOperationException("Not connected");string r=await transport.RequestAsync(command,ct);Log($"> {command}  |  {r.Replace("\r"," ").Replace("\n"," ").Trim()}");return r;}
 private async void Connect_Click(object s,RoutedEventArgs e){
  ConnectButton.IsEnabled=false;
  try{
   if(ModeBox.SelectedIndex==2){
    var devices=J2534Discovery.Find();
    if(devices.Count==0)throw new InvalidOperationException("No J2534 driver installed. Install the genuine Tactrix Openport driver first.");
    var selected=PortBox.SelectedIndex;
    if(selected<0||selected>=devices.Count)throw new InvalidOperationException("Select a J2534 driver first.");
    transport=new J2534CanTransport(devices[selected].DllPath);
   }
   bool sim=ModeBox.SelectedIndex==0;
   if(ModeBox.SelectedIndex==1&&PortBox.SelectedItem is null)throw new InvalidOperationException("Pair Bluetooth and select the outgoing COM port first. BLE-only connections are not implemented.");
   if(ModeBox.SelectedIndex!=2)transport=sim?new SimulatorTransport():new SerialElmTransport(PortBox.SelectedItem!.ToString()!);
   StatusText.Text=sim?"SIMULATION — not real ECU data":"Connecting to ECU...";
   foreach(var cmd in new[]{"ATZ","ATE0","ATL0","ATS1","ATH0","ATSP0"})await Send(cmd);
   StatusText.Text=sim?"SIMULATOR CONNECTED":"ADAPTER CONNECTED — ECU unverified";
   DisconnectButton.IsEnabled=true;DiscoverButton.IsEnabled=true;ScanButton.IsEnabled=true;
  }catch(Exception ex){Log("CONNECT ERROR: "+ex.Message);StatusText.Text="Connection failed";transport?.Dispose();transport=null;ConnectButton.IsEnabled=true;}
 }
 private async void Discover_Click(object s,RoutedEventArgs e){
  DiscoverButton.IsEnabled=false;StartButton.IsEnabled=false;rows.Clear();supported.Clear();lastValues.Clear();
  try{
   var raw=await Send("0100");var available=Pids.DecodeSupported(raw,"00");
   if(available.Contains("20")){raw=await Send("0120");available.UnionWith(Pids.DecodeSupported(raw,"20"));}
   if(available.Contains("40")){raw=await Send("0140");available.UnionWith(Pids.DecodeSupported(raw,"40"));}
   if(available.Contains("60")){raw=await Send("0160");available.UnionWith(Pids.DecodeSupported(raw,"60"));}
   foreach(var def in Pids.All.Where(p=>available.Contains(p.Id))){
    // Validate each advertised PID responds before enabling it.
    var result=await Send("01"+def.Id);var bytes=Pids.Extract(result,def.Id);
    if(bytes is null||def.Decode(bytes) is null){Log($"Skipping {def.Id}: advertised but no decodable response");continue;}
    supported.Add(def.Id,def);var row=new ChannelRow{Pid=def.Id,Name=def.Name};rows.Add(row);Update(row,def,bytes);
   }
   StatusText.Text=$"{supported.Count} responsive PIDs — "+(ModeBox.SelectedIndex==0?"SIMULATED":"ECU read verified");
   StartButton.IsEnabled=supported.Count>0;
  }catch(Exception ex){Log("DISCOVERY ERROR: "+ex.Message);StatusText.Text="Discovery failed";}
  finally{DiscoverButton.IsEnabled=true;}
 }
 private void Update(ChannelRow row,PidDef def,byte[] bytes){var value=def.Decode(bytes);if(value is null)return;lastValues[def.Id]=value.Value;row.Display=$"{value.Value:0.##} {def.Unit}";row.Updated=DateTime.UtcNow.ToString("HH:mm:ss.fff");
  if(def.Id=="0C")RpmText.Text=$"{value.Value:0} rpm";if(def.Id=="11")TpsText.Text=$"{value.Value:0.#} %";if(def.Id=="05")CoolantText.Text=$"{value.Value:0} °C";if(def.Id=="0B")MapText.Text=$"{value.Value:0} kPa";
 }
 private async void Start_Click(object s,RoutedEventArgs e){
  var dlg=new SaveFileDialog{Filter="CSV files (*.csv)|*.csv",FileName=$"Boostech_Run_{DateTime.Now:yyyyMMdd_HHmmss}.csv"};if(dlg.ShowDialog()!=true)return;
  try{
   lastCsvPath=dlg.FileName;sessionFolder=Path.Combine(Path.GetDirectoryName(dlg.FileName)!,Path.GetFileNameWithoutExtension(dlg.FileName)+"_files");Directory.CreateDirectory(sessionFolder);
   var metadata=new {version="2.5",createdUtc=DateTime.UtcNow,vehicleCategory=VehicleCategory,manufacturer=ManufacturerBox.Text,model=ModelBox.Text,year=YearBox.Text,customer=CustomerBox.Text,vehicleId=BikeBox.Text,run=RunBox.Text,transport=ModeBox.SelectedIndex==0?"simulator":ModeBox.SelectedIndex==2?"J2534 ISO15765 11/500":"serial",profile=ProfileBox.Text,pids=supported.Values.Select(x=>new{x.Id,x.Name,x.Unit}).ToArray(),notes="ECU support determined by live PID discovery; no proprietary PIDs validated"};
   await File.WriteAllTextAsync(Path.Combine(sessionFolder,"session.json"),JsonSerializer.Serialize(metadata,new JsonSerializerOptions{WriteIndented=true}));
   csv=new StreamWriter(dlg.FileName,false,new UTF8Encoding(true));
   await csv.WriteLineAsync("timestamp_utc,elapsed_ms,vehicle_category,manufacturer,model,year,customer,vehicle_id,run,pid,parameter,value,unit,raw_response,interval_ms");
   sessionStart=DateTime.UtcNow;activeProfile=ProfileBox.SelectedIndex;activeCustomer=CustomerBox.Text;activeBike=BikeBox.Text;activeRun=RunBox.Text;activeVehicleType=VehicleCategory;activeManufacturer=ManufacturerBox.Text;activeModel=ModelBox.Text;activeYear=YearBox.Text;sessionClock=Stopwatch.StartNew();lastSampleTicks.Clear();sampleCount=0;polling=new CancellationTokenSource();
   ProfileBox.IsEnabled=false;StartButton.IsEnabled=false;DiscoverButton.IsEnabled=false;ScanButton.IsEnabled=false;StopButton.IsEnabled=true;StatusText.Text="RECORDING";
   _=PollLoop(polling.Token);
  }catch(Exception ex){Log("LOGGING ERROR: "+ex.Message);csv?.Dispose();csv=null;}
 }
 private async Task PollLoop(CancellationToken ct){
  // Sequential single-PID polling, with no unsupported proprietary commands.
  try{while(!ct.IsCancellationRequested){
   foreach(var def in PollOrder()){ct.ThrowIfCancellationRequested();
    try{
     string raw=await Send("01"+def.Id,ct);var bytes=Pids.Extract(raw,def.Id);if(bytes is null){Log("NO DATA for "+def.Id);continue;}
     double? value=def.Decode(bytes);if(value is null)continue;
     var row=rows.First(x=>x.Pid==def.Id);await Dispatcher.InvokeAsync(()=>Update(row,def,bytes));
     var now=DateTime.UtcNow;long elapsed=sessionClock?.ElapsedMilliseconds??0;string interval=lastSampleTicks.TryGetValue(def.Id,out long previous)?(elapsed-previous).ToString():"";lastSampleTicks[def.Id]=elapsed;var safeRaw=raw.Replace('"','\'').Replace('\r',' ').Replace('\n',' ');
     if(csv is not null)await csv.WriteLineAsync($"{now:O},{elapsed},{CsvField(activeVehicleType)},{CsvField(activeManufacturer)},{CsvField(activeModel)},{CsvField(activeYear)},{CsvField(activeCustomer)},{CsvField(activeBike)},{CsvField(activeRun)},{def.Id},{CsvField(def.Name)},{value.Value.ToString(System.Globalization.CultureInfo.InvariantCulture)},{CsvField(def.Unit)},{CsvField(safeRaw)},{interval}");
     sampleCount++;if(sampleCount%20==0&&csv is not null)await csv.FlushAsync(ct);
    }catch(OperationCanceledException){throw;}catch(Exception ex){Log($"POLL {def.Id}: {ex.Message}");await Task.Delay(200,ct);}
   }
  }}catch(OperationCanceledException){}catch(Exception ex){Log("POLL LOOP STOPPED: "+ex.Message);}finally{
   if(csv is not null){try{await csv.FlushAsync();await csv.DisposeAsync();}catch(Exception ex){Log("CSV SAVE ERROR: "+ex.Message);}csv=null;}
   await Dispatcher.InvokeAsync(()=>{ProfileBox.IsEnabled=true;StopButton.IsEnabled=false;StartButton.IsEnabled=supported.Count>0;DiscoverButton.IsEnabled=transport is not null;ScanButton.IsEnabled=transport is not null;StatusText.Text=$"Stopped — {sampleCount} samples";});
  }
 }
 private IEnumerable<PidDef> PollOrder(){
  var all=supported.Values.ToArray();int profile=activeProfile;
  string[] high=profile switch {0=>["0C","11","0B","0E","24","34","05","0F"],1=>["0C","11","0B","0E","05","0F","42"],2=>["05","0F","5C","42","0C","11"],_=>[]};
  if(profile==3)return all;
  // Repeating high-priority channels increases their share of sequential requests;
  // actual rates are ECU/adapter dependent, never guaranteed.
  var ordered=high.Where(supported.ContainsKey).Select(id=>supported[id]).ToList();
  if(profile==0)ordered.InsertRange(0,high.Take(3).Where(supported.ContainsKey).Select(id=>supported[id]));
  ordered.AddRange(all.Where(x=>!high.Contains(x.Id)));return ordered;
 }
 private static string CsvField(string value)=>"\""+value.Replace("\"","\"\"").Replace("\r"," ").Replace("\n"," ")+"\"";
 private void Stop_Click(object s,RoutedEventArgs e){polling?.Cancel();StopButton.IsEnabled=false;}
 private void Disconnect_Click(object s,RoutedEventArgs e){if(polling is not null&&!polling.IsCancellationRequested){MessageBox.Show("Stop logging and wait for CSV to save before disconnecting.");return;}transport?.Dispose();transport=null;ConnectButton.IsEnabled=true;DisconnectButton.IsEnabled=false;DiscoverButton.IsEnabled=false;ScanButton.IsEnabled=false;StartButton.IsEnabled=false;rows.Clear();supported.Clear();StatusText.Text="Disconnected";}
 private async void Send_Click(object s,RoutedEventArgs e){
  if(transport is null){MessageBox.Show("Connect first");return;}
  if(polling is not null&&!polling.IsCancellationRequested){MessageBox.Show("Stop logging before sending requests.");return;}
  string cmd=CommandBox.Text.Trim().ToUpperInvariant().Replace(" ","");
  // Whitelist strictly read-only generic Mode 01 queries.
  if(cmd.Length!=4||!cmd.StartsWith("01")||!byte.TryParse(cmd.Substring(2),System.Globalization.NumberStyles.HexNumber,null,out _)){MessageBox.Show("Only Mode 01 PID reads (e.g. 010C) are allowed.");return;}
  try{await Send(cmd);}catch(Exception ex){Log("REQUEST ERROR: "+ex.Message);}
 }
 private async void Scan_Click(object sender,RoutedEventArgs e){
  if(transport is null)return;
  if(polling is not null&&!polling.IsCancellationRequested){MessageBox.Show("Stop logging before scanning.");return;}
  ScanButton.IsEnabled=false;
  try{
   var report=new List<string>{"section,request,result"};
   foreach(var (cmd,label,mode) in new[]{("03","Stored", "43"),("07","Pending","47"),("0A","Permanent","4A")}){
    var raw=await Send(cmd);
    var codes=FaultCodes.Parse(raw,mode);
    var outcome=codes.Count>0?string.Join("; ",codes):raw.Contains("NO DATA",StringComparison.OrdinalIgnoreCase)?"not available / no response":"none decoded";
    Log($"{label} DTCs: "+outcome);report.Add($"{CsvField(label)},{cmd},{CsvField(outcome)}");
   }
   foreach(var (cmd,label) in new[]{("0902","VIN"),("0904","Calibration IDs"),("0906","CVN"),("0200","Freeze-frame support")}){try{var raw=await Send(cmd);report.Add($"{CsvField(label)},{cmd},{CsvField(raw.Replace((char)13,' ').Replace((char)10,' '))}");}catch(Exception ex){report.Add($"{CsvField(label)},{cmd},{CsvField(ex.Message)}");}}
   var save=new SaveFileDialog{Filter="CSV files (*.csv)|*.csv",FileName=$"Boostech_Scan_{DateTime.Now:yyyyMMdd_HHmmss}.csv"};
   if(save.ShowDialog()==true)await File.WriteAllLinesAsync(save.FileName,report);
   Log("Scan is read-only; fault codes have not been cleared. ECU info responses saved raw (not yet decoded).");
  }catch(Exception ex){Log("SCAN ERROR: "+ex.Message);}finally{ScanButton.IsEnabled=transport is not null;}
 }
 private void SaveConsole_Click(object s,RoutedEventArgs e){var dlg=new SaveFileDialog{Filter="Text log (*.txt)|*.txt",FileName="Boostech_Console.txt"};if(dlg.ShowDialog()==true)File.WriteAllText(dlg.FileName,ConsoleBox.Text);}
}
