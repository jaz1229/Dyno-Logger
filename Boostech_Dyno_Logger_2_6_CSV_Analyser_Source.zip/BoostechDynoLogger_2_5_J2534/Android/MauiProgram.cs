using Microsoft.Extensions.Logging;
namespace BoostechMobile;
public static class MauiProgram { public static MauiApp CreateMauiApp(){var b=MauiApp.CreateBuilder();b.UseMauiApp<App>();return b.Build();} }
