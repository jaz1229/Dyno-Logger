namespace BoostechMobile;
public class App:Application {public App(){MainPage=new NavigationPage(new MainPage()){BarBackgroundColor=Color.FromArgb("#101B2B"),BarTextColor=Colors.White};}}
