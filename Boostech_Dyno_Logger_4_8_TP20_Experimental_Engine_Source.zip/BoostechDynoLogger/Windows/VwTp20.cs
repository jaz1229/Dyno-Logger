using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
namespace BoostechDynoLogger;
// TP 2.0 is a separate transport from ISO-TP/UDS. This module handles raw
// CAN frame validation and VW TP2.0 channel-setup packet construction only.
// A complete session needs channel negotiation, sequence/ack handling,
// keepalive, segmentation and KWP2000 measuring-block decoding.
public readonly record struct Can11Frame(ushort Id, byte[] Data) {
 public string ElmPayload => Convert.ToHexString(Data);
 public static Can11Frame Parse(string line) {
  var tokens=Regex.Split(line.Trim(),@"\s+");
  if(tokens.Length<2||tokens[0].Length!=3||!ushort.TryParse(tokens[0],NumberStyles.HexNumber,CultureInfo.InvariantCulture,out var id)||id>0x7FF)
   throw new FormatException("Expected 11-bit CAN header followed by bytes");
  if(tokens.Length>9)throw new FormatException("CAN frame exceeds 8 data bytes");
  var bytes=new List<byte>();
  foreach(var token in tokens.Skip(1)){
   if(token.Length!=2||!byte.TryParse(token,NumberStyles.HexNumber,CultureInfo.InvariantCulture,out var b))throw new FormatException("Invalid CAN byte");
   bytes.Add(b);
  }
  return new(id,bytes.ToArray());
 }
}
public static class VwTp20 {
 // Volkswagen TP2.0 channel setup request is sent to CAN ID 0x200.
 // The destination module is encoded in the first data byte. For module 01
 // (engine), channel request payload is 01 C0 00 10 00 03 01.
 // DO NOT transmit until hardware support and ECU applicability are verified.
 public static Can11Frame ChannelSetupRequest(byte moduleAddress) =>
  new(0x200,new byte[]{moduleAddress,0xC0,0x00,0x10,0x00,0x03,0x01});
 public static string ExplainSetupReply(Can11Frame frame){
  if(frame.Id!=0x200)return "Not a TP2.0 setup response on CAN 0x200";
  if(frame.Data.Length<7)return "Incomplete channel setup reply";
  if(frame.Data[1]!=0xD0)return "No recognized TP2.0 channel acceptance (D0)";
  var txId=frame.Data[2]|((frame.Data[3]&0x0F)<<8);
  var rxId=frame.Data[4]|((frame.Data[5]&0x0F)<<8);
  return $"Potential TP2.0 channel accepted: tx=0x{txId:X3}, rx=0x{rxId:X3}; requires sequence/ACK and KWP layer";
 }
 // Offline parser deliberately does not claim to establish a live session.
 public static string AnalyzeRawResponse(string raw){
  var notes=new List<string>();
  foreach(var line in raw.Split(new[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries)){
   try{var f=Can11Frame.Parse(line);notes.Add($"0x{f.Id:X3}: {Convert.ToHexString(f.Data)} — {ExplainSetupReply(f)}");}
   catch(FormatException){}
  }
  return notes.Count==0?"No decodable raw CAN frames":string.Join("\n",notes);
 }
}
