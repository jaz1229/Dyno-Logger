using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using Android.Bluetooth;
using Java.Util;
namespace BoostechMobile;
public record Channel(string Pid,string Name,string Unit,Func<byte[],double?> Decode);
public static class Obd {
 public static readonly Channel[] Channels={
 new("04","Engine load","%",b=>b.Length>0?b[0]*100d/255:null),new("05","Coolant","°C",b=>b.Length>0?b[0]-40:null),
 new("06","Short fuel trim","%",b=>b.Length>0?(b[0]-128)*100d/128:null),new("07","Long fuel trim","%",b=>b.Length>0?(b[0]-128)*100d/128:null),
 new("0B","MAP","kPa",b=>b.Length>0?b[0]:null),new("0C","RPM","rpm",b=>b.Length>1?(b[0]*256+b[1])/4d:null),
 new("0D","Speed","km/h",b=>b.Length>0?b[0]:null),new("0E","Ignition advance","°",b=>b.Length>0?b[0]/2d-64:null),
 new("0F","Intake temp","°C",b=>b.Length>0?b[0]-40:null),new("11","Throttle","%",b=>b.Length>0?b[0]*100d/255:null),
 new("42","ECU voltage","V",b=>b.Length>1?(b[0]*256+b[1])/1000d:null),
 new("14","O2 sensor 1","V",b=>b.Length>1?b[0]/200d:null),new("24","O2 lambda","λ",b=>b.Length>3?(b[0]*256+b[1])*2d/65536:null),
 new("34","O2 lambda current","λ",b=>b.Length>3?(b[0]*256+b[1])*2d/65536:null)};
 public static byte[]? Extract(string raw,string mode,string? pid=null){
  foreach(var line in raw.ToUpperInvariant().Split(new[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries)){
   var s=Regex.Replace(line.Trim(),@"^\d+:\s*","");
   // Remove CAN ID when present, retain byte tokens. Avoid interpreting the echoed request.
   var parts=Regex.Matches(s,@"(?<![0-9A-F])[0-9A-F]{2}(?![0-9A-F])").Select(m=>m.Value).ToList();
   if(parts.Count<2){var c=Regex.Replace(s,@"[^0-9A-F]","");if(c.Length%2==0&&c.Length>=4)parts=Enumerable.Range(0,c.Length/2).Select(i=>c.Substring(i*2,2)).ToList();}
   for(int i=0;i<parts.Count;i++)if(parts[i]==mode&&(pid==null||(i+1<parts.Count&&parts[i+1]==pid)))
    return parts.Skip(i+1+(pid==null?0:1)).Select(x=>byte.Parse(x,NumberStyles.HexNumber)).ToArray();
  }return null;
 }
 public static HashSet<string> Supported(string raw,string pid){var b=Extract(raw,"41",pid);var h=new HashSet<string>();if(b==null||b.Length<4)return h;int start=Convert.ToInt32(pid,16);for(int i=0;i<32;i++)if((b[i/8]&(1<<(7-i%8)))!=0)h.Add((start+i+1).ToString("X2"));return h;}
 public static List<string> Faults(string raw,string responseMode){
  var b=Extract(raw,responseMode);var result=new List<string>();if(b==null)return result;
  for(int i=0;i+1<b.Length;i+=2){int v=b[i]*256+b[i+1];if(v==0)continue;result.Add($"{ "PCBU"[(v>>14)&3]}{(v>>12)&3}{v&0xFFF:X3}");}return result;
 }
}
public interface IElm:IDisposable {Task<string> Send(string command,CancellationToken ct);}
public sealed class DemoElm:IElm {
 readonly System.Diagnostics.Stopwatch watch=System.Diagnostics.Stopwatch.StartNew();
 public Task<string> Send(string cmd,CancellationToken ct){ct.ThrowIfCancellationRequested();cmd=cmd.ToUpperInvariant();
 if(cmd.StartsWith("AT"))return Task.FromResult(cmd=="ATDP"?"AUTO CAN\r>":"OK\r>");
 if(cmd is "03" or "07" or "0A")return Task.FromResult((cmd=="03"?"43":cmd=="07"?"47":"4A")+" 00 00\r>");
 if(cmd is "0100" or "0120" or "0140"){
  int start=Convert.ToInt32(cmd.Substring(2),16);uint mask=0;
  foreach(var p in Obd.Channels){int n=Convert.ToInt32(p.Pid,16);if(n>start&&n<=start+32)mask|=1u<<(32-(n-start));}
  if(start==0)mask|=1u;if(start==32)mask|=1u;
  return Task.FromResult($"41 {cmd.Substring(2)} {(mask>>24)&255:X2} {(mask>>16)&255:X2} {(mask>>8)&255:X2} {mask&255:X2}\r>");
 }
 int rpm=(int)(3000+2000*(1+Math.Sin(watch.Elapsed.TotalSeconds)));int tps=(int)(30+60*(1+Math.Sin(watch.Elapsed.TotalSeconds))/2);
 string pid=cmd.Length==4?cmd.Substring(2):"";
 string v=pid switch {"0C"=>$"{rpm*4>>8:X2} {rpm*4&255:X2}","11"=>$"{tps*255/100:X2}","05"=>"7F","0B"=>"60","0F"=>"48","04"=>"A0","0E"=>"90","0D"=>"3C","06"=>"80","07"=>"80","42"=>"36 B0","14"=>"80 FF","24"=>"80 00 80 00","34"=>"80 00 80 00",_=>""};
 return Task.FromResult(v.Length==0?"NO DATA\r>":$"41 {pid} {v}\r>");
 }
 public void Dispose(){}
}
public sealed class BluetoothElm:IElm {
 readonly BluetoothSocket socket; readonly Stream input,output; readonly SemaphoreSlim gate=new(1,1);
 public BluetoothElm(BluetoothDevice device){
  socket=device.CreateRfcommSocketToServiceRecord(UUID.FromString("00001101-0000-1000-8000-00805F9B34FB"))!;
  socket.Connect();input=socket.InputStream!;output=socket.OutputStream!;
 }
 public async Task<string> Send(string cmd,CancellationToken ct){
  await gate.WaitAsync(ct);
  try{
   var data=Encoding.ASCII.GetBytes(cmd+"\r");await output.WriteAsync(data,ct);await output.FlushAsync(ct);
   var buf=new byte[1];var sb=new StringBuilder();using var timeout=CancellationTokenSource.CreateLinkedTokenSource(ct);timeout.CancelAfter(TimeSpan.FromSeconds(4));
   while(true){int n=await input.ReadAsync(buf,timeout.Token);if(n==0)throw new IOException("Bluetooth disconnected");if(buf[0]=='>')return sb.ToString();sb.Append((char)buf[0]);if(sb.Length>8192)throw new IOException("Oversized adapter response");}
  }finally{gate.Release();}
 }
 public void Dispose(){try{socket.Close();}catch{}socket.Dispose();gate.Dispose();}
}
