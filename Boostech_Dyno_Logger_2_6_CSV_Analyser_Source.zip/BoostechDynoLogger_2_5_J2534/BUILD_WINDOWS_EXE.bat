@echo off
cd /d "%~dp0Windows"
call PUBLISH_EXE.bat
