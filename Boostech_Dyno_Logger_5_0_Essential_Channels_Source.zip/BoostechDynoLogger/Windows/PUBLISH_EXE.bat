@echo off
cd /d "%~dp0"
where dotnet >nul 2>nul || (echo Install .NET 10 SDK from https://dotnet.microsoft.com/download & pause & exit /b 1)
dotnet publish BoostechDynoLogger.csproj -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true /p:IncludeNativeLibrariesForSelfExtract=true -o "%~dp0publish"
if errorlevel 1 (echo Build failed & pause & exit /b 1)
echo EXE ready: %~dp0publish
pause
