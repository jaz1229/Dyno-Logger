# Boostech Dyno Logger 2.3 — Multi-Vehicle Windows Edition

Adds vehicle category selection (Car, Motorcycle, Tractor, Marine), manufacturer suggestions, model/year, and vehicle identification fields. These are recorded in CSV rows and session.json. Custom manufacturers can be typed.

**Important:** Category selection changes metadata only. It does not imply compatibility with a specific ECU or protocol. Standard ELM-compatible OBD requests work only where the vehicle and adapter support them. Many tractors and marine engines require J1939, NMEA 2000, manufacturer diagnostics, different physical interfaces or adapters. Those protocols are NOT implemented.

The original simulator, Bluetooth Classic serial COM connection, PID discovery, DTC scan, and CSV logging remain. BLE-only adapters are not supported.

## Build
On Windows, double-click BUILD_WINDOWS_EXE.bat at the top level. Requires .NET 10 SDK and internet for restore. Build is not validated in this environment.
