# Boostech Dyno Logger 5.0 — Lean Edition

## Build
Extract ZIP, run `BoostechDynoLogger/Windows/PUBLISH_EXE.bat` on Windows with .NET 10 SDK installed. The generated executable will be in `Windows/publish`. Source has not been compiled in this environment (Windows/.NET SDK unavailable).

## What works in source
- New streamlined WPF dashboard with vehicle category/manufacturer metadata, Bluetooth COM ELM327 and simulator.
- SAE Mode 01 PID bitmap discovery and ECU-response-based channel decoding.
- Sequential read-only PID polling, timestamps, per-sample raw response CSV, diagnostics JSON.
- Offline J1939 29-bit frame import (CAN ID and PGN extraction only, **not** a validated SPN decoder).
- Motorcycle, marine, agriculture and truck profile categories with explicit support boundaries.

## What does NOT work yet
- VW TP2.0/KWP2000, UDS enhanced measurements, per-cylinder knock, manufacturer-specific boost target/N75, live J1939, NMEA 2000, and proprietary motorcycle diagnostic protocols.
- Tactrix J2534 is intentionally not offered in this lean build because the prior integration was not verified on hardware.
- No automatic manufacturer-specific PID identification, no dyno RPM sync, no live CAN capture.
- ELM327 devices differ; COM port and serial speed compatibility must be validated on real hardware.

## Engineering rules
Read-only commands; no actuator control or ECU flashing. Never interpret a successful adapter AT command as a successful ECU response. Only display values decoded from an actual matching ECU reply. CSV is sample/event oriented, not fixed-rate; do not treat timestamps as synchronized with dyno acquisition. Stop logging before changing adapters or running diagnostic probes. Do not rely on experimental readings for engine protection.

## Next implementation targets
1. Test this build on Windows against 2008 Golf GTI and verify CSV rows against a trusted scan tool.
2. Implement and hardware-validate a proper raw CAN J2534 backend (11/29-bit, 250/500k, receive queue and timestamps).
3. Validate VW TP2.0 channel negotiation and ECU measuring blocks using raw CAN traces.
4. Add J1939 SPN decoders and live transport for trucks/tractors, NMEA 2000 PGNs for marine, and brand/ECU-specific motorcycle diagnostics as independently tested plugins.


## 5.0 Essential Channels Update
- Discovery follows supported PID bitmap pages (00, 20, 40, 60, 80, A0, C0, E0) and verifies each displayed PID by an actual response.
- Essentials button selects dyno-relevant standard PIDs; Select all includes other verified channels. Checkboxes allow custom polling selection.
- Parameter coverage lists required dyno channels and explicitly distinguishes verified standard data from unsupported OEM enhanced measurements.
- Per-cylinder knock, requested boost, N75/wastegate duty, OEM-specific rail targets, cam targets, and clutch slip are NOT currently implemented. They cannot be delivered reliably by adding generic Mode 01 PIDs.
- ELM Bluetooth polling is sequential, so select a small channel set for useful sample rates.
- IMPORTANT: Windows build and real ECU test have not been performed in this environment.
