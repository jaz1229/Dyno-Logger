# Boostech Dyno Logger 2.2 — Windows prototype

Upgraded from the user's v2.1 Windows source. Build on Windows with `BUILD_WINDOWS_EXE.bat` in the parent folder or `PUBLISH_EXE.bat` in Windows folder. Requires .NET 10 SDK. This package is **source only**, not a precompiled EXE, and has not been compiled or motorcycle-tested here.

## New in 2.2
- Expanded standard SAE Mode 01 PID definitions; availability determined by supported bitmask and a successful live response. Unsupported channels are skipped.
- Sequential logging profiles: Dyno fast, Balanced, Thermal, All supported. These change polling priority; they do not guarantee sampling rates.
- Monotonic elapsed milliseconds and per-PID sample interval in CSV; timestamps are per reading, not simultaneous.
- Session JSON alongside each CSV with customer, bike, run and discovered channels.
- Read-only DTC scan (03/07/0A), raw Mode 09 identification requests (VIN/calibration/CVN) and a Mode 02 freeze-frame capability probe, exportable to CSV. Multi-frame ECU identification decoding is NOT implemented.
- Generic manufacturer-profile architecture is still a future step; no verified proprietary Honda, Yamaha, Kawasaki, Suzuki PIDs included.

## Known limitations
- Bluetooth Classic COM/ELM serial only; BLE is not implemented.
- Honda 2023 ECU protocol and PID availability remain unverified until the six-pin adapter arrives.
- No external wideband hardware integration; do not use generic O2 data as calibrated AFR.
- No YourDyno API integration, live graphing, or validated manufacturer-specific diagnostics yet.
- The simulator emulates only a subset of PIDs; it is not proof of ECU support.
- Do not use scan data for safety-critical decisions without a validated tool.
