using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Text.Json;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace BoostechDynoLogger;

// Dependency-free, read-only CSV plotting. Uses the same long-form CSV layout as the logger.
public sealed class CsvViewerWindow : Window
{
    private sealed record Sample(double Time, double Value);
    private sealed record RunData(string Name, string Source, Dictionary<string, List<Sample>> Channels, string RpmChannel);
    private readonly List<RunData> runs = new();
    private readonly Dictionary<string, List<Sample>> rpmSeries = new(StringComparer.OrdinalIgnoreCase);
    private readonly ComboBox xAxis = new() { Width = 150, Margin = new Thickness(5) };
    private double minRpm, maxRpm;
    private readonly Dictionary<string, List<Sample>> series = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, CheckBox> switches = new();
    private readonly Canvas plot = new() { Background = new SolidColorBrush(Color.FromRgb(15, 24, 36)), ClipToBounds = true };
    private readonly StackPanel legend = new() { Margin = new Thickness(10) };
    private readonly Dictionary<string, List<TreeViewItem>> channelBranches = new(StringComparer.OrdinalIgnoreCase);
    private readonly TextBox channelSearch = new() { Margin = new Thickness(8, 0, 8, 8), ToolTip = "Filter channel names (does not change visibility)" };
    private readonly TextBlock channelCount = new() { Margin = new Thickness(10, 0, 5, 6), Foreground = Brushes.LightGray };
    private readonly TextBlock info = new() { Foreground = Brushes.LightGray, Text = "Open a Boostech logging CSV to begin." };
    private readonly TextBlock cursor = new() { Foreground = Brushes.LightBlue };
    private readonly Slider zoom = new() { Minimum = 1, Maximum = 20, Value = 1, Width = 145, TickFrequency = 1 };
    private readonly Slider offset = new() { Minimum = 0, Maximum = 1, Value = 0, Width = 135 };
    private readonly ComboBox axis = new() { Width = 160, Margin = new Thickness(5) };
    private double totalSeconds;
    private readonly Brush[] colors = { Brushes.DeepSkyBlue, Brushes.Orange, Brushes.LimeGreen, Brushes.Violet, Brushes.Gold, Brushes.Tomato, Brushes.Cyan, Brushes.HotPink, Brushes.LightSteelBlue, Brushes.SandyBrown };

    public CsvViewerWindow(string? initialFile = null)
    {
        Title = "BOOSTECH / RPM-SYNCED DYNO ANALYSER — 3.0 Preview"; Width = 1240; Height = 780; MinWidth = 850; MinHeight = 520;
        Background = new SolidColorBrush(Color.FromRgb(16, 23, 32)); Foreground = Brushes.White;
        var layout = new DockPanel { Margin = new Thickness(12) }; Content = layout;
        var toolbar = new WrapPanel { Margin = new Thickness(0, 0, 0, 8) };
        DockPanel.SetDock(toolbar, Dock.Top); layout.Children.Add(toolbar);
        var open = new Button { Content = "Open CSV", Padding = new Thickness(15, 7, 15, 7), Margin = new Thickness(3) };
        open.Click += (_, _) => { var d = new OpenFileDialog { Filter = "CSV files|*.csv|All files|*.*" }; if (d.ShowDialog(this) == true) LoadCsv(d.FileName); };
        toolbar.Children.Add(open);
        var openDyno = new Button { Content = "Open YourDyno", Padding = new Thickness(15, 7, 15, 7), Margin = new Thickness(3) };
        openDyno.Click += (_, _) => { var d = new OpenFileDialog { Filter = "YourDyno exports|*.yourdyno|All files|*.*" }; if (d.ShowDialog(this) == true) LoadYourDyno(d.FileName); };
        toolbar.Children.Add(openDyno);
        var png = new Button { Content = "Export chart PNG", Padding = new Thickness(12, 7, 12, 7), Margin = new Thickness(3) };
        png.Click += (_, _) => ExportPng(); toolbar.Children.Add(png);
        toolbar.Children.Add(new TextBlock { Text = "  Zoom", VerticalAlignment = VerticalAlignment.Center }); toolbar.Children.Add(zoom);
        toolbar.Children.Add(new TextBlock { Text = "  Pan", VerticalAlignment = VerticalAlignment.Center }); toolbar.Children.Add(offset);
        toolbar.Children.Add(new TextBlock { Text = "  X axis", VerticalAlignment = VerticalAlignment.Center });
        xAxis.Items.Add("Time (seconds)"); xAxis.Items.Add("Engine RPM (aligned)"); xAxis.SelectedIndex = 0; toolbar.Children.Add(xAxis);
        xAxis.SelectionChanged += (_, _) => Draw();
        var clear = new Button { Content = "Clear runs", Padding = new Thickness(10, 7, 10, 7), Margin = new Thickness(3) };
        clear.Click += (_, _) => { runs.Clear(); series.Clear(); rpmSeries.Clear(); switches.Clear(); legend.Children.Clear(); channelBranches.Clear(); totalSeconds = 0; UpdateChannelCount(); info.Text = "Runs cleared."; Draw(); };
        toolbar.Children.Add(clear);
        toolbar.Children.Add(new TextBlock { Text = "  Scale", VerticalAlignment = VerticalAlignment.Center });
        axis.Items.Add("Individual (normalized)"); axis.Items.Add("Shared raw values"); axis.SelectedIndex = 0; toolbar.Children.Add(axis);
        zoom.ValueChanged += (_, _) => { offset.Value = Math.Min(offset.Value, 1); Draw(); };
        offset.ValueChanged += (_, _) => Draw(); axis.SelectionChanged += (_, _) => Draw();
        var footer = new StackPanel { Margin = new Thickness(4, 8, 4, 0) }; DockPanel.SetDock(footer, Dock.Bottom);
        footer.Children.Add(info); footer.Children.Add(cursor); layout.Children.Add(footer);
        var body = new Grid(); body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(245) });
        body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }); layout.Children.Add(body);
        var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Background = new SolidColorBrush(Color.FromRgb(29, 42, 56)) };
        var side = new StackPanel(); side.Children.Add(new TextBlock { Text = "CHANNELS  ·  toggle visibility", FontWeight = FontWeights.Bold, Margin = new Thickness(10, 12, 5, 6) });
        channelSearch.TextChanged += (_, _) => FilterChannels();
        channelSearch.Text = "";
        side.Children.Add(new TextBlock { Text = "Search channels", Foreground = Brushes.LightGray, Margin = new Thickness(10, 0, 5, 4) });
        side.Children.Add(channelSearch);
        var controls = new WrapPanel { Margin = new Thickness(8, 0, 8, 5) };
        var showAll = new Button { Content = "Show all", Padding = new Thickness(8, 4, 8, 4), Margin = new Thickness(2) };
        var hideAll = new Button { Content = "Hide all", Padding = new Thickness(8, 4, 8, 4), Margin = new Thickness(2) };
        showAll.Click += (_, _) => SetVisibleChannels(true);
        hideAll.Click += (_, _) => SetVisibleChannels(false);
        controls.Children.Add(showAll); controls.Children.Add(hideAll); side.Children.Add(controls);
        side.Children.Add(channelCount); side.Children.Add(legend); scroll.Content = side; body.Children.Add(scroll);
        Grid.SetColumn(plot, 1); body.Children.Add(plot);
        plot.SizeChanged += (_, _) => Draw();
        plot.MouseMove += (_, e) => ShowCursor(e.GetPosition(plot));
        if (!string.IsNullOrWhiteSpace(initialFile) && File.Exists(initialFile)) LoadCsv(initialFile);
    }

    // Supports RFC-style quoted CSV fields (including escaped quotes and embedded newlines).
    private static IEnumerable<string[]> ReadRecords(TextReader reader)
    {
        var field = new StringBuilder(); var record = new List<string>(); bool quoted = false;
        while (true)
        {
            int n = reader.Read();
            if (n < 0) { if (quoted) throw new FormatException("Unterminated quoted CSV field"); if (field.Length > 0 || record.Count > 0) { record.Add(field.ToString()); yield return record.ToArray(); } yield break; }
            char c = (char)n;
            if (c == '"') { if (quoted && reader.Peek() == '"') { reader.Read(); field.Append('"'); } else quoted = !quoted; }
            else if (c == ',' && !quoted) { record.Add(field.ToString()); field.Clear(); }
            else if ((c == '\n' || c == '\r') && !quoted)
            {
                if (c == '\r' && reader.Peek() == '\n') reader.Read();
                record.Add(field.ToString()); field.Clear(); yield return record.ToArray(); record.Clear();
            }
            else field.Append(c);
        }
    }

    private void LoadCsv(string file)
    {
        try
        {
            var loaded = new Dictionary<string, List<Sample>>(StringComparer.OrdinalIgnoreCase);
            int accepted = 0, skipped = 0; double maxTime = 0;
            using var reader = new StreamReader(file);
            using var enumerator = ReadRecords(reader).GetEnumerator();
            if (!enumerator.MoveNext()) throw new FormatException("CSV file is empty");
            var header = enumerator.Current.Select(x => x.Trim().TrimStart('\uFEFF')).ToArray();
            int Index(string name) => Array.FindIndex(header, x => string.Equals(x, name, StringComparison.OrdinalIgnoreCase));
            int t = Index("elapsed_ms"), pid = Index("pid"), parameter = Index("parameter"), value = Index("value"), unit = Index("unit");
            if (t < 0 || value < 0 || (pid < 0 && parameter < 0)) throw new FormatException("Expected Boostech CSV columns: elapsed_ms, pid/parameter, value");
            while (enumerator.MoveNext())
            {
                var fields = enumerator.Current;
                if (fields.Length <= Math.Max(t, Math.Max(value, Math.Max(pid, parameter)))) { skipped++; continue; }
                if (!double.TryParse(fields[t], NumberStyles.Float, CultureInfo.InvariantCulture, out var ms) ||
                    !double.TryParse(fields[value], NumberStyles.Float, CultureInfo.InvariantCulture, out var y) ||
                    !double.IsFinite(ms) || !double.IsFinite(y) || ms < 0) { skipped++; continue; }
                var name = parameter >= 0 && fields[parameter].Length > 0 ? fields[parameter] : fields[pid];
                if (string.IsNullOrWhiteSpace(name)) { skipped++; continue; }
                var suffix = unit >= 0 && unit < fields.Length && fields[unit].Length > 0 ? $" ({fields[unit]})" : "";
                var key = name + suffix;
                if (!loaded.TryGetValue(key, out var samples)) loaded[key] = samples = new List<Sample>();
                samples.Add(new Sample(ms / 1000d, y)); accepted++; maxTime = Math.Max(maxTime, ms / 1000d);
                if (accepted > 1_000_000) throw new InvalidDataException("CSV exceeds the 1,000,000-sample viewer limit");
            }
            if (accepted == 0) throw new FormatException("No valid numeric samples found");
            foreach (var samples in loaded.Values) samples.Sort((a, b) => a.Time.CompareTo(b.Time));
            AddRun(System.IO.Path.GetFileNameWithoutExtension(file), "Log", loaded,
                $"{accepted:N0} CSV samples, {skipped:N0} skipped");
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Could not open CSV", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }


    // The .yourdyno file is a ZIP containing a nested .ydrun ZIP with data.json.
    // All values are read-only. No temporary files are written.
    private void LoadYourDyno(string file)
    {
        try
        {
            var loaded = new Dictionary<string, List<Sample>>(StringComparer.OrdinalIgnoreCase);
            using var outer = ZipFile.OpenRead(file);
            var runEntries = outer.Entries.Where(e => e.FullName.EndsWith(".ydrun", StringComparison.OrdinalIgnoreCase)).ToArray();
            if (runEntries.Length == 0) throw new InvalidDataException("No .ydrun entry found inside this YourDyno export.");
            if (runEntries.Length > 20) throw new InvalidDataException("Too many runs in archive (limit 20).");
            int runIndex = 0;
            foreach (var runEntry in runEntries)
            {
                if (runEntry.Length > 100_000_000) throw new InvalidDataException("Run exceeds 100 MB limit.");
                using var stream = runEntry.Open();
                using var buffer = new MemoryStream();
                stream.CopyTo(buffer);
                buffer.Position = 0;
                using var inner = new ZipArchive(buffer, ZipArchiveMode.Read, leaveOpen: false);
                var dataEntry = inner.GetEntry("data.json") ?? throw new InvalidDataException("Nested run has no data.json.");
                if (dataEntry.Length > 100_000_000) throw new InvalidDataException("Run data exceeds 100 MB limit.");
                using var dataStream = dataEntry.Open();
                using var doc = JsonDocument.Parse(dataStream);
                var root = doc.RootElement;
                if (!root.TryGetProperty("Time", out var timeObj) ||
                    !timeObj.TryGetProperty("rawData", out var times) ||
                    times.ValueKind != JsonValueKind.Array)
                    throw new InvalidDataException("YourDyno run has no Time.rawData array.");
                var timeValues = times.EnumerateArray().Select(v => v.GetDouble()).ToArray();
                if (timeValues.Length == 0) continue;
                double origin = timeValues[0];
                var namePrefix = runEntries.Length > 1 ? $"Run {++runIndex} / " : "";
                foreach (var channel in root.EnumerateObject())
                {
                    if (channel.NameEquals("Time") || channel.Value.ValueKind != JsonValueKind.Object ||
                        !channel.Value.TryGetProperty("rawData", out var raw) || raw.ValueKind != JsonValueKind.Array)
                        continue;
                    var samples = new List<Sample>();
                    int i = 0;
                    foreach (var val in raw.EnumerateArray())
                    {
                        if (i >= timeValues.Length) break;
                        if (val.ValueKind == JsonValueKind.Number &&
                            val.TryGetDouble(out double v) && double.IsFinite(v) &&
                            double.IsFinite(timeValues[i]))
                            samples.Add(new Sample(Math.Max(0, timeValues[i] - origin), v));
                        i++;
                    }
                    if (samples.Count > 0) loaded[namePrefix + channel.Name] = samples;
                }
            }
            if (loaded.Count == 0) throw new InvalidDataException("No numeric channels were found.");
            var maxTime = loaded.Values.SelectMany(v => v).Max(x => x.Time);
            AddRun(System.IO.Path.GetFileNameWithoutExtension(file), "YourDyno", loaded,
                $"{runEntries.Length} YourDyno run(s), raw channels");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Could not open YourDyno export", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private static string FindRpmChannel(Dictionary<string, List<Sample>> channels)
    {
        // Never substitute roller/dyno RPM for actual engine RPM.
        var names = channels.Keys.ToArray();
        return names.FirstOrDefault(k => k.Equals("Engine RPM", StringComparison.OrdinalIgnoreCase))
            ?? names.FirstOrDefault(k => k.Equals("RPM", StringComparison.OrdinalIgnoreCase))
            ?? names.FirstOrDefault(k => k.StartsWith("Engine RPM (", StringComparison.OrdinalIgnoreCase))
            ?? names.FirstOrDefault(k => k.StartsWith("RPM (", StringComparison.OrdinalIgnoreCase))
            ?? names.FirstOrDefault(k => k.Contains("Engine Speed", StringComparison.OrdinalIgnoreCase))
            ?? names.FirstOrDefault(k => k.Contains("RPM", StringComparison.OrdinalIgnoreCase)
                && !k.Contains("Dyno", StringComparison.OrdinalIgnoreCase)
                && !k.Contains("Roller", StringComparison.OrdinalIgnoreCase)
                && !k.Contains("Target", StringComparison.OrdinalIgnoreCase)
                && !k.Contains("Error", StringComparison.OrdinalIgnoreCase))
            ?? "";
    }

    private void AddRun(string name, string source, Dictionary<string, List<Sample>> loaded, string description)
    {
        foreach (var v in loaded.Values) v.Sort((a,b) => a.Time.CompareTo(b.Time));
        var rpmName = FindRpmChannel(loaded);
        if (string.IsNullOrEmpty(rpmName))
            MessageBox.Show(this, $"{name}: no engine RPM channel detected. Time plotting works, but RPM alignment needs an engine RPM channel.",
                "RPM channel missing", MessageBoxButton.OK, MessageBoxImage.Information);
        // Keep both datasets. Prefix every channel so identical names do not collide.
        runs.Add(new RunData(name, source, loaded, rpmName));
        RebuildCombined();
        if (runs.Count > 1 && runs.All(r => r.RpmChannel.Length > 0)) xAxis.SelectedIndex = 1;
        info.Text = $"{runs.Count} loaded run(s) • {description} • RPM mode compares the overlapping engine-RPM sweep only";
        Draw();
    }

    private void RebuildCombined()
    {
        series.Clear(); rpmSeries.Clear(); switches.Clear(); legend.Children.Clear(); channelBranches.Clear();
        double minCommon = double.NegativeInfinity, maxCommon = double.PositiveInfinity;
        totalSeconds = 0; int color = 0;
        var tree = new TreeView { BorderThickness = new Thickness(0), Background = Brushes.Transparent, Foreground = Brushes.White };
        legend.Children.Add(tree);
        var sources = new Dictionary<string, TreeViewItem>(StringComparer.OrdinalIgnoreCase);
        foreach (var run in runs)
        {
            if (!sources.TryGetValue(run.Source, out var sourceNode))
            {
                sourceNode = new TreeViewItem { Header = run.Source, IsExpanded = true, Foreground = Brushes.White };
                tree.Items.Add(sourceNode); sources[run.Source] = sourceNode;
            }
            var runNode = new TreeViewItem { Header = run.Name, IsExpanded = true, Foreground = Brushes.White };
            sourceNode.Items.Add(runNode);
            var categories = new Dictionary<string, TreeViewItem>(StringComparer.OrdinalIgnoreCase);
            var prefix = $"{runs.IndexOf(run) + 1}: {run.Name} / ";
            List<Sample>? rpm = null;
            if (run.RpmChannel.Length > 0) rpm = run.Channels[run.RpmChannel];
            if (rpm is { Count: > 1 })
            {
                // Use the first forward sweep from the first sustained low RPM point to its peak.
                // Avoid mapping the deceleration leg back onto the power pull.
                int peak = 0;
                for (int i = 1; i < rpm.Count; i++) if (rpm[i].Value > rpm[peak].Value) peak = i;
                var sweep = rpm.Take(peak + 1).Where(s => double.IsFinite(s.Value) && s.Value > 0).ToList();
                if (sweep.Count > 1)
                {
                    minCommon = Math.Max(minCommon, sweep.Min(x => x.Value));
                    maxCommon = Math.Min(maxCommon, sweep.Max(x => x.Value));
                    rpm = sweep;
                }
            }
            foreach (var (key, samples) in run.Channels)
            {
                var id = prefix + key;
                series[id] = samples;
                if (rpm != null) rpmSeries[id] = rpm;
                bool visible = key.Contains("Power", StringComparison.OrdinalIgnoreCase)
                    || key.Contains("Torque", StringComparison.OrdinalIgnoreCase);
                var check = new CheckBox { Content = key, IsChecked = visible,
                    Foreground = colors[color++ % colors.Length], Margin = new Thickness(5, 6, 3, 6),
                    ToolTip = $"{samples.Count:N0} samples" };
                check.Checked += (_, _) => { UpdateChannelCount(); Draw(); };
                check.Unchecked += (_, _) => { UpdateChannelCount(); Draw(); };
                var group = ChannelGroup(key);
                if (!categories.TryGetValue(group, out var categoryNode))
                {
                    categoryNode = new TreeViewItem { Header = group, IsExpanded = group == "Power & Torque", Foreground = Brushes.LightGray };
                    categories[group] = categoryNode; runNode.Items.Add(categoryNode);
                }
                var leaf = new TreeViewItem { Header = check, Foreground = Brushes.White };
                categoryNode.Items.Add(leaf);
                if (!channelBranches.TryGetValue(id, out var path)) channelBranches[id] = path = new List<TreeViewItem>();
                path.Add(sourceNode); path.Add(runNode); path.Add(categoryNode); path.Add(leaf);
                switches[id] = check;
                if (samples.Count > 0) totalSeconds = Math.Max(totalSeconds, samples[^1].Time);
            }
        }
        minRpm = double.IsFinite(minCommon) ? minCommon : 0;
        maxRpm = double.IsFinite(maxCommon) ? maxCommon : 0;
        zoom.Value = 1; offset.Value = 0;
        FilterChannels(); UpdateChannelCount();
    }

    private bool RpmMode => xAxis.SelectedIndex == 1;

    private (double start, double end) XRange()
    {
        double min = RpmMode ? minRpm : 0;
        double max = RpmMode ? maxRpm : totalSeconds;
        double width = Math.Max((max - min) / zoom.Value, 0.001);
        double start = min + (max - min - width) * offset.Value;
        return (start, start + width);
    }

    private static double? RpmAtTime(List<Sample> rpm, double time)
    {
        if (rpm.Count < 2 || time < rpm[0].Time || time > rpm[^1].Time) return null;
        int lo = 0, hi = rpm.Count - 1;
        while (lo < hi) { int m = (lo + hi) / 2; if (rpm[m].Time < time) lo = m + 1; else hi = m; }
        if (lo == 0) return rpm[0].Value;
        var a = rpm[lo - 1]; var b = rpm[lo];
        return b.Time <= a.Time ? b.Value : a.Value + (b.Value - a.Value) * (time - a.Time) / (b.Time - a.Time);
    }

    private IEnumerable<(double X, double Y)> Points(string key, List<Sample> samples)
    {
        if (!RpmMode) return samples.Select(s => (s.Time, s.Value));
        if (!rpmSeries.TryGetValue(key, out var rpm)) return Enumerable.Empty<(double, double)>();
        // For each logged channel sample, interpolate the engine RPM at its timestamp.
        // This correctly maps staggered OBD PID samples onto the dyno RPM axis.
        return samples.Select(s => (X: RpmAtTime(rpm, s.Time), Y: s.Value))
            .Where(p => p.X.HasValue && p.X.Value >= minRpm && p.X.Value <= maxRpm)
            .Select(p => (p.X!.Value, p.Y));
    }

    private void SetVisibleChannels(bool visible)
    {
        foreach (var check in switches.Values) check.IsChecked = visible;
        UpdateChannelCount();
        Draw();
    }

    private static string ChannelGroup(string name)
    {
        string n = name.ToLowerInvariant();
        if (n.Contains("spark") || n.Contains("ignition") || n.Contains("timing advance") || n.Contains("knock") || n.Contains("coil") || n.Contains("dwell")) return "Spark & Ignition";
        if (n.Contains("power") || n.Contains("torque") || n.Contains("horsepower") || n.Contains("wheel hp")) return "Power & Torque";
        if (n.Contains("afr") || n.Contains("lambda") || n.Contains("oxygen") || n.Contains("o2") || n.Contains("fuel") || n.Contains("inject")) return "Fuel & AFR";
        if (n.Contains("boost") || n.Contains("map") || n.Contains("pressure") || n.Contains("vacuum")) return "Boost & Pressure";
        if (n.Contains("temp") || n.Contains("coolant") || n.Contains("iat") || n.Contains("egt")) return "Temperatures";
        if (n.Contains("rpm") || n.Contains("speed") || n.Contains("throttle") || n.Contains("tps") || n.Contains("pedal")) return "Engine & Speed";
        if (n.Contains("brake") || n.Contains("load") || n.Contains("inertia")) return "Dyno & Load";
        if (n.Contains("ambient") || n.Contains("humidity") || n.Contains("weather")) return "Environment";
        return "Other Channels";
    }

    private void FilterChannels()
    {
        string query = channelSearch.Text.Trim();
        var matches = new HashSet<TreeViewItem>();
        foreach (var (id, path) in channelBranches)
        {
            bool found = query.Length == 0 || id.Contains(query, StringComparison.OrdinalIgnoreCase)
                || ChannelGroup(id).Contains(query, StringComparison.OrdinalIgnoreCase);
            path[^1].Visibility = found ? Visibility.Visible : Visibility.Collapsed;
            if (found) foreach (var node in path.Take(path.Count - 1)) matches.Add(node);
            if (found && query.Length > 0) foreach (var node in path.Take(path.Count - 1)) node.IsExpanded = true;
        }
        foreach (var path in channelBranches.Values)
            foreach (var node in path.Take(path.Count - 1))
                node.Visibility = matches.Contains(node) ? Visibility.Visible : Visibility.Collapsed;
        UpdateChannelCount();
    }

    private void UpdateChannelCount()
    {
        channelCount.Text = $"{switches.Values.Count(x => x.IsChecked == true)} visible / {switches.Count} logged channels";
    }

    private (double start, double end) WindowRange()
    {
        return XRange();
    }

    private void Draw()
    {
        if (plot == null || series == null || switches == null) return;
        plot.Children.Clear(); double w = plot.ActualWidth, h = plot.ActualHeight;
        if (w < 80 || h < 80 || series.Count == 0) return;
        if (RpmMode && maxRpm <= minRpm) { var t = new TextBlock { Text = "No overlapping engine RPM range. Load files with engine RPM channels.", Foreground = Brushes.Orange, Margin = new Thickness(20) }; plot.Children.Add(t); return; }
        const double left = 62, right = 20, top = 26, bottom = 48;
        double pw = w - left - right, ph = h - top - bottom;
        if (pw <= 0 || ph <= 0) return;
        var (start, end) = WindowRange();
        void Line(double x1, double y1, double x2, double y2, Brush brush, double thickness = 1)
        { plot.Children.Add(new Line { X1 = x1, Y1 = y1, X2 = x2, Y2 = y2, Stroke = brush, StrokeThickness = thickness }); }
        void Label(string text, double x, double y, Brush brush)
        { var block = new TextBlock { Text = text, Foreground = brush, FontSize = 11 }; Canvas.SetLeft(block, x); Canvas.SetTop(block, y); plot.Children.Add(block); }
        var gridBrush = new SolidColorBrush(Color.FromRgb(46, 61, 77));
        for (int i = 0; i <= 5; i++)
        {
            double x = left + i * pw / 5, y = top + i * ph / 5;
            Line(x, top, x, top + ph, gridBrush); Line(left, y, left + pw, y, gridBrush);
            Label(RpmMode ? $"{start + i * (end - start) / 5:F0}" : $"{start + i * (end - start) / 5:F1}s", x - 12, top + ph + 9, Brushes.LightGray);
        }
        var selected = series.Where(x => switches.TryGetValue(x.Key, out var cb) && cb.IsChecked == true).ToArray();
        bool shared = axis.SelectedIndex == 1;
        var visibleValues = selected.SelectMany(x => Points(x.Key, x.Value).Where(s => s.X >= start && s.X <= end).Select(s => s.Y)).ToArray();
        double sharedMin = visibleValues.Length == 0 ? 0 : visibleValues.Min(), sharedMax = visibleValues.Length == 0 ? 1 : visibleValues.Max();
        if (sharedMax <= sharedMin) sharedMax = sharedMin + 1;
        int idx = 0;
        foreach (var (key, samples) in series)
        {
            var brush = colors[idx++ % colors.Length];
            if (!switches.TryGetValue(key, out var check) || check.IsChecked != true) continue;
            var visible = Points(key, samples).Where(s => s.X >= start && s.X <= end).ToArray();
            if (visible.Length == 0) continue;
            double min = shared ? sharedMin : visible.Min(s => s.Y), max = shared ? sharedMax : visible.Max(s => s.Y);
            if (max <= min) { min -= 0.5; max += 0.5; }
            var geometry = new StreamGeometry();
            using (var ctx = geometry.Open())
            {
                bool first = true;
                // Bound drawing complexity to approximately two points per horizontal pixel.
                int stride = Math.Max(1, visible.Length / Math.Max(1, (int)(pw * 2)));
                for (int i = 0; i < visible.Length; i += stride)
                {
                    var s = visible[i]; var p = new Point(left + (s.X - start) / (end - start) * pw, top + (max - s.Y) / (max - min) * ph);
                    if (first) { ctx.BeginFigure(p, false, false); first = false; } else ctx.LineTo(p, true, false);
                }
            }
            geometry.Freeze(); plot.Children.Add(new System.Windows.Shapes.Path { Data = geometry, Stroke = brush, StrokeThickness = 1.7, SnapsToDevicePixels = true });
        }
        Label(shared ? $"Shared axis: {sharedMin:F1} – {sharedMax:F1}" : "Per-channel normalized scale (0–100%)", left + 4, 4, Brushes.LightGray);
        Label(RpmMode ? "Engine RPM (aligned across runs)" : "Elapsed time (seconds)", left + pw / 2 - 90, h - 18, Brushes.LightGray);
    }

    private void ShowCursor(Point p)
    {
        if (plot.ActualWidth <= 82 || series.Count == 0) return;
        double frac = Math.Clamp((p.X - 62) / (plot.ActualWidth - 82), 0, 1);
        var (start, end) = XRange(); double x = start + frac * (end - start);
        var parts = new List<string> { RpmMode ? $"Cursor {x:F0} RPM" : $"Cursor {x:F2}s" };
        foreach (var (key, samples) in series.Where(e => switches.TryGetValue(e.Key, out var cb) && cb.IsChecked == true))
        {
            var points = Points(key, samples).ToArray();
            if (points.Length == 0) continue;
            var nearest = points.MinBy(p => Math.Abs(p.X - x));
            parts.Add($"{key}: {nearest.Y:F2}");
        }
        cursor.Text = string.Join("    |    ", parts);
    }

    private void ExportPng()
    {
        if (series.Count == 0) { MessageBox.Show(this, "Open a CSV first."); return; }
        var dlg = new SaveFileDialog { Filter = "PNG image|*.png", FileName = "Boostech_Dyno_Chart.png" };
        if (dlg.ShowDialog(this) != true) return;
        try
        {
            var size = new Size(Math.Max(1, plot.ActualWidth), Math.Max(1, plot.ActualHeight));
            plot.Measure(size); plot.Arrange(new Rect(size));
            var bmp = new System.Windows.Media.Imaging.RenderTargetBitmap((int)Math.Ceiling(size.Width), (int)Math.Ceiling(size.Height), 96, 96, PixelFormats.Pbgra32);
            bmp.Render(plot);
            var encoder = new System.Windows.Media.Imaging.PngBitmapEncoder(); encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(bmp));
            using var stream = File.Create(dlg.FileName); encoder.Save(stream);
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "PNG export failed", MessageBoxButton.OK, MessageBoxImage.Error); }
    }
}
