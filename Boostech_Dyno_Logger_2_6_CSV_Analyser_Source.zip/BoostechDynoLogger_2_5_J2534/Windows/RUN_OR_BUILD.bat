@echo off
cd /d "%~dp0"
if exist "Release\BoostechDynoLogger.exe" (start "" "Release\BoostechDynoLogger.exe" & exit /b 0)
call PUBLISH_EXE.bat
if exist "Release\BoostechDynoLogger.exe" start "" "Release\BoostechDynoLogger.exe"
