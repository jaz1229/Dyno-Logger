using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace BoostechDynoLogger;

// Read-only Mode 09 identification. Never guesses ECU family from model/year alone.
public sealed class EcuIdentity {
 public string Vin {get;set;}="";
 public string VinManufacturer {get;set;}="";
 public string CalibrationIds {get;set;}="";
 public string CvnHex {get;set;}="";
 public string Protocol {get;set;}="";
 public string Adapter {get;set;}="";
 public string EcuHeader {get;set;}="";
 public string SupportedPidSignature {get;set;}="";
 public string Mode09Supported {get;set;}="";
 public string MatchStatus {get;set;}="Unverified ECU family";
 public List<string> Warnings {get;set;}=[];
 public Dictionary<string,string> RawResponses {get;set;}=new();
 public DateTime CapturedUtc {get;set;}=DateTime.UtcNow;
}
public static class EcuIdentification {
 public static string ManufacturerFromVin(string vin) {
  if(vin.Length!=17)return "Unknown";
  // WMI identification is indicative, not proof of ECU model or country of manufacture.
  string wmi=vin[..3];
  if(wmi.StartsWith("WVW")||wmi.StartsWith("3VW")||wmi.StartsWith("9BW"))return "Volkswagen";
  if(wmi.StartsWith("WAU")||wmi.StartsWith("TRU"))return "Audi";
  if(wmi.StartsWith("WBA")||wmi.StartsWith("WBS")||wmi.StartsWith("5UX"))return "BMW";
  if(wmi.StartsWith("WDB")||wmi.StartsWith("WDD"))return "Mercedes-Benz";
  if(wmi.StartsWith("JHM")||wmi.StartsWith("1HG")||wmi.StartsWith("2HG"))return "Honda";
  if(wmi.StartsWith("JTD")||wmi.StartsWith("JT2")||wmi.StartsWith("4T1"))return "Toyota";
  if(wmi.StartsWith("1FA")||wmi.StartsWith("1FT")||wmi.StartsWith("WF0"))return "Ford";
  if(wmi.StartsWith("JN1")||wmi.StartsWith("JN8"))return "Nissan";
  if(wmi.StartsWith("KMH")||wmi.StartsWith("5NP"))return "Hyundai";
  if(wmi.StartsWith("KNA")||wmi.StartsWith("KND"))return "Kia";
  return "Unknown (WMI not in local reference)";
 }
 public static bool ValidVin(string vin) =>
  vin.Length==17 && Regex.IsMatch(vin,@"^[A-HJ-NPR-Z0-9]{17}$");
 // Handles ELM CAN headers, ISO-TP framing, ELM numbered responses and
 // headerless Mode 09 output. Rejects mixed/partial ISO-TP sequences.
 public static byte[] ParseMode09(string raw, byte pid) {
  var frames=new List<byte[]>();
  foreach(var source in raw.ToUpperInvariant().Split(['\r','\n'],StringSplitOptions.RemoveEmptyEntries)) {
   var line=source.Trim();
   if(line.Contains("NO DATA")||line.Contains("STOPPED")||line.Contains("SEARCHING")||line.Contains("ERROR"))continue;
   line=Regex.Replace(line,@"^\d+:\s*","");
   line=Regex.Replace(line,@"^(?:[0-9A-F]{3}|[0-9A-F]{8})\s+","");
   string hex=Regex.Replace(line,@"\s+","");
   if(hex.Length<4||hex.Length%2!=0||!Regex.IsMatch(hex,@"\A[0-9A-F]+\z"))continue;
   frames.Add(Enumerable.Range(0,hex.Length/2).Select(i=>Convert.ToByte(hex.Substring(i*2,2),16)).ToArray());
  }
  if(frames.Count==0)return [];
  var payload=new List<byte>();
  int expected=-1, nextSequence=1;
  foreach(var frame in frames){
   if(frame.Length==0)continue;
   int nibble=frame[0]>>4;
   if(nibble==1 && frame.Length>=3){
    expected=((frame[0]&0x0F)<<8)|frame[1];
    if(expected>16384)return [];
    payload.Clear();payload.AddRange(frame.Skip(2));nextSequence=1;
   }else if(nibble==2 && expected>=0){
    if((frame[0]&0x0F)!=(nextSequence&0x0F))return [];
    nextSequence++;payload.AddRange(frame.Skip(1));
   }else if(nibble==0 && frame.Length>=2 && frame[1]==0x49){
    payload.AddRange(frame.Skip(1).Take(frame[0]&0x0F));
   }else if(expected<0){
    // Unframed responses such as "49 02 01 ..." from ELM auto-formatting.
    payload.AddRange(frame);
   }
  }
  if(expected>=0){
   if(payload.Count<expected)return [];
   payload=payload.Take(expected).ToList();
  }
  for(int i=0;i+1<payload.Count;i++){
   if(payload[i]!=0x49||payload[i+1]!=pid)continue;
   int start=i+2;
   // Mode 09 responses commonly carry a message-count/index byte.
   if(start<payload.Count && payload[start]<=0x10)start++;
   return payload.Skip(start).Where(x=>x!=0).ToArray();
  }
  return [];
 }
 public static HashSet<byte> SupportedMode09Pids(string raw){
  var bytes=ParseMode09(raw,0x00);
  var result=new HashSet<byte>();
  if(bytes.Length<4)return result;
  for(int i=0;i<32;i++)if((bytes[i/8]&(0x80>>(i%8)))!=0)result.Add((byte)(i+1));
  return result;
 }
 public static string DecodeVin(string raw) {
  var bytes=ParseMode09(raw,0x02);
  var chars=new string(bytes.Where(b=>b>=0x20&&b<=0x7E).Select(b=>(char)b).ToArray()).Trim();
  var match=Regex.Match(chars,@"[A-HJ-NPR-Z0-9]{17}");
  return match.Success?match.Value:"";
 }
 public static string DecodeCalIds(string raw) {
  var bytes=ParseMode09(raw,0x04);
  if(bytes.Length==0)return "";
  return string.Join(" | ",Enumerable.Range(0,(bytes.Length+15)/16)
   .Select(i=>Encoding.ASCII.GetString(bytes.Skip(i*16).Take(16).ToArray()).Trim('\0',' ','\r','\n'))
   .Where(x=>x.Length>0));
 }
 public static string DecodeCvn(string raw) {
  var bytes=ParseMode09(raw,0x06);
  if(bytes.Length==0)return "";
  return Convert.ToHexString(bytes);
 }
 public static string MatchConfidence(EcuIdentity identity) {
  if(!string.IsNullOrWhiteSpace(identity.CalibrationIds) && ValidVin(identity.Vin))
   return "VIN + calibration ID retrieved; ECU family not independently verified";
  if(!string.IsNullOrWhiteSpace(identity.CalibrationIds))
   return "Calibration ID retrieved; ECU family not independently verified";
  if(ValidVin(identity.Vin))return "VIN retrieved; ECU family unknown";
  return "Insufficient identifiers; manual ECU profile selection required";
 }
 public static string ToJson(EcuIdentity identity) => JsonSerializer.Serialize(identity,new JsonSerializerOptions{WriteIndented=true});
}
