using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
namespace BoostechDynoLogger;
public sealed record EnhancedResult(string Request,string Raw,string Status,string Value,string? Error);
public static class EnhancedDiagnostics {
 // Only known read-only UDS identifiers. Manufacturer-specific values require
 // an independently validated ECU profile and are deliberately not guessed.
 public static readonly IReadOnlyDictionary<string,string> UdsIdentificationDids=new Dictionary<string,string>{
  ["F190"]="VIN",["F187"]="Vehicle manufacturer spare part number",
  ["F188"]="Vehicle manufacturer ECU software number",
  ["F189"]="Vehicle manufacturer ECU software version",
  ["F18A"]="System supplier identifier",
  ["F18C"]="ECU serial number",
  ["F191"]="Vehicle manufacturer ECU hardware number"
 };

 // The iCar Pro 2S may handle ISO-TP automatically (CAF1) or require a
 // single-frame PCI length byte (CAF0). These are two encodings of the
 // same read-only service 22 request, not an address scan.
 public static string BuildSingleFrameRead(string did) {
  if(!Regex.IsMatch(did,@"\A[0-9A-Fa-f]{4}\z"))throw new ArgumentException("Invalid DID");
  return "0322"+did.ToUpperInvariant();
 }
 public static string DescribeResponse(string raw,string did) {
  var positive=ParsePositiveUdsResponse(raw,did);
  if(positive is not null)return "POSITIVE: "+DecodeIdentification(did,positive);
  var nrc=Regex.Match(raw,@"(?i)(?:^|[\s:])(?:0?3\s+)?7F\s*22\s*([0-9A-F]{2})(?:\s|$)");
  if(!nrc.Success)nrc=Regex.Match(raw,@"(?i)(?:^|[\s:])7F22([0-9A-F]{2})(?:\s|$)");
  if(nrc.Success)return "ECU_NEGATIVE_NRC_"+nrc.Groups[1].Value.ToUpperInvariant();
  return ClassifyAdapterResponse(raw);
 }
 public static string? ValidateCanHeader(string input) {
  var id=input.Trim().ToUpperInvariant();
  if(!Regex.IsMatch(id,@"\A[0-9A-F]{3}\z"))return "Use a 3-digit 11-bit CAN request ID (for example 7E0).";
  int n=int.Parse(id,NumberStyles.HexNumber,CultureInfo.InvariantCulture);
  if(n<0x700||n>0x7EF)return "Only 0x700–0x7EF diagnostic request IDs are accepted in this preview.";
  return null;
 }
 public static byte[]? ParsePositiveUdsResponse(string raw,string did) {
  var wanted="62"+did.ToUpperInvariant();
  var frames=new List<byte[]>();
  foreach(var line in raw.ToUpperInvariant().Split(['\r','\n'],StringSplitOptions.RemoveEmptyEntries)) {
   string clean=Regex.Replace(line.Trim(),@"^\d+:\s*","");
   clean=Regex.Replace(clean,@"^(?:[0-9A-F]{3}|[0-9A-F]{8})\s+","");
   var parts=clean.Split(' ',StringSplitOptions.RemoveEmptyEntries);
   string hex=parts.Length>0&&parts.All(x=>Regex.IsMatch(x,@"\A[0-9A-F]{2}\z"))?string.Concat(parts):Regex.Replace(clean,@"\s+","");
   if(hex.Length%2!=0||!Regex.IsMatch(hex,@"\A[0-9A-F]+\z"))continue;
   var bytes=Convert.FromHexString(hex);
   if(bytes.Length>0)frames.Add(bytes);
  }
  // ELM auto-format may return already reassembled 62 DID payload.
  foreach(var f in frames){var h=Convert.ToHexString(f);if(h.StartsWith(wanted))return f.Skip(3).ToArray();}
  // Also support raw ISO-TP single / first / consecutive frames.
  var combined=new List<byte>();int expected=-1;int nextSeq=1;
  foreach(var f in frames){
   if(f.Length==0)continue;
   int type=f[0]>>4;
   if(type==0){int len=f[0]&15;if(len<=f.Length-1){var data=f.Skip(1).Take(len).ToArray();if(Convert.ToHexString(data).StartsWith(wanted))return data.Skip(3).ToArray();}}
   if(type==1 && f.Length>=2){expected=((f[0]&15)<<8)|f[1];combined.Clear();combined.AddRange(f.Skip(2));nextSeq=1;}
   else if(type==2 && expected>0){if((f[0]&15)!=(nextSeq&15))return null;nextSeq++;combined.AddRange(f.Skip(1));}
   if(expected>0 && combined.Count>=expected){var data=combined.Take(expected).ToArray();if(Convert.ToHexString(data).StartsWith(wanted))return data.Skip(3).ToArray();return null;}
  }
  return null;
 }
 public static string DecodeIdentification(string did,byte[] payload){
  if(did=="F190"){
   var vin=Encoding.ASCII.GetString(payload).Trim('\0',' ','\r','\n');
   return EcuIdentification.ValidVin(vin)?vin:"Unverified VIN: "+vin;
  }
  var ascii=Encoding.ASCII.GetString(payload).Trim('\0',' ','\r','\n');
  return payload.Length>0&&ascii.All(c=>c>=32&&c<=126)?ascii:Convert.ToHexString(payload);
 }
 public static string ClassifyAdapterResponse(string raw){
  var upper=raw.ToUpperInvariant();
  if(upper.Contains("STOPPED"))return "STOPPED";
  if(upper.Contains("NO DATA"))return "NO_DATA";
  if(upper.Contains("UNABLE TO CONNECT"))return "UNABLE_TO_CONNECT";
  if(upper.Contains("CAN ERROR")||upper.Contains("BUS ERROR"))return "BUS_ERROR";
  if(upper.Contains("BUFFER FULL"))return "BUFFER_FULL";
  if(IsNegativeResponse(raw))return "UDS_NEGATIVE";
  if(Regex.IsMatch(upper,@"(?:^|\s)(?:[0-9A-F]{3}\s+)?62\s*F1\s*[0-9A-F]{2}"))return "POSSIBLE_UDS_POSITIVE";
  if(upper.Trim()=="OK")return "ADAPTER_OK";
  if(upper.Contains("?"))return "UNRECOGNIZED_COMMAND";
  return "RAW_RESPONSE";
 }
 public static bool IsNegativeResponse(string raw)=>Regex.IsMatch(raw,@"(?i)(?:^|\s|:)7F\s*22\s*[0-9A-F]{2}(?:\s|$)") || Regex.IsMatch(raw,@"(?i)(?:^|\s)7F22[0-9A-F]{2}(?:\s|$)");
}
