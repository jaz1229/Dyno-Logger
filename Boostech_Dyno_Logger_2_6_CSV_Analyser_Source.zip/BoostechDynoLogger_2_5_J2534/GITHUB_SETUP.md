# GitHub Actions — Windows EXE

This source archive includes `.github/workflows/windows-build.yml`.

1. Open `https://github.com/jaz1229/Dyno-Logger`.
2. Upload the **contents** of the `BoostechDynoLogger_2_5_J2534` folder (not the enclosing folder) to the repository's `main` branch. Ensure `Windows/BoostechDynoLogger.csproj` and `.github/workflows/windows-build.yml` appear at the repository root.
3. Open **Actions** > **Windows EXE Build** > **Run workflow** (or let the upload trigger the build).
4. Open the completed workflow run and download the `Boostech-Dyno-Logger-win-x64` or `win-x86` artifact ZIP.
5. Extract the ZIP and run `BoostechDynoLogger.exe` on Windows.

The x86 build may be needed for a 32-bit J2534 driver. Driver bitness must match the application. A successful build does not establish that ECU communications are correct; test on a stationary vehicle first.

If GitHub Actions fails, open the failed step to see the actual compiler/restore error. The code has not been compiled or hardware-tested in this environment.
