# Boostech Dyno Logger v4.9 — experimental VW TP2.0 handshake probe

This release adds a **user-confirmed, single-frame TP2.0 channel-setup probe** to the Enhanced ECU ID tab. It sends CAN 0x200 data `01 C0 00 10 00 03 01` using ELM CAN 11/500 with CAF0 and an explicit 0x200 receive filter. Raw response and parsing are recorded in the existing transport trace. All adapter settings are restored in a finally block; if restore fails, reconnect before logging.

**This is NOT a full TP2.0 session, nor does it retrieve measuring blocks 020/115 or other enhanced channels.** A reply may be missed by ELM firmware or the chosen filter; a NO DATA result does not prove TP2.0 unsupported. The dongle's suitability remains unverified. Test only stationary, ignition on, engine off, with explicit consent. Do not perform during a dyno pull.

Run `Windows/PUBLISH_EXE.bat` on Windows and export the JSON transport trace after testing. This source package has not been Windows-compiled or hardware-tested.
