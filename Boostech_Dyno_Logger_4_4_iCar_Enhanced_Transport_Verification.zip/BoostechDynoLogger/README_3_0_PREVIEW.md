# Boostech Dyno Logger 3.0 — YourDyno Import Preview

## Implemented in this preview
- `Open YourDyno` button in the Windows CSV analyser.
- Direct, read-only `.yourdyno` import using the ZIP archive's nested `.ydrun/data.json`.
- Dynamic graph channels from every numeric `rawData` array, with channel search, show/hide all, and per-channel checkboxes.
- Supports multiple `.ydrun` entries in one export, prefixing their channel names by run index.
- Existing graph zoom/pan, normalized/raw scaling, cursor and PNG export remain.
- Keeps CSV import and existing logging features.

## Not yet implemented
- RPM as the graph X-axis, synchronized ECU/dyno logs, filtered YourDyno power calculations, run alignment, custom dashboard, new ECU protocols, or PDF reports.
- Manufacturer-specific logging and hardware connectivity are not validated by this change.

## Build
Run `Windows/PUBLISH_EXE.bat` on Windows with .NET 10 SDK. No Windows .NET compiler is available in this environment; build and real-world app behavior are unverified.

## Data handling
- Uses original YourDyno raw samples, not UnaVision-filtered displayed values.
- Time is relative to the first `Time.rawData` sample.
- Multi-run support is basic; runs share a relative time axis, not aligned by RPM.
- Archive limits: 20 nested runs, 100 MB per nested run/data JSON.
