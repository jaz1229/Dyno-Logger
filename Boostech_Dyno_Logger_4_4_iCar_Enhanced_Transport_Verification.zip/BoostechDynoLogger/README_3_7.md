# Boostech Dyno Logger 3.7 — Expanded standard PID support

Adds 25 standardized Mode 01 numeric decoders (including catalyst temperatures, fuel rate, evap, accelerator, injection timing, ethanol and more). Supported bitmap controls discovery; vehicle compatibility varies.

Adds manufacturer_pid_reference.json with documented VW measuring-block references and placeholders for other OEMs. This is **not** a working proprietary knock/boost library; no unverified manufacturer requests are sent. Existing v3.6.2 channel layout retained.

Sources: https://python-obd.readthedocs.io/en/latest/Command%20Tables/ and https://www.ross-tech.com/vag-com/m_blocks/020-029.html .

This is Windows source, not build- or hardware-verified. Build with Windows/PUBLISH_EXE.bat. Verify output against a known-good scan tool before dyno use.
