# Boostech Dyno Logger 3.3 — ECU identification preview

## Implemented
- **Identify ECU** button (separate from PID discovery and DTC scan).
- Read-only standard Mode 09 VIN (0902), calibration IDs (0904), CVN (0906), capability bitmap (0900).
- Adapter ID (ATI), detected protocol (ATDP), protocol number (ATDPN), standard PID signature (0100).
- Best-effort ASCII decoding, VIN format validation, indicative VIN WMI manufacturer, confidence messaging.
- ECU identification summary panel; warnings and Save ECU ID JSON with raw responses for troubleshooting.
- ECU identification saved alongside session metadata.
- Manufacturer/ECU reference catalog with explicit `reference-only` entries; no unsupported OEM requests.
- Fixes an important ELM transport bug: writes actual carriage return `\r`, not the literal characters `\\r`.

## Limits / quality gates
- Not yet a comprehensive proprietary ECU database. Model/year does not prove ECU family.
- ELM Mode 09 multi-frame responses vary by adapter and ECU; parsing requires real vehicle verification.
- The VIN may not be reported by motorcycles, older cars, tractors or marine ECUs.
- CVN/calibration IDs are diagnostic identifiers, not cryptographic authentication.
- ECU identification must be done when not logging or discovering.
- No .NET SDK or physical adapter available in this environment: **Windows compilation and hardware tests are outstanding**.
- Existing v3.2 discovery behavior and the rest of the logger are retained.
- Build: Windows/PUBLISH_EXE.bat.
