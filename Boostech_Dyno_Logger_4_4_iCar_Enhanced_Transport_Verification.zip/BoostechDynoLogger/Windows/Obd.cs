using System.IO;
using System.IO.Ports;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
namespace BoostechDynoLogger;
public sealed record PidDef(string Id,string Name,string Unit,Func<byte[],double?> Decode);
public static class Pids {
 public static readonly PidDef[] All = [
 new("1F","Engine runtime","s",b=>b.Length>=2?b[0]*256+b[1]:null),
 new("21","Distance with MIL on","km",b=>b.Length>=2?b[0]*256+b[1]:null),
 new("2C","Commanded EGR","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("2D","EGR error","%",b=>b.Length>=1?(b[0]-128)*100.0/128:null),
 new("2E","Commanded evap purge","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("2F","Fuel tank level","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("30","Warmups since DTC clear","count",b=>b.Length>=1?b[0]:null),
 new("31","Distance since DTC clear","km",b=>b.Length>=2?b[0]*256+b[1]:null),
 new("32","Evap vapor pressure","Pa",b=>b.Length>=2?((b[0]*256+b[1])-32768)/4.0:null),
 new("3C","Catalyst temp B1S1","°C",b=>b.Length>=2?(b[0]*256+b[1])/10.0-40:null),
 new("3D","Catalyst temp B2S1","°C",b=>b.Length>=2?(b[0]*256+b[1])/10.0-40:null),
 new("3E","Catalyst temp B1S2","°C",b=>b.Length>=2?(b[0]*256+b[1])/10.0-40:null),
 new("3F","Catalyst temp B2S2","°C",b=>b.Length>=2?(b[0]*256+b[1])/10.0-40:null),
 new("47","Throttle position B","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("48","Throttle position C","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("4D","Runtime with MIL on","min",b=>b.Length>=2?b[0]*256+b[1]:null),
 new("4E","Time since DTC clear","min",b=>b.Length>=2?b[0]*256+b[1]:null),
 new("52","Ethanol fuel percentage","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("53","Evap vapor pressure absolute","kPa",b=>b.Length>=2?(b[0]*256+b[1])/200.0:null),
 new("54","Evap vapor pressure alternate","Pa",b=>b.Length>=2?(b[0]*256+b[1])-32767:null),
 new("5A","Relative accelerator pedal","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("5B","Hybrid battery remaining","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("5D","Fuel injection timing","°",b=>b.Length>=2?(b[0]*256+b[1])/128.0-210:null),
 new("5E","Engine fuel rate","L/h",b=>b.Length>=2?(b[0]*256+b[1])/20.0:null),

 new("03","Fuel system status","code",b=>b.Length>=1?b[0]:null),
 new("08","Short-term fuel trim B2","%",b=>b.Length>=1?(b[0]-128)*100.0/128:null),
 new("09","Long-term fuel trim B2","%",b=>b.Length>=1?(b[0]-128)*100.0/128:null),
 new("0A","Fuel pressure","kPa",b=>b.Length>=1?b[0]*3.0:null),
 new("10","MAF airflow","g/s",b=>b.Length>=2?(b[0]*256+b[1])/100.0:null),
 new("43","Absolute load","%",b=>b.Length>=2?(b[0]*256+b[1])*100.0/255:null),
 new("44","Commanded equivalence ratio","ratio",b=>b.Length>=2?(b[0]*256+b[1])*2.0/65536:null),
 new("45","Relative throttle position","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("46","Ambient air temperature","°C",b=>b.Length>=1?b[0]-40:null),
 new("49","Accelerator pedal position D","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("4A","Accelerator pedal position E","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("4B","Accelerator pedal position F","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("4C","Commanded throttle actuator","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("5C","Engine oil temperature","°C",b=>b.Length>=1?b[0]-40:null),
 new("22","Fuel rail pressure relative","kPa",b=>b.Length>=2?(b[0]*256+b[1])*0.079:null),
 new("23","Fuel rail pressure diesel/direct injection","kPa",b=>b.Length>=2?(b[0]*256+b[1])*10.0:null),
 new("59","Fuel rail absolute pressure","kPa",b=>b.Length>=2?(b[0]*256+b[1])*10.0:null),
 new("16","O2 narrowband sensor 3","V",b=>b.Length>=2?b[0]/200.0:null),
 new("17","O2 narrowband sensor 4","V",b=>b.Length>=2?b[0]/200.0:null),
 new("18","O2 narrowband sensor 5","V",b=>b.Length>=2?b[0]/200.0:null),
 new("19","O2 narrowband sensor 6","V",b=>b.Length>=2?b[0]/200.0:null),
 new("1A","O2 narrowband sensor 7","V",b=>b.Length>=2?b[0]/200.0:null),
 new("1B","O2 narrowband sensor 8","V",b=>b.Length>=2?b[0]/200.0:null),
 new("25","O2 wideband sensor PID 25","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("26","O2 wideband sensor PID 26","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("27","O2 wideband sensor PID 27","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("28","O2 wideband sensor PID 28","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("29","O2 wideband sensor PID 29","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("2A","O2 wideband sensor PID 2A","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("2B","O2 wideband sensor PID 2B","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("35","O2 wideband sensor PID 35","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("36","O2 wideband sensor PID 36","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("37","O2 wideband sensor PID 37","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("38","O2 wideband sensor PID 38","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("39","O2 wideband sensor PID 39","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("3A","O2 wideband sensor PID 3A","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("3B","O2 wideband sensor PID 3B","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("04","Calculated load","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("05","Coolant temperature","°C",b=>b.Length>=1?b[0]-40:null),
 new("06","Short-term fuel trim B1","%",b=>b.Length>=1?(b[0]-128)*100.0/128:null),
 new("07","Long-term fuel trim B1","%",b=>b.Length>=1?(b[0]-128)*100.0/128:null),
 new("33","Barometric pressure","kPa",b=>b.Length>=1?b[0]:null),
 new("0B","Manifold pressure","kPa",b=>b.Length>=1?b[0]:null),
 new("0C","Engine RPM","rpm",b=>b.Length>=2?(b[0]*256+b[1])/4.0:null),
 new("0D","Vehicle speed","km/h",b=>b.Length>=1?b[0]:null),
 new("0E","Ignition advance","°",b=>b.Length>=1?b[0]/2.0-64:null),
 new("0F","Intake temperature","°C",b=>b.Length>=1?b[0]-40:null),
 new("11","Throttle position","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("42","ECU control voltage","V",b=>b.Length>=2?(b[0]*256+b[1])/1000.0:null),
 new("14","O2 sensor 1 voltage","V",b=>b.Length>=2?b[0]/200.0:null),
 new("15","O2 sensor 2 voltage","V",b=>b.Length>=2?b[0]/200.0:null),
 new("24","Wideband O2 equivalence ratio","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("34","Wideband O2 equivalence ratio","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null)
 ];
 public static HashSet<string> DecodeSupported(string raw, string basePid) {
  var data=Extract(raw,basePid); var result=new HashSet<string>(); if(data is null||data.Length<4)return result;
  int start=Convert.ToInt32(basePid,16);
  for(int i=0;i<32;i++)if((data[i/8] & (1 << (7-i%8)))!=0)result.Add((start+i+1).ToString("X2"));
  return result;
 }
 // Accept ELM echo, headers, optional line numbers and ISO-TP single-frame PCI.
 public static byte[]? Extract(string raw,string pid) {
  string expected="41"+pid.ToUpperInvariant();
  foreach(var line in raw.ToUpperInvariant().Split(['\r','\n'],StringSplitOptions.RemoveEmptyEntries)) {
   string cleaned=line.Trim();
   if(cleaned.Length==0 || cleaned.Contains("NO DATA") || cleaned.Contains("STOPPED")
     || cleaned.Contains("ERROR") || cleaned.Contains("UNABLE TO CONNECT")
     || cleaned.Contains("SEARCHING") || cleaned.Contains("?"))continue;
   cleaned=Regex.Replace(cleaned,@"^\d+:\s*","");
   // Handle common ELM CAN headers (7E8, 18DAF110) without interpreting
   // header digits as payload. Headers off is still the preferred setting.
   cleaned=Regex.Replace(cleaned,@"^(?:[0-9A-F]{3}|[0-9A-F]{8})\s+","");
   var tokens=cleaned.Split(' ',StringSplitOptions.RemoveEmptyEntries);
   string hex;
   if(tokens.Length>0 && tokens.All(t=>t.Length==2&&Regex.IsMatch(t,@"\A[0-9A-F]{2}\z")))
    hex=string.Concat(tokens);
   else {
    hex=Regex.Replace(cleaned,@"\s+","");
    if(!Regex.IsMatch(hex,@"\A[0-9A-F]+\z"))continue;
   }
   if(hex.Length<4 || hex.Length%2!=0)continue;
   // Only accept a service 01 response (41 PID), not an echoed 01 PID
   // request or unrelated text. Strip single-frame ISO-TP PCI if present.
   if(hex.Length>=6 && hex[0]=='0' && hex[1]!='0' && hex.Substring(2,4)==expected)
    hex=hex[2..];
   if(!hex.StartsWith(expected,StringComparison.Ordinal))continue;
   string payload=hex[4..];
   if(payload.Length%2!=0)continue;
   try{
    return Enumerable.Range(0,payload.Length/2)
     .Select(i=>byte.Parse(payload.Substring(i*2,2),NumberStyles.HexNumber,CultureInfo.InvariantCulture))
     .ToArray();
   }catch(FormatException){continue;}
  }
  return null;
 }

}
public interface IObdTransport:IDisposable {Task<string> RequestAsync(string command,CancellationToken ct);}
public sealed class SerialElmTransport:IObdTransport {
 private readonly SerialPort port;
 private readonly SemaphoreSlim gate=new(1,1);
 private bool synchronized=true;
 public SerialElmTransport(string name){
  port=new SerialPort(name,38400,Parity.None,8,StopBits.One){
   ReadTimeout=200,WriteTimeout=1500,NewLine="\r",DtrEnable=false,RtsEnable=false
  };
  port.Open();
 }
 private string ReadPrompt(int timeoutMs,CancellationToken ct){
  var text=new StringBuilder();var clock=System.Diagnostics.Stopwatch.StartNew();
  while(clock.ElapsedMilliseconds<timeoutMs){
   ct.ThrowIfCancellationRequested();
   try{
    int c=port.ReadChar();
    if(c=='>')return text.ToString();
    if(text.Length<32768)text.Append((char)c);
   }catch(TimeoutException){}
  }
  throw new TimeoutException($"No ELM prompt within {timeoutMs} ms");
 }
 public async Task<string> RequestAsync(string cmd,CancellationToken ct){
  await gate.WaitAsync(ct);
  try{
   return await Task.Run(()=>{
    ct.ThrowIfCancellationRequested();
    // Never discard pending ECU output then send a new command: that interrupts
    // the previous ELM operation and produces alternating STOPPED/timeouts.
    if(!synchronized){
     try{ReadPrompt(6000,ct);synchronized=true;}
     catch(TimeoutException){
      // Recover only at a known command boundary. The next request will not be
      // transmitted into an unfinished ECU operation.
      throw new IOException("ELM adapter has not returned to its prompt. Disconnect and reconnect.");
     }
    }
    port.Write(cmd+"\r");
    synchronized=false;
    var timeout=cmd.StartsWith("AT",StringComparison.OrdinalIgnoreCase)?5500:7000;
    string result=ReadPrompt(timeout,ct);
    synchronized=true;
    return result;
   },ct);
  }finally{gate.Release();}
 }
 public void Dispose(){if(port.IsOpen)port.Close();port.Dispose();gate.Dispose();}
}
public sealed class SimulatorTransport:IObdTransport {
 private readonly System.Diagnostics.Stopwatch sw=System.Diagnostics.Stopwatch.StartNew();
 public Task<string> RequestAsync(string command,CancellationToken ct){
  ct.ThrowIfCancellationRequested();command=command.ToUpperInvariant();string response;
  if(command.StartsWith("AT"))response=command=="ATDP"?"AUTO, ISO 15765-4 (CAN 11/500)":"OK";
  else if(command is "0100" or "0120" or "0140" or "0160") {
   int start=Convert.ToInt32(command.Substring(2),16);uint mask=0;
   foreach(var p in Pids.All){int n=Convert.ToInt32(p.Id,16);if(n>start&&n<=start+32)mask|=1u << (32-(n-start));}
   if(start==0)mask|=1u; if(start==0x20)mask|=1u; if(start==0x40)mask|=1u;
   response=$"41 {command.Substring(2)} {((mask>>24)&255):X2} {((mask>>16)&255):X2} {((mask>>8)&255):X2} {(mask&255):X2}";
  }else if(command.StartsWith("01")&&command.Length==4){
   double t=sw.Elapsed.TotalSeconds;int rpm=(int)(2500+3800*(0.5+0.5*Math.Sin(t/3)));int throttle=(int)(20+75*(0.5+0.5*Math.Sin(t/3)));
   string pid=command.Substring(2);response=pid switch{
    "0C"=>$"41 0C {(rpm*4>>8):X2} {(rpm*4&255):X2}","11"=>$"41 11 {(throttle*255/100):X2}","05"=>"41 05 7F","0B"=>"41 0B 60","0F"=>"41 0F 48","04"=>"41 04 A0","0E"=>"41 0E 90","0D"=>"41 0D 3C","06"=>"41 06 80","07"=>"41 07 80","42"=>"41 42 36 B0","14"=>"41 14 80 FF","15"=>"41 15 80 FF","24"=>"41 24 80 00 80 00","34"=>"41 34 80 00 80 00",_=>"NO DATA"};
  }else response="?";
  return Task.FromResult(response+"\r>");
 }
 public void Dispose(){}
}
