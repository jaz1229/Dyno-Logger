# Boostech Dyno Logger v3.4 — ECU Identification reliability update

- Mode 09 capability bitmap now gates VIN, calibration ID and CVN queries when available.
- Improved parsing of ISO-TP single/multi-frame replies, sequence validation and ELM headerless replies.
- Keeps raw ECU responses and flags missing identifiers rather than inventing an ECU match.
- Existing v3.2 ELM synchronization, PID discovery, CSV/YourDyno graphing and saved identity JSON retained.
- Manufacturer catalog remains **reference-only**: there are no verified proprietary DIDs or automatically identified ECU families.
- Compile using `Windows/PUBLISH_EXE.bat` on Windows with .NET 10 SDK. Build and physical vehicle validation have NOT been performed here.
- For professional deployment: test on multiple adapters, Mode 09 multi-ECU responses, K-line and J2534 variants; obtain verified OEM channel definitions with documented provenance.
