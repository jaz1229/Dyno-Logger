# Boostech Dyno Logger 4.3 — iCar Pro 2S transport diagnostics

## Delivered
- Timestamped raw command/response trace with elapsed milliseconds, classification and JSON export.
- Auto detection captures standard OBD2 ECU reply with headers enabled, rather than hiding the evidence.
- UDS test classifies NO DATA, STOPPED, bus errors and negative responses separately.
- Restores headers off and automatic OBD2 protocol after auto-detection.
- No guessed proprietary ECU addresses, diagnostic sessions or undocumented manufacturer-specific PIDs.

## Known limitations
- This is a **diagnostic instrumentation update**, not a working TP 2.0/KWP or universal OEM enhanced logger.
- The v4.2 code remains experimental; UDS multi-frame handling needs actual adapter/ECU verification.
- No Windows compiler or physical iCar Pro 2S available here; compilation and hardware testing outstanding.
- Raw traces may contain VIN and other identifying data; review/redact before sharing.
- On a stationary vehicle, connect COM11, run auto detection once, export transport trace, and share a redacted trace for the next protocol implementation.
