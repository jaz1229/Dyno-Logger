# CSV analyser v2.7

All numeric channels present in a compatible Boostech long-format CSV are dynamically listed. Check/uncheck any channel; Show all / Hide all buttons and channel search are provided. Search filters the list, not the graph. The cursor readout includes all selected channels. The existing chart supports zoom, pan, normalized/raw scale and PNG export.

Run Windows/PUBLISH_EXE.bat to build. Compilation and hardware tests are not verified in this environment.
