@echo off
setlocal
cd /d "%~dp0"
set "APP=bin\Release\net10.0-windows\win-x64\publish\BoostechDynoLogger.exe"
if exist "%APP%" (
 start "" "%APP%"
 exit /b 0
)
where dotnet >nul 2>&1
if errorlevel 1 (
 echo .NET 10 SDK is required for the first build.
 echo Download from https://dotnet.microsoft.com/en-us/download/dotnet/10.0
 pause
 exit /b 1
)
echo Building Boostech Dyno Logger for the first time...
dotnet publish "BoostechDynoLogger.csproj" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o "bin\Release\net10.0-windows\win-x64\publish"
if errorlevel 1 (
 echo Build failed. Check the error messages above. Internet may be needed for NuGet packages.
 pause
 exit /b 1
)
if not exist "%APP%" (
 echo Build completed but executable was not found.
 pause
 exit /b 1
)
start "" "%APP%"
