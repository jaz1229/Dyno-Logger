using System.IO.Ports;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
namespace BoostechDynoLogger;
public sealed record PidDef(string Id,string Name,string Unit,Func<byte[],double?> Decode);
public static class Pids {
 public static readonly PidDef[] All = [
 new("03","Fuel system status","code",b=>b.Length>=1?b[0]:null),
 new("08","Short-term fuel trim B2","%",b=>b.Length>=1?(b[0]-128)*100.0/128:null),
 new("09","Long-term fuel trim B2","%",b=>b.Length>=1?(b[0]-128)*100.0/128:null),
 new("0A","Fuel pressure","kPa",b=>b.Length>=1?b[0]*3.0:null),
 new("10","MAF airflow","g/s",b=>b.Length>=2?(b[0]*256+b[1])/100.0:null),
 new("43","Absolute load","%",b=>b.Length>=2?(b[0]*256+b[1])*100.0/255:null),
 new("44","Commanded equivalence ratio","ratio",b=>b.Length>=2?(b[0]*256+b[1])*2.0/65536:null),
 new("45","Relative throttle position","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("46","Ambient air temperature","°C",b=>b.Length>=1?b[0]-40:null),
 new("49","Accelerator pedal position D","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("4A","Accelerator pedal position E","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("4B","Accelerator pedal position F","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("4C","Commanded throttle actuator","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("5C","Engine oil temperature","°C",b=>b.Length>=1?b[0]-40:null),
 new("22","Fuel rail pressure relative","kPa",b=>b.Length>=2?(b[0]*256+b[1])*0.079:null),
 new("23","Fuel rail pressure diesel/direct injection","kPa",b=>b.Length>=2?(b[0]*256+b[1])*10.0:null),
 new("59","Fuel rail absolute pressure","kPa",b=>b.Length>=2?(b[0]*256+b[1])*10.0:null),
 new("16","O2 narrowband sensor 22","V",b=>b.Length>=2?b[0]/200.0:null),
 new("17","O2 narrowband sensor 23","V",b=>b.Length>=2?b[0]/200.0:null),
 new("18","O2 narrowband sensor 24","V",b=>b.Length>=2?b[0]/200.0:null),
 new("19","O2 narrowband sensor 25","V",b=>b.Length>=2?b[0]/200.0:null),
 new("1A","O2 narrowband sensor 26","V",b=>b.Length>=2?b[0]/200.0:null),
 new("1B","O2 narrowband sensor 27","V",b=>b.Length>=2?b[0]/200.0:null),
 new("25","O2 wideband sensor 37","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("26","O2 wideband sensor 38","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("27","O2 wideband sensor 39","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("28","O2 wideband sensor 40","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("29","O2 wideband sensor 41","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("2A","O2 wideband sensor 42","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("2B","O2 wideband sensor 43","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("35","O2 wideband sensor 53","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("36","O2 wideband sensor 54","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("37","O2 wideband sensor 55","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("38","O2 wideband sensor 56","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("39","O2 wideband sensor 57","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("3A","O2 wideband sensor 58","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("3B","O2 wideband sensor 59","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("04","Calculated load","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("05","Coolant temperature","°C",b=>b.Length>=1?b[0]-40:null),
 new("06","Short-term fuel trim B1","%",b=>b.Length>=1?(b[0]-128)*100.0/128:null),
 new("07","Long-term fuel trim B1","%",b=>b.Length>=1?(b[0]-128)*100.0/128:null),
 new("0B","Manifold pressure","kPa",b=>b.Length>=1?b[0]:null),
 new("0C","Engine RPM","rpm",b=>b.Length>=2?(b[0]*256+b[1])/4.0:null),
 new("0D","Vehicle speed","km/h",b=>b.Length>=1?b[0]:null),
 new("0E","Ignition advance","°",b=>b.Length>=1?b[0]/2.0-64:null),
 new("0F","Intake temperature","°C",b=>b.Length>=1?b[0]-40:null),
 new("11","Throttle position","%",b=>b.Length>=1?b[0]*100.0/255:null),
 new("42","ECU control voltage","V",b=>b.Length>=2?(b[0]*256+b[1])/1000.0:null),
 new("14","O2 sensor 1 voltage","V",b=>b.Length>=2?b[0]/200.0:null),
 new("15","O2 sensor 2 voltage","V",b=>b.Length>=2?b[0]/200.0:null),
 new("24","Wideband O2 equivalence ratio","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null),
 new("34","Wideband O2 equivalence ratio","ratio",b=>b.Length>=4?(b[0]*256+b[1])*2.0/65536:null)
 ];
 public static HashSet<string> DecodeSupported(string raw, string basePid) {
  var data=Extract(raw,basePid); var result=new HashSet<string>(); if(data is null||data.Length<4)return result;
  int start=Convert.ToInt32(basePid,16);
  for(int i=0;i<32;i++)if((data[i/8] & (1 << (7-i%8)))!=0)result.Add((start+i+1).ToString("X2"));
  return result;
 }
 // Accept ELM echo, headers, optional line numbers and ISO-TP single-frame PCI.
 public static byte[]? Extract(string raw,string pid) {
  foreach(var line in raw.ToUpperInvariant().Split(['\r','\n'],StringSplitOptions.RemoveEmptyEntries)) {
   var s=line.Trim(); if(s.Contains("NO DATA")||s.Contains("ERROR")||s.Contains("STOPPED"))continue;
   s=Regex.Replace(s,@"^\d+:\s*","");
   var tokens=Regex.Matches(s,@"(?<![0-9A-F])[0-9A-F]{2}(?![0-9A-F])").Select(m=>m.Value).ToList();
   // Handles spaced bytes and 3-digit CAN headers. Also handles compact hex lines.
   if(tokens.Count<2){var compact=Regex.Replace(s,@"[^0-9A-F]",""); if(compact.Length%2==0&&compact.Length>=4)tokens=Enumerable.Range(0,compact.Length/2).Select(i=>compact.Substring(i*2,2)).ToList();}
   for(int i=0;i+1<tokens.Count;i++)if(tokens[i]=="41"&&tokens[i+1]==pid) {
    return tokens.Skip(i+2).Select(t=>byte.Parse(t,NumberStyles.HexNumber)).ToArray();
   }
  }
  return null;
 }
}
public interface IObdTransport:IDisposable {Task<string> RequestAsync(string command,CancellationToken ct);}
public sealed class SerialElmTransport:IObdTransport {
 private readonly SerialPort port;
 public SerialElmTransport(string name){port=new SerialPort(name,38400,Parity.None,8,StopBits.One){ReadTimeout=300,WriteTimeout=1200,NewLine="\r",DtrEnable=false,RtsEnable=false};port.Open();}
 public async Task<string> RequestAsync(string cmd,CancellationToken ct){
  return await Task.Run(()=>{
   ct.ThrowIfCancellationRequested();port.DiscardInBuffer();port.Write(cmd+"\r");var b=new StringBuilder();var sw=System.Diagnostics.Stopwatch.StartNew();
   while(sw.ElapsedMilliseconds<2800){ct.ThrowIfCancellationRequested();try{var ch=(char)port.ReadChar();if(ch=='>')return b.ToString();b.Append(ch);}catch(TimeoutException){} }
   throw new TimeoutException("No ELM prompt within 2.8 seconds");
  },ct);
 }
 public void Dispose(){if(port.IsOpen)port.Close();port.Dispose();}
}
public sealed class SimulatorTransport:IObdTransport {
 private readonly System.Diagnostics.Stopwatch sw=System.Diagnostics.Stopwatch.StartNew();
 public Task<string> RequestAsync(string command,CancellationToken ct){
  ct.ThrowIfCancellationRequested();command=command.ToUpperInvariant();string response;
  if(command.StartsWith("AT"))response=command=="ATDP"?"AUTO, ISO 15765-4 (CAN 11/500)":"OK";
  else if(command is "0100" or "0120" or "0140" or "0160") {
   int start=Convert.ToInt32(command.Substring(2),16);uint mask=0;
   foreach(var p in Pids.All){int n=Convert.ToInt32(p.Id,16);if(n>start&&n<=start+32)mask|=1u << (32-(n-start));}
   if(start==0)mask|=1u; if(start==0x20)mask|=1u; if(start==0x40)mask|=1u;
   response=$"41 {command.Substring(2)} {((mask>>24)&255):X2} {((mask>>16)&255):X2} {((mask>>8)&255):X2} {(mask&255):X2}";
  }else if(command.StartsWith("01")&&command.Length==4){
   double t=sw.Elapsed.TotalSeconds;int rpm=(int)(2500+3800*(0.5+0.5*Math.Sin(t/3)));int throttle=(int)(20+75*(0.5+0.5*Math.Sin(t/3)));
   string pid=command.Substring(2);response=pid switch{
    "0C"=>$"41 0C {(rpm*4>>8):X2} {(rpm*4&255):X2}","11"=>$"41 11 {(throttle*255/100):X2}","05"=>"41 05 7F","0B"=>"41 0B 60","0F"=>"41 0F 48","04"=>"41 04 A0","0E"=>"41 0E 90","0D"=>"41 0D 3C","06"=>"41 06 80","07"=>"41 07 80","42"=>"41 42 36 B0","14"=>"41 14 80 FF","15"=>"41 15 80 FF","24"=>"41 24 80 00 80 00","34"=>"41 34 80 00 80 00",_=>"NO DATA"};
  }else response="?";
  return Task.FromResult(response+"\r>");
 }
 public void Dispose(){}
}
